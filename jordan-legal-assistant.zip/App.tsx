import React, { useState, useRef, useEffect } from 'react';
import { Send, Menu, Scale, Loader2, Briefcase, FileText, ChevronRight, Trash2, Mic, MicOff, Download, ArrowDown } from 'lucide-react';
import ChatMessage from './components/ChatMessage';
import Sidebar from './components/Sidebar';
import { queryLegalAssistant } from './services/geminiUtils';
import { Message, QueryStatus } from './types';

// Speech Recognition Type Definition
declare global {
  interface Window {
    webkitSpeechRecognition: any;
    SpeechRecognition: any;
  }
}

const App: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [status, setStatus] = useState<QueryStatus>(QueryStatus.IDLE);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [showScrollButton, setShowScrollButton] = useState(false);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const chatContainerRef = useRef<HTMLDivElement>(null);

  const suggestedQuestions = [
    { text: "ما عقوبة القتل القصد في القانون الأردني؟", icon: <Scale size={18} /> },
    { text: "ما هي شروط استحقاق علاوة السفر؟", icon: <Briefcase size={18} /> },
    { text: "كيف يتم حساب الإجازات السنوية؟", icon: <FileText size={18} /> },
  ];

  // Scroll Handling
  const scrollToBottom = (smooth = true) => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: smooth ? 'smooth' : 'auto', block: 'end' });
    }
  };

  // Auto-scroll on new messages
  useEffect(() => {
    if (messages.length > 0) {
      scrollToBottom();
    }
  }, [messages, status]);

  // Handle Scroll Visibility
  const handleScroll = () => {
    if (chatContainerRef.current) {
      const { scrollTop, scrollHeight, clientHeight } = chatContainerRef.current;
      // Show button if user is more than 300px away from bottom
      const isNotAtBottom = scrollHeight - scrollTop - clientHeight > 300;
      setShowScrollButton(isNotAtBottom);
    }
  };

  const handleQuickQuestion = (question: string) => {
    setInput(question);
    // Optional: Auto submit here if desired
  };

  const handleClearChat = () => {
    if (window.confirm('هل أنت متأكد من رغبتك في مسح المحادثة وبدء جلسة جديدة؟')) {
      setMessages([]);
      setInput('');
      setStatus(QueryStatus.IDLE);
      window.speechSynthesis.cancel();
    }
  };

  const handleExportChat = () => {
    if (messages.length === 0) return;
    
    const textContent = messages.map(m => 
      `[${m.timestamp.toLocaleString('ar-JO')}] ${m.role === 'user' ? 'السائل' : 'المستشار'}:\n${m.content}\n-------------------`
    ).join('\n\n');
    
    const blob = new Blob([textContent], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `استشارة_قانونية_${new Date().toISOString().slice(0,10)}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Voice Recognition Logic
  const toggleListening = () => {
    if (isListening) {
      setIsListening(false);
      return;
    }

    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert("عذراً، متصفحك لا يدعم ميزة الإدخال الصوتي.");
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = 'ar-JO'; // Jordanian Arabic dialect preference
    recognition.continuous = false;
    recognition.interimResults = false;

    recognition.onstart = () => setIsListening(true);
    recognition.onend = () => setIsListening(false);
    
    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      setInput(prev => prev ? `${prev} ${transcript}` : transcript);
    };

    recognition.onerror = (event: any) => {
      console.error("Speech recognition error", event.error);
      setIsListening(false);
    };

    recognition.start();
  };

  const handleSubmit = async (e?: React.FormEvent, manualInput?: string) => {
    if (e) e.preventDefault();
    const textToSend = manualInput || input;
    
    if (!textToSend.trim() || status !== QueryStatus.IDLE) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: textToSend,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setStatus(QueryStatus.SEARCHING_LOCAL);

    try {
      const responseText = await queryLegalAssistant(userMsg.content);
      
      const botMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: responseText,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, botMsg]);
    } catch (error) {
      const errorMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: "عذراً، واجهت مشكلة تقنية. يرجى إعادة المحاولة.",
        isError: true,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorMsg]);
    } finally {
      setStatus(QueryStatus.IDLE);
    }
  };

  return (
    <div className="flex h-screen bg-slate-50 font-tajawal overflow-hidden">
      {/* Mobile Sidebar Overlay */}
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-slate-900/80 backdrop-blur-sm z-40 md:hidden transition-opacity"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}
      
      {/* Mobile Sidebar */}
      <div className={`fixed inset-y-0 right-0 z-50 w-80 bg-slate-900 shadow-2xl transform transition-transform duration-300 ease-out md:hidden ${isSidebarOpen ? 'translate-x-0' : 'translate-x-full'}`}>
        <Sidebar />
      </div>

      {/* Desktop Sidebar */}
      <Sidebar />

      {/* Main Content Wrapper */}
      <div className="flex-1 flex flex-col h-full relative w-full">
        {/* Background Gradients */}
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-indigo-200/20 rounded-full blur-3xl pointer-events-none -translate-y-1/2 z-0"></div>
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-amber-200/20 rounded-full blur-3xl pointer-events-none translate-y-1/2 z-0"></div>

        {/* Header */}
        <header className="h-16 md:h-20 flex-shrink-0 flex items-center justify-between px-4 md:px-6 z-20 bg-white/80 backdrop-blur-md border-b border-white/50 shadow-sm">
          <div className="flex items-center gap-3">
             <div className="md:hidden bg-gradient-to-tr from-indigo-600 to-blue-600 p-2 rounded-xl shadow-lg shadow-indigo-500/20">
                <Scale className="text-white h-5 w-5" />
             </div>
             <div>
                <h2 className="font-bold text-slate-800 text-lg md:text-xl tracking-tight">المحامي الذكي</h2>
                <div className="flex items-center gap-1.5">
                   <span className={`w-2 h-2 rounded-full ${status === QueryStatus.IDLE ? 'bg-emerald-500' : 'bg-amber-500 animate-pulse'}`}></span>
                   <p className="text-[10px] md:text-xs text-slate-500 font-medium">{status === QueryStatus.IDLE ? 'جاهز للاستشارة' : 'جاري المعالجة...'}</p>
                </div>
             </div>
          </div>
          
          <div className="flex items-center gap-2">
            {messages.length > 0 && (
              <>
                <button 
                  onClick={handleExportChat}
                  className="p-2 hover:bg-indigo-50 text-slate-500 hover:text-indigo-600 rounded-lg transition-colors hidden md:flex"
                  title="حفظ المحادثة"
                >
                  <Download size={20} />
                </button>
                <div className="h-6 w-px bg-slate-200 hidden md:block"></div>
                <button 
                  onClick={handleClearChat}
                  className="p-2 hover:bg-red-50 text-slate-400 hover:text-red-500 rounded-lg transition-colors flex items-center gap-2"
                  title="مسح المحادثة"
                >
                  <Trash2 size={20} />
                  <span className="hidden lg:inline text-sm font-medium">جلسة جديدة</span>
                </button>
              </>
            )}
            <button 
              onClick={() => setIsSidebarOpen(true)}
              className="p-2 hover:bg-slate-100 rounded-xl md:hidden text-slate-600 transition-colors"
            >
              <Menu size={24} />
            </button>
          </div>
        </header>

        {/* Chat Area - Scroll Container */}
        <div 
          ref={chatContainerRef}
          onScroll={handleScroll}
          className="flex-1 overflow-y-auto overflow-x-hidden p-4 md:p-8 z-10 scroll-smooth custom-scrollbar relative"
        >
          <div className="max-w-4xl mx-auto min-h-full flex flex-col pb-6">
            
            {messages.length === 0 ? (
              <div className="flex-1 flex flex-col items-center justify-center text-center space-y-6 md:space-y-8 animate-fade-in py-10">
                <div className="relative group cursor-default">
                  <div className="absolute inset-0 bg-gradient-to-tr from-indigo-500 to-amber-500 blur-[50px] opacity-20 rounded-full group-hover:opacity-30 transition-opacity"></div>
                  <div className="bg-white p-6 md:p-8 rounded-[2rem] shadow-xl border border-slate-100 relative transform transition-all duration-500 hover:scale-105 hover:shadow-2xl hover:shadow-indigo-500/10">
                    <Scale size={56} className="text-indigo-600 md:w-20 md:h-20" />
                  </div>
                </div>
                <div className="max-w-lg px-4">
                  <h1 className="text-2xl md:text-4xl font-extrabold text-slate-900 mb-4 tracking-tight">
                    مستشارك القانوني <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-amber-600">الذكي</span>
                  </h1>
                  <p className="text-slate-500 text-base md:text-lg leading-relaxed">
                    نظام متطور يعتمد على الذكاء الاصطناعي والقوانين الأردنية.
                    <br className="hidden md:block"/>
                    ابدأ بسؤال أو اختر من الاقتراحات أدناه.
                  </p>
                </div>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 w-full max-w-3xl mt-6 px-2">
                  {suggestedQuestions.map((q, idx) => (
                    <button
                      key={idx}
                      onClick={() => handleQuickQuestion(q.text)}
                      className="flex flex-col items-center text-center gap-3 p-4 bg-white hover:bg-indigo-50/50 border border-slate-200 hover:border-indigo-200 rounded-2xl shadow-sm hover:shadow-lg hover:-translate-y-1 transition-all duration-300 group"
                    >
                      <div className="bg-indigo-50 text-indigo-600 p-3 rounded-xl group-hover:bg-indigo-600 group-hover:text-white transition-all duration-300 shadow-sm">
                        {q.icon}
                      </div>
                      <span className="text-sm font-semibold text-slate-700 group-hover:text-indigo-900">{q.text}</span>
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              <>
                {messages.map((msg) => (
                  <ChatMessage key={msg.id} message={msg} />
                ))}
                
                {status !== QueryStatus.IDLE && (
                  <div className="flex w-full justify-end mb-6 animate-fade-in">
                     <div className="bg-white p-4 rounded-2xl rounded-tr-none border border-amber-100 shadow-lg shadow-amber-500/5 flex items-center gap-3">
                        <div className="relative">
                          <div className="absolute inset-0 bg-amber-400 blur-lg opacity-30 animate-pulse"></div>
                          <Loader2 className="animate-spin text-amber-500 relative z-10" size={24} />
                        </div>
                        <div className="flex flex-col">
                          <span className="text-sm text-slate-800 font-bold">جاري البحث والتحليل...</span>
                          <span className="text-[10px] text-slate-400">نبحث في {status === QueryStatus.SEARCHING_LOCAL ? 'القوانين المحلية' : 'المصادر المفتوحة'}</span>
                        </div>
                     </div>
                  </div>
                )}
                {/* Invisible element to scroll to */}
                <div ref={messagesEndRef} className="h-px w-full" />
              </>
            )}
          </div>
          
          {/* Scroll To Bottom Fab */}
          {showScrollButton && (
            <button 
              onClick={() => scrollToBottom(true)}
              className="sticky bottom-4 right-4 mr-auto bg-slate-800 text-white p-3 rounded-full shadow-lg hover:bg-indigo-600 transition-all z-30 animate-fade-in flex items-center justify-center"
              title="الذهاب للأسفل"
            >
              <ArrowDown size={20} />
            </button>
          )}
        </div>

        {/* Input Area */}
        <div className="p-4 md:p-6 z-20 bg-white/80 backdrop-blur-md border-t border-slate-200/50">
          <div className="max-w-4xl mx-auto">
            <div className="relative group">
              {/* Gradient Border Glow */}
              <div className={`absolute -inset-0.5 bg-gradient-to-r from-indigo-500 to-amber-500 rounded-2xl opacity-20 group-hover:opacity-40 transition duration-500 blur ${isListening ? 'opacity-70 animate-pulse' : ''}`}></div>
              
              <form onSubmit={(e) => handleSubmit(e)} className="relative flex items-center bg-white rounded-2xl shadow-xl">
                
                {/* Voice Input Button */}
                <button
                  type="button"
                  onClick={toggleListening}
                  className={`absolute right-3 p-2.5 rounded-xl transition-all duration-300 flex items-center justify-center z-10 ${
                    isListening 
                      ? 'bg-red-50 text-red-500 hover:bg-red-100 animate-pulse' 
                      : 'text-slate-400 hover:text-indigo-600 hover:bg-indigo-50'
                  }`}
                  title={isListening ? "إيقاف الاستماع" : "تحدث للكتابة"}
                >
                  {isListening ? <MicOff size={20} /> : <Mic size={20} />}
                </button>

                <input
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder={isListening ? "جاري الاستماع... تحدث الآن" : "اكتب استشارتك القانونية هنا..."}
                  className="w-full bg-transparent text-slate-800 text-base placeholder:text-slate-400 rounded-2xl focus:outline-none block py-4 md:py-5 pl-14 pr-14"
                  disabled={status !== QueryStatus.IDLE}
                />
                
                {/* Submit Button */}
                <button
                  type="submit"
                  disabled={!input.trim() || status !== QueryStatus.IDLE}
                  className={`absolute left-2 md:left-3 p-2 md:p-3 rounded-xl transition-all duration-300 flex items-center justify-center ${
                    input.trim() && status === QueryStatus.IDLE
                      ? 'bg-indigo-600 text-white hover:bg-indigo-700 shadow-lg shadow-indigo-200 scale-100'
                      : 'bg-slate-100 text-slate-300 cursor-not-allowed scale-95'
                  }`}
                >
                  {status !== QueryStatus.IDLE ? <Loader2 size={20} className="animate-spin" /> : <Send size={20} className={input.trim() ? "ml-0.5" : ""} />}
                </button>
              </form>
            </div>
            
            {/* Footer Text */}
            <div className="flex justify-between items-center mt-3 px-2">
              <p className="text-[10px] text-slate-400 font-medium">
                جميع الإجابات لأغراض استرشادية فقط.
              </p>
              {isListening && (
                <span className="text-[10px] text-red-500 font-bold animate-pulse flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-red-500"></span>
                  جاري الاستماع...
                </span>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default App;