export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  isError?: boolean;
  timestamp: Date;
}

export interface LegalDocument {
  id: string;
  title: string;
  category: string;
  content: string;
}

export enum QueryStatus {
  IDLE = 'idle',
  SEARCHING_LOCAL = 'searching_local',
  SEARCHING_WEB = 'searching_web',
  GENERATING = 'generating',
  COMPLETE = 'complete',
  ERROR = 'error'
}