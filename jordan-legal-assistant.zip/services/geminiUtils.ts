import { GoogleGenAI } from "@google/genai";
import { LOCAL_DOCUMENTS } from '../data/documents';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const SYSTEM_INSTRUCTION = `
You are a specialized Legal Assistant for Jordan.
Your primary knowledge base is the provided CONTEXT of Jordanian laws and regulations.

PROTOCOL:
1.  **Analyze** the user's question in Arabic.
2.  **Search** the provided CONTEXT for relevant Articles or Laws.
3.  **If found in Context:**
    *   Return the answer strictly in this format:
        *   **Source:** [Law Name] - [Article Number]
        *   **Text:** "[Exact quote of the article]"
        *   **Explanation:** [A simplified, plain-language explanation of what this means for the user in Arabic].
4.  **If NOT found in Context:**
    *   You must simulate a web search for "lawinjordan.com".
    *   State clearly: "لم أجد النص في المستندات المحلية، ولكن بناءً على البحث في المصادر القانونية الأردنية العامة (lawinjordan.com)..."
    *   Then provide the best possible legal answer based on your general training data regarding Jordanian Law.
5.  **Language:** Always respond in Arabic.
6.  **Tone:** Professional, objective, and legally accurate. Do not give moral judgments.
`;

export async function queryLegalAssistant(userQuery: string): Promise<string> {
  try {
    // 1. Prepare Context (Naive RAG: Dump all docs into context since they are text)
    // In a production app, we would use embeddings/vector search here.
    // For this demo, we concatenate titles and content.
    const contextString = LOCAL_DOCUMENTS.map(doc => 
      `--- DOCUMENT START ---\nTITLE: ${doc.title}\nCATEGORY: ${doc.category}\nCONTENT:\n${doc.content}\n--- DOCUMENT END ---`
    ).join('\n\n');

    const prompt = `
    CONTEXT DOCUMENTS:
    ${contextString}

    USER QUESTION:
    ${userQuery}
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: [
        { role: 'user', parts: [{ text: prompt }] }
      ],
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.3, // Low temperature for factual accuracy
      }
    });

    return response.text || "عذراً، لم أتمكن من استخراج إجابة دقيقة. يرجى إعادة صياغة السؤال.";

  } catch (error) {
    console.error("Gemini API Error:", error);
    return "عذراً، حدث خطأ أثناء الاتصال بالمساعد القانوني. يرجى المحاولة لاحقاً.";
  }
}