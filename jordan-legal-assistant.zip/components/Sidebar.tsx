import React from 'react';
import { Scale, FileText, Gavel, Sparkles, BookOpen } from 'lucide-react';
import { LOCAL_DOCUMENTS } from '../data/documents';

const Sidebar: React.FC = () => {
  return (
    <div className="hidden md:flex flex-col w-80 bg-slate-900 text-white h-screen overflow-hidden border-l border-slate-800 shadow-2xl relative">
      {/* Background Gradient Mesh */}
      <div className="absolute top-0 right-0 w-full h-full bg-gradient-to-b from-indigo-950 via-slate-900 to-slate-950 opacity-90 -z-10"></div>
      <div className="absolute top-0 left-0 w-64 h-64 bg-indigo-600/10 blur-[80px] rounded-full pointer-events-none"></div>

      <div className="p-6 border-b border-white/10 backdrop-blur-sm">
        <div className="flex items-center gap-4">
          <div className="bg-gradient-to-br from-amber-400 to-amber-600 p-2.5 rounded-xl shadow-lg shadow-amber-500/20">
            <Scale className="text-white h-7 w-7" />
          </div>
          <div>
            <h1 className="font-bold text-xl text-white tracking-wide">المستشار القانوني</h1>
            <div className="flex items-center gap-1.5 mt-1">
              <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse"></span>
              <p className="text-[11px] text-slate-300 font-medium">النسخة الذكية 2.0</p>
            </div>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-6">
        <div>
          <div className="flex items-center gap-2 mb-4 px-2">
            <BookOpen size={16} className="text-amber-500" />
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              المكتبة القانونية
            </h3>
          </div>
          
          <div className="space-y-2">
            {LOCAL_DOCUMENTS.map((doc) => (
              <div key={doc.id} className="group relative flex items-start gap-3 p-3.5 rounded-xl hover:bg-white/5 transition-all duration-300 cursor-pointer border border-transparent hover:border-white/10">
                <div className="mt-1 p-1.5 rounded-lg bg-indigo-500/10 text-indigo-400 group-hover:text-indigo-300 group-hover:bg-indigo-500/20 transition-colors">
                   <FileText size={14} />
                </div>
                <div className="flex-1">
                  <h4 className="text-sm font-medium text-slate-200 group-hover:text-white leading-tight transition-colors">
                    {doc.title}
                  </h4>
                  <span className="text-[10px] text-slate-500 mt-1.5 block group-hover:text-slate-400">
                    {doc.category}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-gradient-to-br from-indigo-900/50 to-slate-900/50 rounded-2xl p-5 border border-indigo-500/20 shadow-inner relative overflow-hidden">
           <div className="absolute top-0 left-0 w-20 h-20 bg-amber-500/10 blur-[30px] rounded-full pointer-events-none"></div>
          <div className="flex items-center gap-2 mb-3 text-amber-400 relative z-10">
            <Gavel size={18} />
            <span className="text-sm font-bold">تنويه قانوني هام</span>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed relative z-10 text-justify">
            يعتمد هذا النظام على تقنيات الذكاء الاصطناعي في تحليل النصوص القانونية. النتائج استرشادية ولا تغني عن استشارة محامٍ مزاول.
          </p>
        </div>
      </div>
      
      <div className="p-4 border-t border-white/5 bg-slate-950/30 backdrop-blur-md text-center">
        <div className="flex items-center justify-center gap-2 text-xs text-slate-500 font-medium">
          <Sparkles size={12} className="text-amber-500" />
          <span>مدعوم بتقنيات Gemini AI</span>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;