import React, { useState } from 'react';
import ReactMarkdown from 'react-markdown';
import { Message } from '../types';
import { User, Bot, AlertCircle, ShieldCheck, Copy, Check, Volume2, Share2, StopCircle } from 'lucide-react';

interface ChatMessageProps {
  message: Message;
}

const ChatMessage: React.FC<ChatMessageProps> = ({ message }) => {
  const isUser = message.role === 'user';
  const [isCopied, setIsCopied] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(message.content);
      setIsCopied(true);
      setTimeout(() => setIsCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy text', err);
    }
  };

  const handleSpeak = () => {
    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      return;
    }

    const utterance = new SpeechSynthesisUtterance(message.content);
    utterance.lang = 'ar-SA'; // Prefer Arabic
    utterance.rate = 1.0;
    
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    window.speechSynthesis.speak(utterance);
    setIsSpeaking(true);
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'استشارة قانونية - المحامي الذكي',
          text: message.content,
        });
      } catch (err) {
        console.log('Error sharing', err);
      }
    } else {
      handleCopy(); // Fallback to copy
    }
  };

  return (
    <div className={`flex w-full mb-8 animate-fade-in ${isUser ? 'justify-start' : 'justify-end'}`}>
      <div className={`flex max-w-[95%] md:max-w-[85%] ${isUser ? 'flex-row' : 'flex-row-reverse'} items-end gap-3`}>
        
        {/* Avatar */}
        <div className={`flex-shrink-0 h-10 w-10 rounded-full flex items-center justify-center shadow-md ${
          isUser 
            ? 'bg-gradient-to-tr from-indigo-600 to-blue-500 text-white' 
            : 'bg-gradient-to-tr from-amber-500 to-yellow-600 text-white'
        }`}>
          {isUser ? <User size={20} /> : <ShieldCheck size={22} />}
        </div>

        {/* Message Bubble Container */}
        <div className="flex flex-col relative group">
          {/* Bubble */}
          <div className={`flex flex-col p-5 shadow-sm relative transition-all duration-300 ${
            isUser 
              ? 'bg-white text-slate-800 rounded-2xl rounded-bl-none border border-slate-100 hover:shadow-md' 
              : 'bg-white text-slate-800 rounded-2xl rounded-br-none border-t-4 border-t-amber-500 shadow-amber-500/5 hover:shadow-lg hover:shadow-amber-500/10'
          } ${message.isError ? 'bg-red-50 border border-red-100 text-red-800' : ''}`}>
            
            {message.isError && (
              <div className="flex items-center gap-2 mb-2 text-red-600 font-bold">
                <AlertCircle size={16} />
                <span>خطأ في المعالجة</span>
              </div>
            )}

            <div className="prose prose-sm md:prose-base max-w-none font-tajawal rtl text-slate-700 leading-relaxed" dir="rtl">
              <ReactMarkdown
                components={{
                  h3: ({node, ...props}) => <h3 className="text-indigo-700 font-bold text-lg mt-4 mb-2" {...props} />,
                  strong: ({node, ...props}) => <strong className="text-slate-900 font-extrabold" {...props} />,
                  ul: ({node, ...props}) => <ul className="list-disc list-inside space-y-1 my-2 bg-slate-50 p-3 rounded-lg border border-slate-100" {...props} />,
                  a: ({node, ...props}) => <a className="text-indigo-600 underline hover:text-indigo-800" {...props} />
                }}
              >
                {message.content}
              </ReactMarkdown>
            </div>
            
            {/* Footer Metadata */}
            <div className={`flex items-center justify-between mt-3 pt-2 ${!isUser && 'border-t border-slate-100'}`}>
               <span className="text-[10px] font-medium opacity-50 flex items-center gap-1">
                {message.timestamp.toLocaleTimeString('ar-JO', { hour: '2-digit', minute: '2-digit' })}
                {!isUser && !message.isError && <span>• تم التدقيق آلياً</span>}
              </span>

              {/* Action Buttons (Only for Assistant or lengthy User messages) */}
              {!message.isError && (
                <div className="flex items-center gap-1">
                  
                  {/* Read Aloud Button */}
                  <button 
                    onClick={handleSpeak}
                    className={`p-1.5 rounded-full transition-colors ${isSpeaking ? 'bg-red-100 text-red-600' : 'hover:bg-slate-100 text-slate-400 hover:text-indigo-600'}`}
                    title={isSpeaking ? "إيقاف القراءة" : "قراءة النص"}
                  >
                    {isSpeaking ? <StopCircle size={14} /> : <Volume2 size={14} />}
                  </button>

                  {/* Share Button */}
                  <button 
                    onClick={handleShare}
                    className="p-1.5 rounded-full hover:bg-slate-100 text-slate-400 hover:text-indigo-600 transition-colors"
                    title="مشاركة"
                  >
                    <Share2 size={14} />
                  </button>

                  {/* Copy Button */}
                  <button 
                    onClick={handleCopy}
                    className="p-1.5 rounded-full hover:bg-slate-100 text-slate-400 hover:text-emerald-600 transition-colors"
                    title="نسخ النص"
                  >
                    {isCopied ? <Check size={14} className="text-emerald-500" /> : <Copy size={14} />}
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChatMessage;