import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Translation, Language, AnalysisResult } from '../types';
import { LoadingSpinner, BoltIcon, ErrorIcon, ChevronDownIcon } from './Icons';
// FIX: Replaced getStrictAnalysis with getQuantumAnalysis as it is the correct available function.
import { getQuantumAnalysis } from '../services/geminiService';
import { fetchHistoricalKlines, ApiError } from '../services/backtestService';
import { CandleChart } from './CandleChart';
// FIX: StrictAnalysisDisplay is obsolete and was removed. An inline component will be used instead.

const SYMBOLS_TO_SCAN = [
    'BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'XRPUSDT', 'DOGEUSDT', 'ADAUSDT', 'BNBUSDT',
    'AVAXUSDT', 'LINKUSDT', 'DOTUSDT', 'TRXUSDT', 'MATICUSDT', 'SHIBUSDT',
    'LTCUSDT', 'BCHUSDT', 'UNIUSDT', 'NEARUSDT', 'ATOMUSDT', 'INJUSDT', 'OPUSDT',
    'ARBUSDT', 'RUNEUSDT', 'AAVEUSDT', 'TIAUSDT', 'PEPEUSDT', 'WIFUSDT'
];

interface AiTraderPanelProps {
    t: Translation;
    language: Language;
}


const QuantumSignalDetails: React.FC<{ signal: AnalysisResult; t: Translation; }> = ({ signal, t }) => {
    return (
        <div className="space-y-4 text-sm">
            {signal.analysis_summary && (
                <div className="bg-brand-surface/70 p-3 rounded-lg">
                    <h4 className="font-bold text-brand-primary mb-2">{t.finalVerdict}</h4>
                    <p className="text-brand-text-secondary leading-relaxed">{signal.analysis_summary}</p>
                </div>
            )}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {signal.bullish_case && (
                    <div className="bg-brand-bg/40 p-3 rounded-lg border-l-2 border-green-500">
                         <h4 className="font-bold text-green-400 mb-2">{t.bullishCase}</h4>
                         <p className="text-brand-text-secondary leading-relaxed">{signal.bullish_case}</p>
                    </div>
                )}
                 {signal.bearish_case && (
                    <div className="bg-brand-bg/40 p-3 rounded-lg border-l-2 border-red-500">
                         <h4 className="font-bold text-red-400 mb-2">{t.bearishCase}</h4>
                         <p className="text-brand-text-secondary leading-relaxed">{signal.bearish_case}</p>
                    </div>
                )}
            </div>
            <div className="bg-brand-surface/70 p-3 rounded-lg grid grid-cols-2 md:grid-cols-4 gap-2">
                <div><span className="text-brand-text-secondary">{t.entryPrice}:</span> <span className="font-semibold">${signal.possible_entry?.toFixed(3)}</span></div>
                <div><span className="text-brand-text-secondary">{t.stopLoss}:</span> <span className="font-semibold text-red-400">${signal.stop_loss?.toFixed(3)}</span></div>
                <div><span className="text-brand-text-secondary">{t.takeProfit}:</span> <span className="font-semibold text-green-400">${signal.take_profit?.toFixed(3)}</span></div>
                <div><span className="text-brand-text-secondary">{t.riskRewardRatio}:</span> <span className="font-semibold">{signal.rr_ratio?.toFixed(2)}</span></div>
            </div>
        </div>
    );
};

const SignalCard: React.FC<{
    signal: AnalysisResult;
    t: Translation;
    language: Language;
    isExpanded: boolean;
    onToggle: () => void;
}> = ({ signal, t, language, isExpanded, onToggle }) => {
    
    // FIX: Use possible_position from Quantum Analysis instead of trade_type.
    const isLong = signal.possible_position === 'Long';
    const borderColor = isLong ? 'border-l-green-400' : 'border-l-red-400';
    const tradeTypeColor = isLong ? 'text-green-400' : 'text-red-400';
    const positionText = isLong ? t.long : t.short;

    return (
        <div className={`glass-card p-4 animate-fade-in border-l-4 ${borderColor}`}>
            <button onClick={onToggle} className="w-full flex justify-between items-center text-left">
                <div className="flex items-center gap-4">
                     <div className="flex-shrink-0">
                        <div className={`w-2 h-10 rounded-full ${isLong ? 'bg-green-400' : 'bg-red-400'}`}></div>
                    </div>
                    <div>
                        <h3 className="text-lg font-bold">{signal.symbol}</h3>
                        <p className={`text-sm font-semibold ${tradeTypeColor}`}>{positionText}</p>
                    </div>
                </div>
                <div className="flex items-center gap-4">
                    <div className="text-right">
                        <p className="text-xs text-brand-text-secondary">{t.confidence}</p>
                        <p className="font-bold text-brand-primary">{((signal.confidence || 0) * 100).toFixed(0)}%</p>
                    </div>
                    <ChevronDownIcon className={`w-6 h-6 text-brand-text-secondary transition-transform duration-300 ${isExpanded ? 'rotate-180' : ''}`} />
                </div>
            </button>

            {isExpanded && (
                <div className="mt-4 pt-4 border-t border-brand-border animate-fade-in space-y-4">
                    <QuantumSignalDetails signal={signal} t={t} />
                    {signal.klineData && <CandleChart data={signal.klineData} language={language} />}
                </div>
            )}
        </div>
    );
}

export const AiTraderPanel: React.FC<AiTraderPanelProps> = ({ t, language }) => {
    const [isScanning, setIsScanning] = useState(false);
    const [signals, setSignals] = useState<AnalysisResult[]>([]);
    const [statusMessage, setStatusMessage] = useState<string>(t.statusIdle);
    const [error, setError] = useState<string | null>(null);
    const [expandedSignalId, setExpandedSignalId] = useState<string | null>(null);

    const isScanningRef = useRef(false);

    useEffect(() => {
        return () => { isScanningRef.current = false; };
    }, []);

    const runScan = useCallback(async () => {
        setSignals([]);
        setError(null);
        let foundSignalsCount = 0;
        let newSignals: AnalysisResult[] = [];

        for (const symbol of SYMBOLS_TO_SCAN) {
            if (!isScanningRef.current) break;

            setStatusMessage(t.statusScanningSymbol.replace('{symbol}', symbol));
            try {
                const klines = await fetchHistoricalKlines(symbol, '1h');
                if (klines && klines.length >= 200) {
                    // FIX: Call getQuantumAnalysis and adjust the success condition.
                    const result = await getQuantumAnalysis(klines, symbol, language);
                    if (result && (result.possible_position === 'Long' || result.possible_position === 'Short') && isScanningRef.current) {
                        const signalWithData: AnalysisResult = {
                            ...result,
                            id: symbol,
                            symbol: symbol,
                            klineData: klines,
                        };
                        newSignals.push(signalWithData);
                        setSignals([...newSignals]); // Update state incrementally
                        foundSignalsCount++;
                    }
                }
                // Add a small delay to avoid hitting API rate limits and to make the scan feel smoother.
                if (isScanningRef.current) await new Promise(resolve => setTimeout(resolve, 1000)); 

            } catch (err) {
                console.error(`Error scanning ${symbol}:`, err);
                if (err instanceof ApiError && isScanningRef.current) {
                    setError(`Could not fetch data for ${symbol}. Skipping.`);
                    await new Promise(resolve => setTimeout(resolve, 2000));
                    setError(null);
                } else if (isScanningRef.current) {
                     setError(`Analysis failed for ${symbol}. Skipping.`);
                     await new Promise(resolve => setTimeout(resolve, 2000));
                     setError(null);
                }
            }
        }

        if (isScanningRef.current) {
            setStatusMessage(t.scanComplete.replace('{count}', foundSignalsCount.toString()));
        }

        isScanningRef.current = false;
        setIsScanning(false);
    }, [language, t]);

    const handleStartScan = () => {
        isScanningRef.current = true;
        setIsScanning(true);
        setStatusMessage(t.statusScanning);
        runScan();
    };

    const handleStopScan = () => {
        isScanningRef.current = false;
        setIsScanning(false);
        setStatusMessage(t.statusIdle);
    };
    
    const handleToggleSignal = (signalId: string) => {
        setExpandedSignalId(prevId => prevId === signalId ? null : signalId);
    };

    return (
        <div className="space-y-8">
            <div className="glass-card p-6">
                <h2 className="text-2xl font-bold">{t.aiAssistantTitle}</h2>
                <p className="text-brand-text-secondary mt-2">{t.aiAssistantDescription}</p>
            </div>

            <div className="glass-card p-6">
                 <h3 className="text-xl font-bold mb-2">{t.traderControlsTitle}</h3>
                 <div className="flex items-center justify-between mb-4">
                    <span className="text-sm font-medium">{t.botStatus}:</span>
                    <span className="text-sm font-semibold bg-brand-surface px-3 py-1 rounded-full flex items-center gap-2">
                       {isScanning && <LoadingSpinner className="w-4 h-4 text-brand-primary -ml-1 mr-1" />}
                       {statusMessage}
                    </span>
                 </div>
                 <button 
                    onClick={isScanning ? handleStopScan : handleStartScan}
                    className={`w-full font-bold py-3 px-4 rounded-lg transition duration-300 flex items-center justify-center text-lg ${isScanning ? 'bg-brand-danger hover:bg-red-700' : 'bg-brand-success hover:bg-green-700'}`}
                >
                   <BoltIcon className="w-5 h-5 me-2 rtl:ms-2"/>
                   {isScanning ? t.stopTrader : t.startTrader}
                </button>
                 {error && (
                    <div className="mt-4 bg-red-900/50 border border-brand-danger text-red-300 px-3 py-2 rounded-lg text-sm flex items-start space-x-2 rtl:space-x-reverse" role="alert">
                        <ErrorIcon className="w-5 h-5 mt-0.5" />
                        <span>{error}</span>
                    </div>
                )}
            </div>

            <div className="space-y-4">
                {signals.map((signal) => (
                    <SignalCard 
                        key={signal.id} 
                        signal={signal} 
                        t={t} 
                        language={language}
                        isExpanded={expandedSignalId === signal.id}
                        onToggle={() => handleToggleSignal(signal.id!)}
                    />
                ))}
                
                {!isScanning && signals.length === 0 && (statusMessage.includes(t.scanComplete.split('.')[0]) || statusMessage === t.statusIdle) && (
                    <div className="text-center py-16 glass-card">
                        <p className="text-brand-text-secondary">{t.noSignalsFound}</p>
                    </div>
                )}
            </div>
            
            <div className="text-center text-xs text-brand-text-secondary mt-4">
                <p>{t.aiTraderDisclaimer}</p>
            </div>
        </div>
    );
};
