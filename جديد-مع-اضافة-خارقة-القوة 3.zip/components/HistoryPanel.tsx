import React, { useState, useMemo } from 'react';
import { SavedSignal, Translation, Language } from '../types';
import { updateSignalStatus, deleteSignal } from '../services/authService';
import { CheckCircleIcon, XCircleIcon, TrashIcon, SearchIcon, HistoryIcon, ChartIcon } from './Icons';

interface HistoryPanelProps {
    history: SavedSignal[];
    setHistory: (history: SavedSignal[]) => void;
    t: Translation;
    language: Language;
}

const StatCard: React.FC<{ label: string; value: string | number; color?: string }> = ({ label, value, color = 'text-brand-text-primary' }) => (
    <div className="bg-brand-surface/50 p-4 rounded-lg border border-brand-border text-center">
        <p className="text-sm text-brand-text-secondary mb-1">{label}</p>
        <p className={`text-2xl font-bold ${color}`}>{value}</p>
    </div>
);

export const HistoryPanel: React.FC<HistoryPanelProps> = ({ history, setHistory, t, language }) => {
    const [filterSymbol, setFilterSymbol] = useState('');
    const [filterDate, setFilterDate] = useState('');

    const filteredHistory = useMemo(() => {
        return history.filter(signal => {
            const matchSymbol = filterSymbol ? (signal.symbol || '').toLowerCase().includes(filterSymbol.toLowerCase()) : true;
            const signalDate = new Date(signal.timestamp).toISOString().split('T')[0];
            const matchDate = filterDate ? signalDate === filterDate : true;
            return matchSymbol && matchDate;
        });
    }, [history, filterSymbol, filterDate]);

    const stats = useMemo(() => {
        const total = filteredHistory.length;
        const wins = filteredHistory.filter(s => s.status === 'Win').length;
        const losses = filteredHistory.filter(s => s.status === 'Loss').length;
        const winRate = total > 0 && (wins + losses) > 0 ? (wins / (wins + losses)) * 100 : 0;
        return { total, wins, losses, winRate };
    }, [filteredHistory]);

    const handleStatusUpdate = (id: string, status: 'Win' | 'Loss') => {
        const updated = updateSignalStatus(id, status);
        setHistory(updated);
    };

    const handleDelete = (id: string) => {
        if (confirm(t.deleteSignal + '?')) {
            const updated = deleteSignal(id);
            setHistory(updated);
        }
    };

    return (
        <div className="space-y-6 animate-fade-in">
            <div className="glass-card p-6">
                <div className="flex items-center gap-3 mb-4">
                    <HistoryIcon className="w-8 h-8 text-brand-primary" />
                    <h2 className="text-2xl font-bold">{t.historyTitle}</h2>
                </div>
                <p className="text-brand-text-secondary mb-6">{t.historyDescription}</p>

                {/* Statistics */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
                    <StatCard label={t.winRate} value={`${stats.winRate.toFixed(1)}%`} color={stats.winRate >= 50 ? 'text-green-400' : 'text-red-400'} />
                    <StatCard label={t.totalSignals} value={stats.total} />
                    <StatCard label={t.wins} value={stats.wins} color="text-green-400" />
                    <StatCard label={t.losses} value={stats.losses} color="text-red-400" />
                </div>

                {/* Filters */}
                <div className="flex flex-col md:flex-row gap-4 mb-6">
                    <div className="relative flex-grow">
                        <input
                            type="text"
                            placeholder={t.filterBySymbol}
                            value={filterSymbol}
                            onChange={(e) => setFilterSymbol(e.target.value)}
                            className="w-full bg-brand-surface border border-brand-border rounded-lg p-3 ps-10 rtl:pr-10 focus:ring-2 focus:ring-primary focus:outline-none"
                        />
                        <SearchIcon className="w-5 h-5 absolute top-1/2 left-3 rtl:left-auto rtl:right-3 transform -translate-y-1/2 text-brand-text-secondary" />
                    </div>
                    <div className="md:w-1/3">
                         <input
                            type="date"
                            value={filterDate}
                            onChange={(e) => setFilterDate(e.target.value)}
                            className="w-full bg-brand-surface border border-brand-border rounded-lg p-3 focus:ring-2 focus:ring-primary focus:outline-none text-brand-text-primary"
                        />
                    </div>
                </div>

                {/* Table */}
                <div className="overflow-x-auto">
                    {filteredHistory.length > 0 ? (
                        <table className="w-full text-left rtl:text-right border-collapse">
                            <thead>
                                <tr className="border-b border-brand-border text-brand-text-secondary text-sm">
                                    <th className="p-3">{t.chart}</th>
                                    <th className="p-3">{t.entryPrice}</th>
                                    <th className="p-3">{t.position}</th>
                                    <th className="p-3">Result</th>
                                    <th className="p-3 text-center">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {filteredHistory.map((signal) => (
                                    <tr key={signal.id} className="border-b border-brand-border hover:bg-brand-surface/30 transition-colors group">
                                        <td className="p-3">
                                            <div>
                                                <p className="font-bold text-brand-text-primary">{signal.symbol || 'Unknown'}</p>
                                                <p className="text-xs text-brand-text-secondary">{new Date(signal.timestamp).toLocaleString(language === 'ar' ? 'ar-EG' : 'en-US')}</p>
                                            </div>
                                        </td>
                                        <td className="p-3 font-mono text-sm">
                                            <p><span className="text-brand-text-secondary">Entry:</span> ${signal.possible_entry?.toFixed(4)}</p>
                                            <p><span className="text-green-400">TP:</span> ${signal.take_profit?.toFixed(4)}</p>
                                            <p><span className="text-red-400">SL:</span> ${signal.stop_loss?.toFixed(4)}</p>
                                        </td>
                                        <td className="p-3">
                                            <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-bold ${signal.possible_position === 'Long' ? 'bg-green-500/20 text-green-300' : 'bg-red-500/20 text-red-300'}`}>
                                                {signal.possible_position === 'Long' ? <CheckCircleIcon className="w-3 h-3"/> : <XCircleIcon className="w-3 h-3"/>}
                                                {signal.possible_position}
                                            </span>
                                        </td>
                                        <td className="p-3">
                                            {signal.status === 'Pending' ? (
                                                <div className="flex gap-2">
                                                    <button 
                                                        onClick={() => handleStatusUpdate(signal.id, 'Win')}
                                                        className="p-1 rounded hover:bg-green-500/20 text-brand-text-secondary hover:text-green-400 transition-colors"
                                                        title={t.markAsWin}
                                                    >
                                                        <CheckCircleIcon className="w-6 h-6" />
                                                    </button>
                                                    <button 
                                                        onClick={() => handleStatusUpdate(signal.id, 'Loss')}
                                                        className="p-1 rounded hover:bg-red-500/20 text-brand-text-secondary hover:text-red-400 transition-colors"
                                                        title={t.markAsLoss}
                                                    >
                                                        <XCircleIcon className="w-6 h-6" />
                                                    </button>
                                                </div>
                                            ) : (
                                                <span className={`font-bold ${signal.status === 'Win' ? 'text-green-400' : 'text-red-400'}`}>
                                                    {signal.status === 'Win' ? t.statusWin : t.statusLoss}
                                                </span>
                                            )}
                                        </td>
                                        <td className="p-3 text-center">
                                            <button 
                                                onClick={() => handleDelete(signal.id)}
                                                className="text-brand-text-secondary hover:text-brand-danger transition-colors p-2"
                                                title={t.deleteSignal}
                                            >
                                                <TrashIcon className="w-5 h-5" />
                                            </button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    ) : (
                        <div className="text-center py-12">
                             <ChartIcon className="w-16 h-16 text-brand-border mx-auto mb-3" />
                             <p className="text-brand-text-secondary">{t.noSignalsFound}</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};