import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { Language, NewsArticle, Translation } from '../types';
import { fetchLatestNews, searchNews } from '../services/newsService';
import { LoadingSpinner, ErrorIcon, NewspaperIcon, SearchIcon } from './Icons';

interface CryptoNewsPanelProps {
    t: Translation;
    language: Language;
}

const NewsArticleCard: React.FC<{ article: NewsArticle, t: Translation }> = ({ article, t }) => {
    const sentimentColor = useMemo(() => {
        switch (article.sentiment) {
            case 'Bullish': return 'bg-green-500/20 text-green-300 border-green-500/30';
            case 'Bearish': return 'bg-red-500/20 text-red-300 border-red-500/30';
            default: return 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30';
        }
    }, [article.sentiment]);

    const sentimentText = useMemo(() => {
        switch (article.sentiment) {
            case 'Bullish': return t.sentimentBullish;
            case 'Bearish': return t.sentimentBearish;
            default: return t.sentimentNeutral;
        }
    }, [article.sentiment, t]);

    return (
        <a 
            href={article.url} 
            target="_blank" 
            rel="noopener noreferrer" 
            className="block glass-card p-4 hover:border-brand-primary/50 transition-all duration-300 hover:bg-brand-surface/60 group"
        >
            <div className="flex justify-between items-start gap-4">
                <h3 className="text-lg font-bold text-brand-text-primary group-hover:text-brand-primary transition-colors">{article.title}</h3>
                <span className={`text-xs font-semibold px-2.5 py-1 rounded-full whitespace-nowrap ${sentimentColor}`}>{sentimentText}</span>
            </div>
            <div className="text-xs text-brand-text-secondary my-2 flex items-center gap-2">
                <span className="font-medium text-brand-text-primary">{article.source}</span> 
                <span>&bull;</span> 
                <span>{new Date(article.timestamp).toLocaleString()}</span>
            </div>
            <p className="text-sm text-brand-text-secondary leading-relaxed">
                {article.summary}
            </p>
        </a>
    );
};

export const CryptoNewsPanel: React.FC<CryptoNewsPanelProps> = ({ t, language }) => {
    const [articles, setArticles] = useState<NewsArticle[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [searchTerm, setSearchTerm] = useState('');
    
    const trendingTopics = useMemo(() => [
        { name: language === 'ar' ? 'بيتكوين' : 'Bitcoin', query: 'Bitcoin Price Today' },
        { name: language === 'ar' ? 'إيثريوم' : 'Ethereum', query: 'Ethereum News' },
        { name: language === 'ar' ? 'العملات البديلة' : 'Altcoins', query: 'Altcoin Season' },
        { name: language === 'ar' ? 'تنظيم' : 'Regulation', query: 'Crypto Regulation' },
    ], [language]);

    const fetchNews = useCallback(async (query?: string) => {
        setIsLoading(true);
        setError(null);
        try {
            const newsData = query ? await searchNews(query, language) : await fetchLatestNews(language);
            setArticles(newsData);
        } catch (err) {
            console.error(err);
            const errorMessage = (err instanceof Error) ? err.message : t.errorNewsFailed;
            if (errorMessage.includes('API key not valid')) {
                 setError(t.errorApiKey);
            } else {
                 setError(t.errorNewsFailed);
            }
        } finally {
            setIsLoading(false);
        }
    }, [language, t]);

    useEffect(() => {
        fetchNews();
    }, [fetchNews, language]);

    const handleSearch = (e: React.FormEvent) => {
        e.preventDefault();
        if(searchTerm.trim()) {
            fetchNews(searchTerm.trim());
        }
    };

    const handleTopicClick = (query: string) => {
        setSearchTerm(query);
        fetchNews(query);
    }
    
    return (
        <div className="space-y-8">
            <div className="glass-card p-6">
                <div className="flex items-center gap-3 mb-2">
                    <h2 className="text-2xl font-bold">{t.cryptoNewsTitle}</h2>
                    <span className="bg-red-500/20 text-red-400 text-xs px-2 py-0.5 rounded animate-pulse font-mono">LIVE</span>
                </div>
                <p className="text-brand-text-secondary mb-6">{t.cryptoNewsDescription}</p>
                 <form onSubmit={handleSearch} className="flex flex-col sm:flex-row items-center gap-2">
                    <div className="relative w-full">
                        <input
                            type="text"
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            placeholder={t.searchNewsPlaceholder}
                            className="w-full bg-brand-surface border border-brand-border rounded-lg p-3 ps-10 rtl:pr-10 focus:ring-2 focus:ring-brand-primary focus:outline-none text-md"
                        />
                        <SearchIcon className="w-5 h-5 absolute top-1/2 left-3 rtl:left-auto rtl:right-3 transform -translate-y-1/2 text-brand-text-secondary"/>
                    </div>
                    <button
                        type="submit"
                        disabled={isLoading}
                        className="w-full sm:w-auto main-button bg-brand-primary hover:bg-brand-secondary text-white font-bold py-3 px-6 rounded-lg transition duration-300 disabled:bg-gray-500 disabled:cursor-not-allowed flex items-center justify-center"
                    >
                        {isLoading ? <LoadingSpinner className="h-5 w-5 -ml-0 mr-0"/> : t.search}
                    </button>
                </form>
                 <div className="mt-4">
                    <h3 className="text-sm font-semibold text-brand-text-secondary mb-2">{t.trendingTopics}</h3>
                    <div className="flex flex-wrap gap-2">
                        {trendingTopics.map(topic => (
                             <button 
                                key={topic.query}
                                onClick={() => handleTopicClick(topic.query)}
                                className="bg-brand-surface hover:bg-brand-border text-brand-text-secondary text-sm font-medium py-1.5 px-3 rounded-full transition-colors"
                             >
                                 {topic.name}
                             </button>
                        ))}
                    </div>
                </div>
            </div>

            <div className="min-h-[400px]">
                {isLoading && (
                    <div className="flex flex-col items-center justify-center text-center p-8">
                        <LoadingSpinner className="w-8 h-8 -ml-1 mr-3 text-brand-primary" />
                        <p className="mt-2">{t.fetchingNews}</p>
                    </div>
                )}
                {error && (
                    <div className="bg-red-900/50 border border-brand-danger text-red-300 px-4 py-3 rounded-lg flex items-center justify-center" role="alert">
                        <ErrorIcon className="h-5 w-5 me-2 rtl:ms-2"/>
                        <span>{error}</span>
                    </div>
                )}
                {!isLoading && !error && articles.length === 0 && (
                     <div className="flex flex-col items-center justify-center text-center p-8 glass-card">
                         <NewspaperIcon className="w-16 h-16 text-brand-border mb-4"/>
                        <h3 className="text-xl font-bold">{t.noNewsFound}</h3>
                    </div>
                )}
                {!isLoading && !error && articles.length > 0 && (
                    <div className="grid grid-cols-1 gap-4">
                        {articles.map((article, idx) => <NewsArticleCard key={article.id || idx} article={article} t={t} />)}
                    </div>
                )}
            </div>
        </div>
    );
};