import React, { useState, useMemo, memo } from 'react';
import { AnalysisResult, Language, Translation, Kline, WhaleActivity, User } from '../types';
import { ChartIcon, CheckCircleIcon, DocumentTextIcon, ExclamationIcon, XCircleIcon, CalculatorIcon, ClipboardIcon, StructureIcon, TargetIcon, BeakerIcon, HistoryIcon } from './Icons';
import { CandleChart } from './CandleChart';


const SentimentMeter: React.FC<{ score: number; t: Translation }> = ({ score, t }) => {
    const sentiment = useMemo(() => {
        if (score <= 20) return { label: t.extremeFear, color: 'bg-red-600' };
        if (score <= 40) return { label: t.fear, color: 'bg-orange-500' };
        if (score <= 60) return { label: t.neutral, color: 'bg-yellow-500' };
        if (score <= 80) return { label: t.greed, color: 'bg-green-500' };
        return { label: t.extremeGreed, color: 'bg-green-400' };
    }, [score, t]);

    return (
        <div className="bg-brand-surface/50 p-4 rounded-lg border border-brand-border">
            <h3 className="text-lg font-bold mb-3 text-center">{t.marketSentiment}</h3>
            <div className="w-full bg-brand-bg rounded-full h-2.5">
                <div className={`${sentiment.color} h-2.5 rounded-full transition-all duration-500`} style={{ width: `${score}%` }}></div>
            </div>
            <p className="text-center font-semibold mt-2">{sentiment.label} ({score})</p>
        </div>
    );
};

// Whale Radar for the Super Power Feature
const WhaleRadar: React.FC<{ activity: WhaleActivity; t: Translation }> = ({ activity, t }) => {
    const { score, action, warning } = activity;
    
    const radarColor = score > 70 ? 'text-red-400' : (score > 40 ? 'text-yellow-400' : 'text-blue-400');
    const borderColor = score > 70 ? 'border-red-500' : (score > 40 ? 'border-yellow-500' : 'border-blue-500');

    let actionText = action;
    if (action === 'Accumulation') actionText = t.accumulation;
    if (action === 'Distribution') actionText = t.distribution;
    if (action === 'Dormant') actionText = t.dormant;

    return (
        <div className={`bg-brand-surface/50 p-4 rounded-lg border-2 ${borderColor} relative overflow-hidden`}>
            <div className="absolute top-0 right-0 p-2 opacity-10">
                 <BeakerIcon className="w-24 h-24" />
            </div>
            <h3 className="text-lg font-bold mb-4 flex items-center z-10 relative">
                <span className="text-2xl me-2">🐋</span> {t.whaleRadar}
            </h3>
            
            <div className="grid grid-cols-2 gap-4 relative z-10">
                <div>
                    <p className="text-xs text-brand-text-secondary uppercase">{t.whaleScore}</p>
                    <div className="flex items-end gap-1">
                        <span className={`text-3xl font-black ${radarColor}`}>{score}</span>
                        <span className="text-sm text-brand-text-secondary mb-1">/100</span>
                    </div>
                </div>
                <div>
                     <p className="text-xs text-brand-text-secondary uppercase">{t.whaleAction}</p>
                     <p className="text-xl font-bold text-brand-text-primary">{actionText}</p>
                </div>
            </div>

            {warning && warning !== 'None' && (
                <div className="mt-4 bg-red-900/40 p-2 rounded border border-red-500/50 flex items-center gap-2 animate-pulse relative z-10">
                    <ExclamationIcon className="w-5 h-5 text-red-400" />
                    <p className="text-sm text-red-300 font-bold">{t.manipulationWarning}: {warning}</p>
                </div>
            )}
        </div>
    );
};


const LevelItem: React.FC<{ label: string; value: string | number; icon: React.ReactNode }> = ({ label, value, icon }) => (
    <div className="bg-brand-bg/50 p-3 rounded-lg">
        <h4 className="text-xs font-semibold text-brand-text-secondary mb-1 flex items-center gap-2">{icon} {label}</h4>
        <p className="text-sm font-mono">{typeof value === 'number' ? `$${value.toFixed(3)}` : value}</p>
    </div>
);

const StructuralLevelsCard: React.FC<{ result: AnalysisResult; t: Translation; }> = ({ result, t }) => {
    return (
        <div className="bg-brand-surface/50 p-4 rounded-lg border border-brand-border">
            <h3 className="text-lg font-bold mb-4 flex items-center"><StructureIcon className="w-6 h-6 me-2 rtl:ms-2 text-brand-primary"/>{t.marketStructure}</h3>
            <div className="space-y-3">
                {result.market_structure && (
                     <div className="flex justify-between items-center bg-brand-bg/50 p-3 rounded-lg">
                        <span className="text-sm font-semibold">{result.market_structure === 'Bullish' ? '🔼' : '🔽'} {result.market_structure}</span>
                        <span className={`text-xs font-bold px-2 py-1 rounded-md ${result.market_structure === 'Bullish' ? 'bg-green-500/20 text-green-300' : 'bg-red-500/20 text-red-300'}`}>
                            {result.market_structure_reason === 'BOS' ? t.breakOfStructure : t.changeOfCharacter}
                        </span>
                    </div>
                )}
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    {result.key_support && <LevelItem label={t.support} value={result.key_support} icon={<div className="w-3 h-3 rounded-full bg-green-500/50 border border-green-400" />} />}
                    {result.key_resistance && <LevelItem label={t.resistance} value={result.key_resistance} icon={<div className="w-3 h-3 rounded-full bg-red-500/50 border border-red-400" />} />}
                    {result.point_of_control && <LevelItem label={t.pointOfControl} value={result.point_of_control} icon={<TargetIcon className="w-4 h-4 text-yellow-400" />} />}
                    {result.order_block && <LevelItem label={t.orderBlock} value={`${result.order_block.start_price.toFixed(3)} - ${result.order_block.end_price.toFixed(3)}`} icon={<div className={`w-3 h-3 rounded-sm ${result.order_block.type === 'Bullish' ? 'bg-blue-400' : 'bg-purple-400'}`} />} />}
                    {result.fair_value_gap && <LevelItem label={t.fairValueGap} value={`${result.fair_value_gap.start_price.toFixed(3)} - ${result.fair_value_gap.end_price.toFixed(3)}`} icon={<div className="w-3 h-3 rounded-sm bg-gray-500/50 border border-gray-400" />} />}
                </div>
            </div>
        </div>
    );
};

const BullBearAnalysis: React.FC<{ result: AnalysisResult; t: Translation }> = ({ result, t }) => {
    return (
         <div className="bg-brand-surface/50 p-4 rounded-lg border border-brand-border space-y-4">
            {result.liquidity_analysis && (
                 <div>
                    <h4 className="font-bold text-brand-primary mb-2">{t.liquidityAnalysis}</h4>
                    <p className="text-sm text-brand-text-secondary leading-relaxed">{result.liquidity_analysis}</p>
                 </div>
            )}
             <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {result.bullish_case && (
                    <div className="bg-brand-bg/40 p-3 rounded-lg border-l-2 border-green-500">
                         <h4 className="font-bold text-green-400 mb-2">{t.bullishCase}</h4>
                         <p className="text-sm text-brand-text-secondary leading-relaxed">{result.bullish_case}</p>
                    </div>
                )}
                 {result.bearish_case && (
                    <div className="bg-brand-bg/40 p-3 rounded-lg border-l-2 border-red-500">
                         <h4 className="font-bold text-red-400 mb-2">{t.bearishCase}</h4>
                         <p className="text-sm text-brand-text-secondary leading-relaxed">{result.bearish_case}</p>
                    </div>
                )}
            </div>
        </div>
    );
};

interface ResultsPanelProps {
    result: AnalysisResult | null;
    isLoading: boolean;
    t: Translation;
    analysisSource: 'file' | 'symbol' | null;
    language: Language;
    klineData: Kline[] | null;
    user: User | null;
    onSaveSignal: () => void;
}

const renderRecommendationValue = (position: AnalysisResult['possible_position'], t: Translation) => {
    switch (position) {
        case 'Long':
            return <span className="flex items-center font-bold text-green-400"><CheckCircleIcon className="w-5 h-5 me-2 rtl:ms-2" /> {t.long}</span>;
        case 'Short':
            return <span className="flex items-center font-bold text-red-400"><XCircleIcon className="w-5 h-5 me-2 rtl:ms-2" /> {t.short}</span>;
        default:
            return <span className="flex items-center font-bold text-yellow-400"><ExclamationIcon className="w-5 h-5 me-2 rtl:ms-2" /> {t.stayOut}</span>;
    }
};

const DataCard: React.FC<{ label: string; value: React.ReactNode; className?: string }> = ({ label, value, className }) => (
    <div className={`flex justify-between items-center py-2 ${className}`}>
        <span className="text-sm text-brand-text-secondary">{label}</span>
        <span className="text-sm font-semibold text-right font-mono">{value}</span>
    </div>
);

const TradeSetupCard: React.FC<{ result: AnalysisResult; t: Translation; user: User | null; onSaveSignal: () => void }> = ({ result, t, user, onSaveSignal }) => {
    const [copied, setCopied] = useState(false);
    const [saved, setSaved] = useState(false);
    
    if (!result.possible_position || !result.possible_entry || !result.take_profit || !result.stop_loss) return null;

    const handleCopy = () => {
        const tradeDetails = `
Position: ${result.possible_position}
Entry: ${result.possible_entry?.toFixed(4)}
Take Profit: ${result.take_profit?.toFixed(4)}
Stop Loss: ${result.stop_loss?.toFixed(4)}
        `.trim();
        navigator.clipboard.writeText(tradeDetails);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
    };

    const handleSave = () => {
        onSaveSignal();
        setSaved(true);
        setTimeout(() => setSaved(false), 2000);
    };

    return (
        <div className="bg-brand-surface/50 p-4 rounded-lg border border-brand-border">
            <h3 className="text-lg font-bold mb-4 flex items-center"><ClipboardIcon className="w-6 h-6 me-2 rtl:ms-2 text-brand-primary"/>{t.tradeSetup}</h3>
            <div className="space-y-2">
                <DataCard label={t.position} value={renderRecommendationValue(result.possible_position, t)} />
                {result.recommended_timeframe && (
                    <DataCard label={t.recommendedTimeframe} value={result.recommended_timeframe} />
                )}
                <DataCard label={t.entryPrice} value={`$${result.possible_entry.toFixed(3)}`} />
                <DataCard label={t.takeProfit} value={`$${result.take_profit.toFixed(3)}`} className="text-green-400" />
                <DataCard label={t.stopLoss} value={`$${result.stop_loss.toFixed(3)}`} className="text-red-400" />
                <DataCard label={t.riskRewardRatio} value={`1 : ${result.rr_ratio?.toFixed(2)}`} />
                <DataCard label={t.confidence} value={`${((result.confidence || 0) * 100).toFixed(0)}%`} />
            </div>
            
            <div className="flex gap-2 mt-4">
                <button
                    onClick={handleCopy}
                    className="flex-1 main-button bg-brand-primary hover:bg-brand-secondary text-white font-bold py-2 px-4 rounded-lg transition duration-300 flex items-center justify-center text-sm"
                >
                    <ClipboardIcon className="w-4 h-4 me-2 rtl:ms-2" />
                    {copied ? t.copied : t.copyTradeDetails}
                </button>
                
                {user && (
                    <button
                        onClick={handleSave}
                        disabled={saved}
                        className={`flex-1 main-button font-bold py-2 px-4 rounded-lg transition duration-300 flex items-center justify-center text-sm ${saved ? 'bg-green-600 text-white' : 'bg-brand-surface border border-brand-border hover:bg-brand-bg text-brand-text-secondary'}`}
                    >
                        {saved ? (
                            <>
                                <CheckCircleIcon className="w-4 h-4 me-2 rtl:ms-2" />
                                {t.savedToHistory}
                            </>
                        ) : (
                            <>
                                <HistoryIcon className="w-4 h-4 me-2 rtl:ms-2" />
                                {t.saveToHistory}
                            </>
                        )}
                    </button>
                )}
            </div>
            {!user && (
                 <p className="text-xs text-brand-text-secondary text-center mt-2 opacity-70">{t.loginRequiredDesc}</p>
            )}
        </div>
    );
};

const PositionSizingCalculator: React.FC<{ result: AnalysisResult; t: Translation; }> = ({ result, t }) => {
    const [accountBalance, setAccountBalance] = useState(1000);
    const [riskPercent, setRiskPercent] = useState(1);
    if (!result.possible_entry || !result.stop_loss || !result.symbol) return null;


    const { amountToRisk, positionSizeUSD, positionSizeAsset } = useMemo(() => {
        const riskAmount = accountBalance * (riskPercent / 100);
        const stopLossDistance = Math.abs(result.possible_entry! - result.stop_loss!);
        
        if (stopLossDistance === 0) return { amountToRisk: 0, positionSizeUSD: 0, positionSizeAsset: 0 };

        const sizeInAsset = riskAmount / stopLossDistance;
        const sizeInUSD = sizeInAsset * result.possible_entry!;

        return {
            amountToRisk: riskAmount,
            positionSizeUSD: sizeInUSD,
            positionSizeAsset: sizeInAsset,
        };
    }, [accountBalance, riskPercent, result]);
    
    return (
        <div className="bg-brand-surface/50 p-4 rounded-lg border border-brand-border">
            <h3 className="text-lg font-bold mb-4 flex items-center"><CalculatorIcon className="w-6 h-6 me-2 rtl:ms-2 text-brand-primary"/>{t.positionSizingTitle}</h3>
            <div className="space-y-4">
                <div>
                    <label htmlFor="accountBalance" className="block text-sm font-medium text-brand-text-secondary mb-2">{t.accountBalance}</label>
                    <input
                        type="number"
                        id="accountBalance"
                        value={accountBalance}
                        onChange={(e) => setAccountBalance(parseFloat(e.target.value) || 0)}
                        className="w-full bg-brand-surface border border-brand-border rounded-lg p-2 focus:ring-2 focus:ring-brand-primary focus:outline-none text-sm"
                    />
                </div>
                <div>
                    <label htmlFor="riskPercent" className="block text-sm font-medium text-brand-text-secondary mb-2">{t.riskPerTrade}</label>
                     <div className="flex items-center">
                        <input
                            type="range"
                            id="riskPercent"
                            min="0.5"
                            max="10"
                            step="0.5"
                            value={riskPercent}
                            onChange={(e) => setRiskPercent(parseFloat(e.target.value))}
                            className="w-full h-2 rounded-lg appearance-none cursor-pointer bg-brand-border"
                        />
                        <span className="ms-4 rtl:me-4 text-lg font-semibold w-16 text-center text-brand-primary">{riskPercent.toFixed(1)}%</span>
                    </div>
                </div>
                <div className="border-t border-brand-border pt-4 space-y-2">
                    <DataCard label={t.amountToRisk} value={`$${amountToRisk.toFixed(2)}`} className="text-red-400" />
                    <DataCard label={t.positionSizeAsset} value={`${positionSizeAsset.toFixed(6)} ${result.symbol.replace('USDT', '')}`} />
                    <DataCard label={t.positionSize} value={`$${positionSizeUSD.toFixed(2)}`} />
                </div>
                 <p className="text-xs text-brand-text-secondary text-center pt-2">{t.calculatorNote}</p>
            </div>
        </div>
    );
};


export const ResultsPanel: React.FC<ResultsPanelProps> = ({ result, isLoading, t, analysisSource, language, klineData, user, onSaveSignal }) => {
    
    if (!result && !isLoading) {
        return (
            <div className="glass-card p-6 min-h-[600px] flex flex-col justify-center items-center text-center">
                 <ChartIcon className="w-16 h-16 text-brand-border mb-4"/>
                <h3 className="text-xl font-bold">{t.superAnalysisResults}</h3>
                <p className="text-brand-text-secondary mt-2">{t.waitingForAnalysis}</p>
            </div>
        );
    }

    const isSymbolAnalysis = analysisSource === 'symbol';
    const isQuantumAnalysis = isSymbolAnalysis && result?.market_sentiment_score !== undefined;

    return (
        <div className="glass-card p-4 md:p-6 animate-fade-in">
            <h2 className="text-2xl font-bold mb-4">
                {isQuantumAnalysis ? t.quantumAnalysis : t.superAnalysisResults} - {result?.symbol}
            </h2>
            {isLoading && !result && <div className="min-h-[600px] flex items-center justify-center"><p>{t.analyzing}</p></div>}
            
            {isSymbolAnalysis && klineData && (
                <CandleChart data={klineData} language={language} />
            )}
            
            {result && (
                <div className="space-y-6 mt-4">
                    {isQuantumAnalysis ? (
                        <div className="space-y-6">
                             {/* Sentiment Meter */}
                             <SentimentMeter score={result.market_sentiment_score!} t={t} />
                             
                             {/* Whale Radar */}
                             {result.whale_activity && <WhaleRadar activity={result.whale_activity} t={t} />}

                             {/* Market Structure & Key Levels */}
                             <StructuralLevelsCard result={result} t={t} />
                             
                             {/* Bull/Bear Case & Liquidity */}
                             <BullBearAnalysis result={result} t={t} />
                             
                             {/* Final Verdict */}
                             <div className="bg-brand-surface/50 p-4 rounded-lg border border-brand-border">
                                <h4 className="font-bold text-brand-primary mb-2">{t.finalVerdict}</h4>
                                <p className="text-sm text-brand-text-primary leading-relaxed">{result.analysis_summary}</p>
                            </div>
                        </div>
                    ) : (
                        result.analysis_summary && (
                            <div className="bg-brand-surface/50 p-4 rounded-lg border border-brand-border">
                                <h3 className="text-lg font-bold mb-3 flex items-center"><DocumentTextIcon className="w-6 h-6 me-2 rtl:ms-2 text-brand-primary"/>{t.summary}</h3>
                                <p className="text-sm text-brand-text-secondary leading-relaxed mb-4">{result.analysis_summary}</p>
                            </div>
                        )
                    )}

                    {result.possible_position !== 'Stay Out' ? (
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                            <TradeSetupCard result={result} t={t} user={user} onSaveSignal={onSaveSignal} />
                            <PositionSizingCalculator result={result} t={t} />
                        </div>
                    ) : (
                         <div className="bg-brand-surface/50 p-4 rounded-lg border border-brand-border h-full flex flex-col justify-center items-center text-center py-8">
                            <ExclamationIcon className="w-12 h-12 text-yellow-400 mb-3" />
                            <p className="font-bold text-xl mb-1">{t.stayOut}</p>
                            <p className="text-sm text-brand-text-secondary max-w-md">{result.analysis_summary || t.noClearOpportunity}</p>
                        </div>
                    )}
                    
                    <div className="mt-4 text-center text-xs text-brand-text-secondary">
                        <p>{t.disclaimer}</p>
                    </div>
                </div>
            )}
        </div>
    );
};