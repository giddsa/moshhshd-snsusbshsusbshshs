import React, { useState } from 'react';
// FIX: Correctly import Signal and ManualAnalysisInput from types.ts.
import { Translation, Signal, TradingType, ManualAnalysisInput } from '../types';
// FIX: Import only processManualAnalysis from the service to fix missing member errors.
import { processManualAnalysis } from '../services/analysisService';
import { LoadingSpinner, SignalIcon, CheckCircleIcon, XCircleIcon } from './Icons';

interface AutoSignalPanelProps {
    leverage: number;
    t: Translation;
    tradingType: TradingType;
}

const SignalCard: React.FC<{ signal: Signal, t: Translation }> = ({ signal, t }) => {
    const isLong = signal.possible_position === 'Long';
    const colorClass = isLong ? 'text-green-400' : 'text-red-400';
    const borderClass = isLong ? 'border-l-green-400' : 'border-l-red-400';

    return (
        <div className={`bg-brand-surface/50 p-4 rounded-lg border border-brand-border border-l-4 ${borderClass} flex flex-col md:flex-row md:items-center md:justify-between gap-4`}>
            <div className="flex items-center gap-4">
                {isLong ? <CheckCircleIcon className={`w-8 h-8 ${colorClass}`} /> : <XCircleIcon className={`w-8 h-8 ${colorClass}`} />}
                <div>
                    <p className={`font-bold text-lg ${colorClass}`}>{t[signal.possible_position.toLowerCase() as 'long' | 'short']} Signal</p>
                    <p className="text-xs text-brand-text-secondary">{new Date(signal.timestamp).toLocaleString()}</p>
                </div>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-x-6 gap-y-2 text-sm">
                <div><span className="text-brand-text-secondary">{t.entryPrice}:</span> <span className="font-semibold">${signal.possible_entry.toFixed(3)}</span></div>
                <div><span className="text-brand-text-secondary">{t.confidence}:</span> <span className="font-semibold">{(signal.confidence * 100).toFixed(0)}%</span></div>
                <div><span className="text-brand-text-secondary">{t.takeProfit}:</span> <span className="font-semibold text-green-400">${signal.take_profit.toFixed(3)}</span></div>
                <div><span className="text-brand-text-secondary">{t.stopLoss}:</span> <span className="font-semibold text-red-400">${signal.stop_loss.toFixed(3)}</span></div>
            </div>
        </div>
    );
};

const InputField: React.FC<{ label: string; name: string; value: string; onChange: (e: React.ChangeEvent<HTMLInputElement>) => void; placeholder?: string }> = 
({ label, name, value, onChange, placeholder }) => (
    <div>
        <label htmlFor={name} className="block text-sm font-medium text-brand-text-secondary mb-2">{label}</label>
        <input
            type="text"
            id={name}
            name={name}
            value={value}
            onChange={onChange}
            placeholder={placeholder}
            className="w-full bg-brand-surface border border-brand-border rounded-lg p-2 focus:ring-2 focus:ring-brand-primary focus:outline-none text-sm"
        />
    </div>
);

export const AutoSignalPanel: React.FC<AutoSignalPanelProps> = ({ leverage, t, tradingType }) => {
    const [signal, setSignal] = useState<Signal | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [formState, setFormState] = useState({
        symbol: 'BTCUSDT',
        currentPrice: '65000',
        rsi: '55',
        ema9: '64500',
        ema21: '64000',
        ema50: '63000',
        macdLine: '150',
        macdSignal: '120',
        atr: '800'
    });

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        if (name !== 'symbol' && value !== '' && !/^-?\d*\.?\d*$/.test(value)) {
            return;
        }
        setFormState(prev => ({ ...prev, [name]: value }));
    };

    const handleGenerate = () => {
        setIsLoading(true);
        setSignal(null);

        const input: ManualAnalysisInput = {
            symbol: formState.symbol,
            currentPrice: parseFloat(formState.currentPrice),
            rsi: parseFloat(formState.rsi),
            ema9: parseFloat(formState.ema9),
            ema21: parseFloat(formState.ema21),
            ema50: parseFloat(formState.ema50),
            macdLine: parseFloat(formState.macdLine),
            macdSignal: parseFloat(formState.macdSignal),
            atr: parseFloat(formState.atr),
            leverage,
            tradingType,
        };
        
        if (Object.values(input).some(v => typeof v === 'number' && isNaN(v))) {
            alert('Please fill all fields with valid numbers.');
            setIsLoading(false);
            return;
        }

        setTimeout(() => {
            const result = processManualAnalysis(input);
            const newSignal: Signal = {
                ...result,
                id: `manual-${Date.now()}`,
                timestamp: Date.now(),
            };
            setSignal(newSignal);
            setIsLoading(false);
        }, 500);
    };

    return (
        <div className="space-y-8">
            <div className="glass-card p-6">
                <h2 className="text-2xl font-bold">{t.autoSignalTitle}</h2>
                <p className="text-brand-text-secondary mt-2 mb-6">{t.autoSignalDescription}</p>

                <div className="border-t border-brand-border pt-6">
                    <h3 className="text-xl font-bold mb-4">{t.manualInput}</h3>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                        <InputField label={t.symbol} name="symbol" value={formState.symbol} onChange={handleInputChange} placeholder="e.g., BTCUSDT" />
                        <InputField label={t.currentPrice} name="currentPrice" value={formState.currentPrice} onChange={handleInputChange} placeholder="e.g., 65000" />
                        <InputField label={t.rsi} name="rsi" value={formState.rsi} onChange={handleInputChange} placeholder="e.g., 55" />
                        <InputField label={t.ema9} name="ema9" value={formState.ema9} onChange={handleInputChange} placeholder="e.g., 64500" />
                        <InputField label={t.ema21} name="ema21" value={formState.ema21} onChange={handleInputChange} placeholder="e.g., 64000" />
                        <InputField label={t.ema50} name="ema50" value={formState.ema50} onChange={handleInputChange} placeholder="e.g., 63000" />
                        <InputField label={t.macdLine} name="macdLine" value={formState.macdLine} onChange={handleInputChange} placeholder="e.g., 150" />
                        <InputField label={t.macdSignal} name="macdSignal" value={formState.macdSignal} onChange={handleInputChange} placeholder="e.g., 120" />
                        <InputField label={t.atr} name="atr" value={formState.atr} onChange={handleInputChange} placeholder="e.g., 800" />
                    </div>
                </div>

                <div className="mt-6">
                    <button
                        onClick={handleGenerate}
                        disabled={isLoading}
                        className="w-full sm:w-auto main-button bg-brand-primary hover:bg-brand-secondary text-white font-bold py-2.5 px-6 rounded-lg transition duration-300 disabled:bg-gray-500 disabled:cursor-not-allowed flex items-center justify-center"
                    >
                        {isLoading ? <LoadingSpinner /> : <SignalIcon className="w-5 h-5 me-2 rtl:ms-2" />}
                        {isLoading ? t.analyzing : t.startMonitoring}
                    </button>
                </div>
            </div>

            <div className="glass-card p-6">
                <h3 className="text-xl font-bold mb-4">{t.generatedSignals}</h3>
                {isLoading && <div className="text-center p-8"><LoadingSpinner /></div>}
                {signal && !isLoading && (
                    <SignalCard signal={signal} t={t} />
                )}
                {!signal && !isLoading && (
                    <div className="text-center py-8">
                        <p className="text-brand-text-secondary">{t.noSignals}</p>
                    </div>
                )}
            </div>
        </div>
    );
};