import { User, SavedSignal } from '../types';

const STORAGE_KEY_USER = 'smart_analyst_user';
const STORAGE_KEY_HISTORY = 'smart_analyst_history';

// Mock Login Function
export const loginUser = async (): Promise<User> => {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 800));
    
    const mockUser: User = {
        id: 'user_' + Math.floor(Math.random() * 100000),
        name: 'Trader Joe',
        email: 'trader@example.com',
        avatarUrl: 'https://ui-avatars.com/api/?name=Trader+Joe&background=0D8ABC&color=fff&rounded=true'
    };
    
    localStorage.setItem(STORAGE_KEY_USER, JSON.stringify(mockUser));
    return mockUser;
};

// Mock Logout Function
export const logoutUser = async (): Promise<void> => {
    await new Promise(resolve => setTimeout(resolve, 300));
    localStorage.removeItem(STORAGE_KEY_USER);
};

// Get current user from storage
export const getCurrentUser = (): User | null => {
    const stored = localStorage.getItem(STORAGE_KEY_USER);
    return stored ? JSON.parse(stored) : null;
};

// Get signal history from storage
export const getSignalHistory = (): SavedSignal[] => {
    const stored = localStorage.getItem(STORAGE_KEY_HISTORY);
    return stored ? JSON.parse(stored) : [];
};

// Save a new signal
export const saveSignal = (signal: SavedSignal): SavedSignal[] => {
    const current = getSignalHistory();
    // Check for duplicates based on timestamp and symbol to avoid double saving
    const exists = current.some(s => s.symbol === signal.symbol && Math.abs(s.timestamp - signal.timestamp) < 60000); // 1 min window
    
    if (exists) return current;

    const updated = [signal, ...current];
    localStorage.setItem(STORAGE_KEY_HISTORY, JSON.stringify(updated));
    return updated;
};

// Update signal status (Win/Loss)
export const updateSignalStatus = (id: string, status: 'Win' | 'Loss'): SavedSignal[] => {
    const current = getSignalHistory();
    const updated = current.map(s => s.id === id ? { ...s, status } : s);
    localStorage.setItem(STORAGE_KEY_HISTORY, JSON.stringify(updated));
    return updated;
};

// Delete a signal
export const deleteSignal = (id: string): SavedSignal[] => {
    const current = getSignalHistory();
    const updated = current.filter(s => s.id !== id);
    localStorage.setItem(STORAGE_KEY_HISTORY, JSON.stringify(updated));
    return updated;
};