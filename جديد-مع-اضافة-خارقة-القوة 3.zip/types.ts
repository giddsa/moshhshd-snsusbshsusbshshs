export type Language = 'en' | 'ar';
export type TradingType = 'futures' | 'spot';

export interface User {
    id: string;
    name: string;
    email: string;
    avatarUrl?: string;
}

export interface SavedSignal extends AnalysisResult {
    id: string;
    timestamp: number;
    status: 'Pending' | 'Win' | 'Loss'; // User can update this manually in history
    pnl?: number; // Realized PnL
}

export interface Kline {
    timestamp: number;
    open: number;
    high: number;
    low: number;
    close: number;
    volume: number;
}

export interface UploadedImage {
    data: string; // base64 encoded data
    mimeType: string;
}

export interface ChatMessage {
    role: 'user' | 'model';
    parts: { text: string }[];
}


export interface Indicators {
    rsi: number;
    macd: {
        macd: number;
        signal: number;
        hist: number;
        // Fix: Removed incorrect type definition if present in previous versions to match usage
    };
    atr: number;
    ema: {
        '9': number;
        '21': number;
        '50': number;
    };
    bollinger: {
        upper: number;
        middle: number;
        lower: number;
    };
}

export type Position = 'Long' | 'Short' | 'Stay Out';

export interface NumericalAnalysisResult {
    symbol: string;
    timeframe: string;
    possible_position: Position;
    trend_direction: 'Uptrend' | 'Downtrend' | 'Sideways';
    possible_entry: number;
    take_profit: number;
    stop_loss: number;
    rr_ratio: number;
    confidence: number;
    indicators: Indicators;
}

export interface WhaleActivity {
    score: number; // 0 to 100
    action: 'Accumulation' | 'Distribution' | 'Dormant';
    warning?: string; // e.g. "Potential Stop Hunt", "Pump incoming"
}

export interface GeminiAnalysisResult {
    analysis_summary: string;
    analysis_explanation?: string;
    // Quantum Analysis Fields
    market_sentiment_score?: number; // 0 (Fear) to 100 (Greed)
    whale_activity?: WhaleActivity; // NEW: Super Power Feature
    key_support?: number;
    key_resistance?: number;
    point_of_control?: number;
    liquidity_analysis?: string;
    bullish_case?: string;
    bearish_case?: string;
    recommended_timeframe?: string;
    // Smart Money Concepts
    market_structure?: 'Bullish' | 'Bearish';
    market_structure_reason?: 'BOS' | 'CHoCH';
    order_block?: {
        type: 'Bullish' | 'Bearish';
        start_price: number;
        end_price: number;
    };
    fair_value_gap?: {
        start_price: number;
        end_price: number;
    };
    // Fields for new Strict Analysis
    reason?: string;
    trend?: string;
    trade_type?: string; // e.g., 'شراء', 'بيع'
    entry_zone?: string; // e.g., '123.45 - 123.00'
    tp1?: number;
    tp2?: number;
    tp3?: number;
    trade_strength_percent?: number;
}

export type AnalysisResult = Partial<NumericalAnalysisResult> & Partial<GeminiAnalysisResult> & {
    symbol?: string;
    stop_loss?: number; // Ensure stop_loss is available for strict analysis
    id?: string; // for key prop in lists
    klineData?: Kline[]; // for charting signals
};


export interface NewsArticle {
    id: string;
    title: string;
    source: string;
    summary: string;
    sentiment: 'Bullish' | 'Bearish' | 'Neutral';
    timestamp: string;
    url: string;
}

// FIX: Added missing BacktestResult type
export interface BacktestResult {
    totalPnl: number;
    winRate: number;
    totalTrades: number;
    averageWin: number;
    averageLoss: number;
    pnlHistory: { timestamp: number; pnl: number }[];
}

// FIX: Added missing Signal type
export interface Signal extends NumericalAnalysisResult {
    id: string;
    timestamp: number;
}

// FIX: Added missing ManualAnalysisInput type for the AutoSignalPanel
export interface ManualAnalysisInput {
    symbol: string;
    currentPrice: number;
    rsi: number;
    ema9: number;
    ema21: number;
    ema50: number;
    macdLine: number;
    macdSignal: number;
    atr: number;
    leverage: number;
    tradingType: TradingType;
}

// FIX: Added missing OpenPosition type
export interface OpenPosition {
    id: string;
    symbol: string;
    position: 'Long' | 'Short';
    entryPrice: number;
    amountUSD: number;
}

// FIX: Added missing TradeHistory type
export interface TradeHistory {
    id: string;
    symbol: string;
    position: 'Long' | 'Short';
    pnl: number;
    entryPrice: number;
    exitPrice: number;
}


export interface Translation {
    // Header
    headerTitle: string;
    login: string;
    logout: string;
    welcome: string;
    
    // Tabs
    analyzerTab: string;
    chatTab: string;
    aiAssistant: string;
    newsTab: string;
    historyTab: string;

    // Upload Panel
    uploadTitle: string;
    uploadImage: string;
    uploadData: string;
    or: string;
    uploadInstructions: string;
    uploading: string;
    removeImage: string;
    uploadFile: string;
    analyzeBySymbol: string;
    enterSymbol: string;
    symbolPlaceholder: string;
    
    // Settings Panel
    settingsTitle: string;
    tradingType: string;
    futures: string;
    spot: string;
    leverage: string;
    
    // Main Controls
    analyzeNow: string;
    analyzing: string;

    // Results Panel
    analysisResults: string;
    superAnalysisResults: string;
    waitingForAnalysis: string;
    chart: string;
    recommendation: string;
    position: string;
    entryPrice: string;
    takeProfit: string;
    stopLoss: string;
    riskRewardRatio: string;
    confidence: string;
    summary: string;
    fullAnalysis: string;
    saveAnalysis: string;
    disclaimer: string;
    tradeSetup: string;
    copyTradeDetails: string;
    copied: string;
    noClearOpportunity: string;
    kucoinAiAnalysis: string;
    quantumAnalysis: string;
    marketSentiment: string;
    recommendedTimeframe: string;
    extremeFear: string;
    fear: string;
    neutral: string;
    greed: string;
    extremeGreed: string;
    keyLevels: string;
    support: string;
    resistance: string;
    pointOfControl: string;
    liquidityAnalysis: string;
    bullishCase: string;
    bearishCase: string;
    finalVerdict: string;
    marketStructure: string;
    orderBlock: string;
    fairValueGap: string;
    breakOfStructure: string;
    changeOfCharacter: string;
    strictAnalysis: string;
    noSafeTrade: string;
    trend: string;
    tradeType: string;
    entryZone: string;
    targets: string;
    tradeStrength: string;
    
    // Whale Radar
    whaleRadar: string;
    whaleScore: string;
    whaleAction: string;
    accumulation: string;
    distribution: string;
    dormant: string;
    manipulationWarning: string;

    // Positions
    long: string;
    short: string;
    stayOut: string;

    // Chat Panel
    chatWithSato: string;
    satoWelcome: string;
    chatPlaceholder: string;
    send: string;
    satoFetchingPrice: string;

    // AI Trader Panel
    aiAssistantTitle: string;
    aiAssistantDescription: string;
    selectExchange: string;
    executeOn: string;
    tradeExecutionNotification: string;
    traderControlsTitle: string;
    botStatus: string;
    statusIdle: string;
    statusScanning: string;
    // FIX: Add missing translation keys to fix type error in constants.ts.
    statusScanningSymbol: string;
    scanComplete: string;
    noSignalsFound: string;
    statusFound: string;
    statusGenerating: string;
    minConfidence: string;
    startTrader: string;
    stopTrader: string;
    tradeProposalTitle: string;
    tradeRationale: string;
    currentMarketPrice: string;
    livePriceFromBinance: string;
    aiTraderDisclaimer: string;
    trackTrade: string;
    tradeTracker: string;
    trackingStatus: string;
    livePrice: string;
    statusTracking: string;
    statusSuccess: string;
    statusFailure: string;
    tradeTargetReached: string;
    tradeStopLossHit: string;


    // Position Sizing Calculator
    positionSizingTitle: string;
    accountBalance: string;
    riskPerTrade: string;
    amountToRisk: string;
    positionSize: string;
    positionSizeAsset: string;
    calculatorNote: string;

    // Crypto News Panel
    cryptoNewsTitle: string;
    cryptoNewsDescription: string;
    searchNewsPlaceholder: string;
    search: string;
    trendingTopics: string;
    noNewsFound: string;
    fetchingNews: string;
    newsSentiment: string;
    sentimentBullish: string;
    sentimentBearish: string;
    sentimentNeutral: string;

    // History & Auth
    loginWithGoogle: string;
    historyTitle: string;
    historyDescription: string;
    winRate: string;
    totalSignals: string;
    wins: string;
    losses: string;
    filterBySymbol: string;
    filterByDate: string;
    statusPending: string;
    statusWin: string;
    statusLoss: string;
    markAsWin: string;
    markAsLoss: string;
    deleteSignal: string;
    saveToHistory: string;
    savedToHistory: string;
    loginRequired: string;
    loginRequiredDesc: string;

    // Errors & Notes
    errorNoData: string;
    errorAnalysisFailed: string;
    errorApiKey: string;
    errorVisionAnalysisFailed: string;
    errorChatFailed: string;
    errorNewsFailed: string;
    errorUnsupportedSymbol: string;

    // Footer
    instagramLink: string;
}