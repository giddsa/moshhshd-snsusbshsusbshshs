# ملف wsgi.py لتهيئة تطبيق Flask على PythonAnywhere
import sys
import os

# إضافة مسار المشروع إلى المسارات
# تأكد من أن اسم المجلد هو 'telegram_bot'
project_home = os.path.expanduser('~/telegram_bot')
if project_home not in sys.path:
    sys.path.insert(0, project_home)

# تعيين متغير البيئة لرمز البوت
# سيتم استبدال 'YOUR_BOT_TOKEN_HERE' برمز البوت الفعلي من الواجهة الأمامية
# ولكن يفضل أن يتم تعيينه في صفحة الـ Web App على PythonAnywhere
# هنا نستخدم os.environ.get للحماية
if 'BOT_TOKEN' not in os.environ:
    # هذا الرمز سيتم استبداله تلقائيًا بواسطة سكربت الواجهة الأمامية
    # عند إنشاء ملف wsgi.py النهائي
    os.environ['BOT_TOKEN'] = 'YOUR_BOT_TOKEN_HERE' 

# استيراد التطبيق من ملف البوت
# تأكد من أن اسم ملف البوت هو 'bot_script.py'
from bot_template import app as application 
# تم إعادة تسمية app إلى application لأن PythonAnywhere يتوقع هذا الاسم

# ملاحظة: تأكد من أن ملف البوت (bot_template.py) يحتوي على السطر:
# app = Flask(__name__)
# وتأكد من أن اسم ملف البوت هو 'bot_template.py' أو قم بتعديل هذا الملف وفقًا لذلك.

