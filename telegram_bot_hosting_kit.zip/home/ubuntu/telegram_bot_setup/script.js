// ============================================
// وظائف عامة (General Functions)
// ============================================

/**
 * تبديل بين علامات التبويب
 */
function switchTab(tabName) {
    // إخفاء جميع محتويات التبويب
    const tabContents = document.querySelectorAll('.tab-content');
    tabContents.forEach(tab => {
        tab.classList.remove('active');
    });

    // إزالة الفئة النشطة من جميع الأزرار
    const tabButtons = document.querySelectorAll('.tab-button');
    tabButtons.forEach(btn => {
        btn.classList.remove('active');
    });

    // عرض التبويب المختار
    const selectedTab = document.getElementById(tabName);
    if (selectedTab) {
        selectedTab.classList.add('active');
    }

    // تفعيل الزر المختار
    event.target.classList.add('active');
}

/**
 * إضافة مستمعي أحداث علامات التبويب
 */
document.addEventListener('DOMContentLoaded', function() {
    const tabButtons = document.querySelectorAll('.tab-button');
    tabButtons.forEach(button => {
        button.addEventListener('click', function() {
            const tabName = this.getAttribute('data-tab');
            switchTab(tabName);
        });
    });
});

// ============================================
// وظائف إدارة كلمات المرور (Password Functions)
// ============================================

/**
 * تبديل عرض/إخفاء كلمة المرور
 */
function togglePasswordVisibility(fieldId) {
    const field = document.getElementById(fieldId);
    const button = event.target;

    if (field.type === 'password') {
        field.type = 'text';
        button.textContent = '👁️‍🗨️ إخفاء';
    } else {
        field.type = 'password';
        button.textContent = '👁️ عرض';
    }
}

// ============================================
// وظائف إدارة النماذج (Form Functions)
// ============================================

/**
 * إظهار/إخفاء نموذج الرفع
 */
function toggleUploadForm() {
    const uploadForm = document.getElementById('uploadForm');
    uploadForm.classList.toggle('hidden');
}

/**
 * تحميل سكربت نموذجي
 */
function downloadTemplate() {
    // إنشاء سكربت بوت نموذجي
    const templateCode = `#!/usr/bin/env python3
# -*- coding: utf-8 -*-
\"\"\"
بوت تلجرام نموذجي باستخدام Flask و Webhook
هذا السكربت يعمل على PythonAnywhere بشكل مجاني
\"\"\"

import os
import json
import logging
from flask import Flask, request
import requests

# إعداد السجلات (Logging)
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# إنشاء تطبيق Flask
app = Flask(__name__)

# بيانات البوت (استبدل بـ رمزك الخاص)
BOT_TOKEN = os.environ.get('BOT_TOKEN', 'YOUR_BOT_TOKEN_HERE')
TELEGRAM_API_URL = f'https://api.telegram.org/bot{BOT_TOKEN}'

# ============================================
# وظائف مساعدة
# ============================================

def send_message(chat_id, text):
    \"\"\"إرسال رسالة نصية\"\"\"
    url = f'{TELEGRAM_API_URL}/sendMessage'
    data = {
        'chat_id': chat_id,
        'text': text,
        'parse_mode': 'HTML'
    }
    try:
        response = requests.post(url, json=data)
        response.raise_for_status()
        return True
    except Exception as e:
        logger.error(f'خطأ في إرسال الرسالة: {e}')
        return False

def handle_message(message):
    \"\"\"معالجة الرسائل الواردة\"\"\"
    chat_id = message['chat']['id']
    text = message.get('text', '')
    
    # معالجة الأوامر
    if text == '/start':
        send_message(chat_id, 
            'مرحباً! 👋\\n'
            'أنا بوت تلجرام نموذجي.\\n'
            'استخدم /help للمزيد من المعلومات.')
    
    elif text == '/help':
        send_message(chat_id,
            'الأوامر المتاحة:\\n'
            '/start - ابدأ\\n'
            '/help - المساعدة\\n'
            '/echo - كرر الرسالة')
    
    elif text.startswith('/echo '):
        echo_text = text[6:]
        send_message(chat_id, f'صدى: {echo_text}')
    
    else:
        send_message(chat_id, f'لقد استقبلت رسالتك: {text}')

# ============================================
# مسارات Flask (Routes)
# ============================================

@app.route('/')
def index():
    \"\"\"الصفحة الرئيسية\"\"\"
    return 'البوت يعمل بشكل صحيح! ✅'

@app.route('/webhook', methods=['POST'])
def webhook():
    \"\"\"استقبال التحديثات من تلجرام\"\"\"
    try:
        update = request.get_json()
        logger.info(f'تحديث جديد: {update}')
        
        # التحقق من وجود رسالة
        if 'message' in update:
            message = update['message']
            handle_message(message)
        
        return 'OK', 200
    
    except Exception as e:
        logger.error(f'خطأ في معالجة التحديث: {e}')
        return 'Error', 500

@app.route('/set_webhook', methods=['GET'])
def set_webhook():
    \"\"\"تعيين Webhook (للاختبار المحلي فقط)\"\"\"
    webhook_url = request.args.get('url', '')
    if not webhook_url:
        return 'يجب تحديد URL', 400
    
    url = f'{TELEGRAM_API_URL}/setWebhook'
    data = {'url': webhook_url}
    
    try:
        response = requests.post(url, json=data)
        return response.json()
    except Exception as e:
        return {'error': str(e)}, 500

# ============================================
# تشغيل التطبيق
# ============================================

if __name__ == '__main__':
    # ملاحظة: على PythonAnywhere، لا تستخدم app.run()
    # بدلاً من ذلك، استخدم ملف WSGI
    app.run(debug=False, host='0.0.0.0', port=5000)
`;

    // إنشاء ملف وتحميله
    downloadFile('bot_template.py', templateCode, 'text/plain');
}

/**
 * تحميل ملف
 */
function downloadFile(filename, content, type) {
    const element = document.createElement('a');
    element.setAttribute('href', 'data:' + type + ';charset=utf-8,' + encodeURIComponent(content));
    element.setAttribute('download', filename);
    element.style.display = 'none';
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
}

/**
 * إنشاء ملفات الإعداد
 */
function generateSetupFiles() {
    // التحقق من صحة البيانات
    const botName = document.getElementById('botName').value.trim();
    const botToken = document.getElementById('botToken').value.trim();
    const pythonUsername = document.getElementById('pythonUsername').value.trim();

    if (!botName || !botToken || !pythonUsername) {
        alert('يرجى ملء جميع الحقول المطلوبة!');
        return;
    }

    // التحقق من صيغة رمز البوت
    if (botToken.length < 20) {
        alert('رمز البوت يبدو غير صحيح. تأكد من نسخه بشكل كامل من BotFather.');
        return;
    }

    // إنشاء ملف requirements.txt
    const requirementsContent = `python-telegram-bot==20.3
Flask==3.0.0
requests==2.31.0
gunicorn==21.2.0
`;

    // إنشاء ملف wsgi.py
    const wsgiContent = `import sys
import os

# إضافة مسار المشروع
project_home = os.path.expanduser('~/telegram_bot')
if project_home not in sys.path:
    sys.path.insert(0, project_home)

# استيراد تطبيق Flask
from bot_script import app

# تعيين متغير البيئة
os.environ['BOT_TOKEN'] = '${botToken}'
`;

    // إنشاء ملف .env (للمرجع)
    const envContent = `# متغيرات البيئة للبوت
BOT_TOKEN=${botToken}
BOT_NAME=${botName}
WEBHOOK_URL=https://${pythonUsername}.pythonanywhere.com/webhook
`;

    // إنشاء ملف setup_instructions.txt
    const instructionsContent = `═══════════════════════════════════════════════════════════
منصة استضافة بوت تلجرام المجانية - دليل الإعداد
═══════════════════════════════════════════════════════════

معلومات البوت:
─────────────
اسم البوت: ${botName}
اسم المستخدم على PythonAnywhere: ${pythonUsername}
Webhook URL: https://${pythonUsername}.pythonanywhere.com/webhook

خطوات الإعداد:
─────────────

1. إنشاء حساب على PythonAnywhere:
   - اذهب إلى https://www.pythonanywhere.com
   - اختر الخطة المجانية (Beginner)
   - أنشئ حسابًا باستخدام بريدك الإلكتروني

2. رفع ملفات البوت:
   - سجل الدخول إلى حسابك على PythonAnywhere
   - اذهب إلى "Files" (الملفات)
   - أنشئ مجلدًا جديدًا باسم "telegram_bot"
   - رفع الملفات التالية:
     * bot_script.py
     * requirements.txt
     * wsgi.py

3. إنشاء تطبيق ويب:
   - اذهب إلى "Web" من القائمة الرئيسية
   - انقر على "Add a new web app"
   - اختر "Manual configuration"
   - اختر "Python 3.10" (أو أحدث)
   - في ملف WSGI، استبدل المحتوى بمحتوى wsgi.py

4. تثبيت المكتبات:
   - افتح "Bash console"
   - انتقل إلى المجلد: cd /home/${pythonUsername}/telegram_bot
   - ثبت المكتبات: pip install -r requirements.txt

5. تفعيل Webhook:
   - استخدم curl أو Postman لتنفيذ الأمر التالي:
   curl -X POST https://api.telegram.org/bot${botToken}/setWebhook?url=https://${pythonUsername}.pythonanywhere.com/webhook

6. تشغيل البوت:
   - اذهب إلى صفحة "Web"
   - انقر على "Reload" لإعادة تحميل التطبيق
   - تحقق من أن حالة التطبيق خضراء
   - اختبر البوت على تلجرام

ملاحظات مهمة:
──────────────
- البوت قد ينام بعد فترة من عدم النشاط على الخطة المجانية
- استخدم UptimeRobot (مجاني) لزيارة التطبيق كل 5 دقائق
- تحقق من السجلات (Log files) في حالة حدوث أخطاء
- لا تشارك رمز البوت مع أحد

الدعم:
──────
للمزيد من المساعدة، اطلع على:
- توثيق python-telegram-bot: https://python-telegram-bot.readthedocs.io
- منتدى PythonAnywhere: https://www.pythonanywhere.com/forums/
- مجتمع تلجرام للمطورين: https://t.me/telegram

═══════════════════════════════════════════════════════════
`;

    // عرض منطقة النتائج
    const resultsArea = document.getElementById('resultsArea');
    const downloadLinks = document.getElementById('downloadLinks');
    
    // مسح الروابط السابقة
    downloadLinks.innerHTML = '';

    // إنشاء روابط التحميل
    const files = [
        { name: 'requirements.txt', content: requirementsContent },
        { name: 'wsgi.py', content: wsgiContent },
        { name: '.env', content: envContent },
        { name: 'setup_instructions.txt', content: instructionsContent }
    ];

    files.forEach(file => {
        const link = document.createElement('a');
        link.href = 'data:text/plain;charset=utf-8,' + encodeURIComponent(file.content);
        link.download = file.name;
        link.textContent = `📥 تحميل ${file.name}`;
        downloadLinks.appendChild(link);
    });

    // عرض منطقة النتائج
    resultsArea.classList.remove('hidden');

    // التمرير إلى منطقة النتائج
    resultsArea.scrollIntoView({ behavior: 'smooth', block: 'start' });

    // عرض رسالة نجاح
    alert('✅ تم إنشاء ملفات الإعداد بنجاح!\\n\\nيمكنك الآن تحميل الملفات ورفعها إلى PythonAnywhere.');
}

// ============================================
// وظائف إضافية
// ============================================

/**
 * نسخ النص إلى الحافظة
 */
function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {
        alert('تم النسخ إلى الحافظة!');
    }).catch(err => {
        console.error('خطأ في النسخ:', err);
    });
}

/**
 * التحقق من الاتصال بالإنترنت
 */
window.addEventListener('online', () => {
    console.log('تم استعادة الاتصال بالإنترنت');
});

window.addEventListener('offline', () => {
    console.log('فُقد الاتصال بالإنترنت');
    alert('تنبيه: فُقد الاتصال بالإنترنت. بعض الميزات قد لا تعمل.');
});

// ============================================
// تهيئة الصفحة
// ============================================

document.addEventListener('DOMContentLoaded', function() {
    console.log('✅ تم تحميل الصفحة بنجاح');
    
    // يمكن إضافة أي تهيئة إضافية هنا
});

