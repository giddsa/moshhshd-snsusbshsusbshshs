#!/usr/bin/env python3
# -*- coding: utf-8 -*-
\"\"\"
بوت تلجرام نموذجي باستخدام Flask و Webhook
هذا السكربت يعمل على PythonAnywhere بشكل مجاني
\"\"\"

import os
import json
import logging
from flask import Flask, request
import requests

# إعداد السجلات (Logging)
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# إنشاء تطبيق Flask
app = Flask(__name__)

# بيانات البوت (يتم قراءة الرمز من متغيرات البيئة على PythonAnywhere)
# يجب تعيين متغير البيئة BOT_TOKEN في ملف wsgi.py
BOT_TOKEN = os.environ.get('BOT_TOKEN', 'YOUR_BOT_TOKEN_HERE')
TELEGRAM_API_URL = f'https://api.telegram.org/bot{BOT_TOKEN}'

# ============================================
# وظائف مساعدة
# ============================================

def send_message(chat_id, text):
    \"\"\"إرسال رسالة نصية\"\"\"
    url = f'{TELEGRAM_API_URL}/sendMessage'
    data = {
        'chat_id': chat_id,
        'text': text,
        'parse_mode': 'HTML'
    }
    try:
        response = requests.post(url, json=data)
        response.raise_for_status()
        return True
    except Exception as e:
        logger.error(f'خطأ في إرسال الرسالة: {e}')
        return False

def handle_message(message):
    \"\"\"معالجة الرسائل الواردة\"\"\"
    # استخراج معلومات الرسالة
    chat_id = message['chat']['id']
    text = message.get('text', '')
    
    # معالجة الأوامر
    if text == '/start':
        send_message(chat_id, 
            'مرحباً! 👋\\n'
            'أنا بوت تلجرام نموذجي.\\n'
            'استخدم /help للمزيد من المعلومات.')
    
    elif text == '/help':
        send_message(chat_id,
            'الأوامر المتاحة:\\n'
            '/start - ابدأ\\n'
            '/help - المساعدة\\n'
            '/echo - كرر الرسالة')
    
    elif text.startswith('/echo '):
        echo_text = text[6:]
        send_message(chat_id, f'صدى: {echo_text}')
    
    else:
        # الرد على الرسائل الأخرى
        send_message(chat_id, f'لقد استقبلت رسالتك: {text}')

# ============================================
# مسارات Flask (Routes)
# ============================================

@app.route('/')
def index():
    \"\"\"الصفحة الرئيسية للتطبيق (للتحقق من التشغيل)\"\"\"
    return 'البوت يعمل بشكل صحيح! ✅'

@app.route('/webhook', methods=['POST'])
def webhook():
    \"\"\"استقبال التحديثات من تلجرام\"\"\"
    try:
        # الحصول على بيانات التحديث المرسلة من تلجرام
        update = request.get_json()
        logger.info(f'تحديث جديد: {update}')
        
        # التحقق من وجود رسالة
        if 'message' in update:
            message = update['message']
            handle_message(message)
        
        # يجب أن يرد الويب هوك بـ OK خلال ثوانٍ قليلة
        return 'OK', 200
    
    except Exception as e:
        logger.error(f'خطأ في معالجة التحديث: {e}')
        return 'Error', 500

# ============================================
# تشغيل التطبيق
# ============================================

if __name__ == '__main__':
    # ملاحظة: هذا الجزء يستخدم للاختبار المحلي فقط.
    # على PythonAnywhere، يتم تشغيل التطبيق بواسطة ملف WSGI.
    print(\"البوت يعمل محليًا. لا تستخدم هذا على PythonAnywhere.\")
    app.run(debug=True, host='0.0.0.0', port=5000)

