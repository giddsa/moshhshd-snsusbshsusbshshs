import React, { useMemo, memo } from 'react';
import { ComposedChart, Bar, Line, XAxis, YAxis, Tooltip, CartesianGrid, ResponsiveContainer, Legend, Cell, ReferenceLine } from 'recharts';
import { Kline, Language } from '../types';
import { calculateMACDForChart, calculateBollingerBandsForChart, calculateRSIForChart, calculateEMAArrayForChart } from '../services/analysisService';


export const CandleChart: React.FC<{ data: Kline[]; language: Language }> = memo(({ data, language }) => {
    
    const chartData = useMemo(() => {
        if (!data || data.length === 0) return [];
        const closePrices = data.map(k => k.close);
        
        const macdData = calculateMACDForChart(closePrices);
        const bbandsData = calculateBollingerBandsForChart(closePrices);
        const rsiData = calculateRSIForChart(closePrices);
        const ema9Data = calculateEMAArrayForChart(closePrices, 9);
        const ema21Data = calculateEMAArrayForChart(closePrices, 21);
        const ema50Data = calculateEMAArrayForChart(closePrices, 50);

        return data.map((kline, i) => ({
            ...kline,
            time: new Date(kline.timestamp).toLocaleTimeString(language === 'ar' ? 'ar-EG' : 'en-US', {
                hour: '2-digit',
                minute: '2-digit',
            }),
            macd: macdData[i],
            bbands: bbandsData[i],
            rsi: rsiData[i],
            ema9: ema9Data[i],
            ema21: ema21Data[i],
            ema50: ema50Data[i],
            volumeColor: kline.close >= kline.open ? 'rgba(35, 134, 54, 0.5)' : 'rgba(218, 54, 51, 0.5)',
        }));
    }, [data, language]);

    const CustomTooltip = ({ active, payload }: any) => {
        if (!active || !payload?.length) return null;
        const p = payload[0].payload;
        return (
            <div className="glass-card p-2 text-xs border border-brand-border">
                <p>Time: {new Date(p.timestamp).toLocaleString(language === 'ar' ? 'ar-EG' : 'en-US')}</p>
                <p>Open: {p.open}</p>
                <p>Close: {p.close}</p>
                <p>High: {p.high}</p>
                <p>Low: {p.low}</p>
                {p.ema9 && <p style={{ color: '#FFD700' }}>EMA 9: {p.ema9.toFixed(3)}</p>}
                {p.ema21 && <p style={{ color: '#ADFF2F' }}>EMA 21: {p.ema21.toFixed(3)}</p>}
                {p.ema50 && <p style={{ color: '#00FFFF' }}>EMA 50: {p.ema50.toFixed(3)}</p>}
                {p.bbands?.middle && <p style={{ color: '#FFA500' }}>BB Mid: {p.bbands.middle.toFixed(3)}</p>}
            </div>
        );
    };

    const MacdTooltip = ({ active, payload, label }: any) => {
        if (active && payload && payload.length) {
            const data = payload[0].payload.macd;
            return (
                <div className="glass-card p-2 text-xs border border-brand-border">
                    <p>Time: {label}</p>
                    {data.macd != null && <p style={{ color: '#00BFFF' }}>MACD: {data.macd.toFixed(4)}</p>}
                    {data.signal != null && <p style={{ color: '#FF6347' }}>Signal: {data.signal.toFixed(4)}</p>}
                    {data.hist != null && <p style={{ color: data.hist >= 0 ? '#238636' : '#DA3633' }}>Hist: {data.hist.toFixed(4)}</p>}
                </div>
            );
        }
        return null;
    };
    
    const RsiTooltip = ({ active, payload, label }: any) => {
        if (active && payload && payload.length) {
            return (
                <div className="glass-card p-2 text-xs border border-brand-border">
                    <p>Time: {label}</p>
                    {payload[0].payload.rsi != null && <p style={{ color: '#9370DB' }}>RSI: {payload[0].payload.rsi.toFixed(2)}</p>}
                </div>
            );
        }
        return null;
    };

    const VolumeTooltip = ({ active, payload, label }: any) => {
        if (active && payload && payload.length) {
            return (
                <div className="glass-card p-2 text-xs border border-brand-border">
                    <p>Time: {label}</p>
                    {payload[0].payload.volume != null && <p>Volume: {payload[0].payload.volume.toLocaleString()}</p>}
                </div>
            );
        }
        return null;
    };

    return (
        <div style={{ direction: 'ltr' }} className="mb-4">
            <ResponsiveContainer width="100%" height={300}>
                <ComposedChart data={chartData} margin={{ top: 5, right: 20, left: 0, bottom: 5 }} syncId="cryptoChart">
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--brand-border)" />
                    <XAxis dataKey="time" stroke="var(--brand-text-secondary)" fontSize={12} tickLine={false} axisLine={false} tick={false} />
                    <YAxis stroke="var(--brand-text-secondary)" fontSize={12} domain={['auto', 'auto']} allowDataOverflow={true} width={60} orientation="right" />
                    <Tooltip content={<CustomTooltip />} />
                    <Legend verticalAlign="top" height={36}/>
                    <Bar
                        dataKey={k => [k.low, k.high]}
                        shape={(props: any) => {
                            const { x, y, width, height, payload } = props;
                            const { open, close, high, low } = payload;
                            const isUp = close >= open;
                            const color = isUp ? '#238636' : '#DA3633';

                            const wick = <line x1={x + width / 2} y1={y} x2={x + width / 2} y2={y + height} stroke={color} strokeWidth={1}/>;
                            
                            if (high === low) return wick;
                            
                            const y_open = y + height * (high - open) / (high - low);
                            const y_close = y + height * (high - close) / (high - low);

                            const body_y = Math.min(y_open, y_close);
                            const body_height = Math.max(1, Math.abs(y_open - y_close));
                            
                            return (
                                <g>
                                    {wick}
                                    <rect x={x} y={body_y} width={width} height={body_height} fill={color} />
                                </g>
                            )
                        }}
                    />
                    <Line type="monotone" dataKey="bbands.upper" stroke="rgba(139, 148, 158, 0.5)" dot={false} name="BB Upper" strokeWidth={1} />
                    <Line type="monotone" dataKey="bbands.middle" stroke="rgba(255, 165, 0, 0.5)" dot={false} name="BB Middle" strokeWidth={1} strokeDasharray="3 3" />
                    <Line type="monotone" dataKey="bbands.lower" stroke="rgba(139, 148, 158, 0.5)" dot={false} name="BB Lower" strokeWidth={1} />
                    <Line type="monotone" dataKey="ema9" stroke="#FFD700" dot={false} name="EMA 9" strokeWidth={1.5}/>
                    <Line type="monotone" dataKey="ema21" stroke="#ADFF2F" dot={false} name="EMA 21" strokeWidth={1.5}/>
                    <Line type="monotone" dataKey="ema50" stroke="#00FFFF" dot={false} name="EMA 50" strokeWidth={1.5}/>
                </ComposedChart>
            </ResponsiveContainer>
             <ResponsiveContainer width="100%" height={100}>
                 <ComposedChart data={chartData} margin={{ top: 10, right: 20, left: 0, bottom: 5 }} syncId="cryptoChart">
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--brand-border)" />
                    <XAxis dataKey="time" stroke="var(--brand-text-secondary)" fontSize={12} tick={false} axisLine={false}/>
                    <YAxis stroke="var(--brand-text-secondary)" fontSize={12} domain={['auto', 'auto']} allowDataOverflow={true} width={60} orientation="right" />
                    <Tooltip content={<MacdTooltip />} />
                    <Legend verticalAlign="top" height={36}/>
                    <Bar dataKey="macd.hist" name="Histogram" barSize={4}>
                        {chartData.map((entry, index) => {
                            if (entry.macd.hist === null) return null;
                            return <Cell key={`cell-${index}`} fill={entry.macd.hist >= 0 ? 'rgba(35, 134, 54, 0.7)' : 'rgba(218, 54, 51, 0.7)'} />;
                        })}
                    </Bar>
                    <Line type="monotone" dataKey="macd.macd" stroke="#00BFFF" dot={false} name="MACD" strokeWidth={2}/>
                    <Line type="monotone" dataKey="macd.signal" stroke="#FF6347" dot={false} name="Signal" strokeWidth={2} />
                </ComposedChart>
            </ResponsiveContainer>
            <ResponsiveContainer width="100%" height={100}>
                <ComposedChart data={chartData} margin={{ top: 10, right: 20, left: 0, bottom: 5 }} syncId="cryptoChart">
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--brand-border)" />
                    <XAxis dataKey="time" stroke="var(--brand-text-secondary)" fontSize={12} tick={false} axisLine={false} />
                    <YAxis stroke="var(--brand-text-secondary)" fontSize={12} domain={[0, 100]} allowDataOverflow={true} width={60} orientation="right" />
                    <Tooltip content={<RsiTooltip />} />
                    <Legend verticalAlign="top" height={36}/>
                    <ReferenceLine y={70} stroke="var(--brand-danger)" strokeDasharray="3 3" />
                    <ReferenceLine y={30} stroke="var(--brand-success)" strokeDasharray="3 3" />
                    <Line type="monotone" dataKey="rsi" stroke="#9370DB" dot={false} name="RSI (14)" strokeWidth={2}/>
                </ComposedChart>
            </ResponsiveContainer>
            <ResponsiveContainer width="100%" height={100}>
                <ComposedChart data={chartData} margin={{ top: 10, right: 20, left: 0, bottom: 20 }} syncId="cryptoChart">
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--brand-border)" />
                    <XAxis dataKey="time" stroke="var(--brand-text-secondary)" fontSize={12} />
                    <YAxis stroke="var(--brand-text-secondary)" fontSize={12} domain={['auto', 'auto']} allowDataOverflow={true} width={60} orientation="right" />
                    <Tooltip content={<VolumeTooltip />} />
                    <Legend verticalAlign="top" height={36}/>
                    <Bar dataKey="volume" name="Volume">
                        {chartData.map((entry, index) => (
                            <Cell key={`cell-vol-${index}`} fill={entry.volumeColor} />
                        ))}
                    </Bar>
                </ComposedChart>
            </ResponsiveContainer>
        </div>
    );
});