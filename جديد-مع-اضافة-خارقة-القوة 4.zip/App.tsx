import React, { useState, useCallback, useMemo } from 'react';
import { Header } from './components/Header';
import { UploadPanel } from './components/UploadPanel';
import { SettingsPanel } from './components/SettingsPanel';
import { ResultsPanel } from './components/ResultsPanel';
import { Footer } from './components/Footer';
import { ChatPanel } from './components/ChatPanel';
import { AiTraderPanel } from './components/AiTraderPanel';
import { CryptoNewsPanel } from './components/CryptoNewsPanel';
import { LoadingSpinner, ErrorIcon, AnalyzerIcon, ChatBubbleIcon, BoltIcon, NewspaperIcon } from './components/Icons';
import { AnalysisResult, Kline, Language, UploadedImage, TradingType } from './types';
import { translations } from './constants';
import { processAnalysis } from './services/analysisService';
import { generateAnalysisExplanation, analyzeChartImage, getQuantumAnalysis } from './services/geminiService';
import { fetchHistoricalKlines, ApiError } from './services/backtestService';


type ActiveTab = 'analyzer' | 'ai-trader' | 'chat' | 'news';

const App: React.FC = () => {
    const [language, setLanguage] = useState<Language>('en');
    const [activeTab, setActiveTab] = useState<ActiveTab>('analyzer');
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);
    const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
    const [leverage, setLeverage] = useState<number>(10);
    const [tradingType, setTradingType] = useState<TradingType>('futures');
    const [klineData, setKlineData] = useState<Kline[] | null>(null);
    const [uploadedImage, setUploadedImage] = useState<UploadedImage | null>(null);
    const [symbol, setSymbol] = useState<string | null>(null);
    const [analysisSource, setAnalysisSource] = useState<'file' | 'symbol' | null>(null);

    const t = useMemo(() => translations[language], [language]);

    const handleAnalyze = useCallback(async () => {
        if (!klineData && !uploadedImage && !symbol) {
            setError(t.errorNoData);
            return;
        }

        setIsLoading(true);
        setError(null);
        setAnalysisResult(null);

        const finalLeverage = tradingType === 'spot' ? 1 : leverage;

        try {
            let finalResult: AnalysisResult = {};

            if (symbol) {
                setAnalysisSource('symbol');
                const fetchedKlines = await fetchHistoricalKlines(symbol, '1h');
                 if (fetchedKlines.length < 100) { 
                    throw new Error("Could not fetch enough historical data for a quantum analysis.");
                }
                setKlineData(fetchedKlines);
                
                const quantumResult = await getQuantumAnalysis(fetchedKlines, symbol, language);

                finalResult = {
                    ...quantumResult,
                    symbol: symbol.toUpperCase(),
                };

            } else if (uploadedImage) {
                setAnalysisSource('file');
                finalResult = await analyzeChartImage(uploadedImage, finalLeverage, language, tradingType);
            } else if (klineData) {
                setAnalysisSource('file');
                const numericalAnalysis = processAnalysis(klineData, finalLeverage, tradingType);
                const geminiExplanation = await generateAnalysisExplanation(numericalAnalysis, language);
                finalResult = {
                    ...numericalAnalysis,
                    ...geminiExplanation
                };
            } else {
                throw new Error("No data available to analyze.");
            }
            
            setAnalysisResult(finalResult);

        } catch (err) {
            console.error(err);
             if (err instanceof ApiError) {
                const errorMessage = t.errorUnsupportedSymbol
                    .replace('{symbol}', symbol || '');
                setError(errorMessage);
            } else {
                const errorMessage = (err instanceof Error) ? err.message : t.errorAnalysisFailed;
                if (errorMessage.includes('API key not valid')) {
                     setError(t.errorApiKey);
                } else if (symbol) {
                     setError(errorMessage);
                } else if (uploadedImage) {
                    setError(t.errorVisionAnalysisFailed);
                }
                else {
                     setError(errorMessage);
                }
            }
        } finally {
            setIsLoading(false);
        }
    }, [klineData, uploadedImage, symbol, leverage, tradingType, language, t]);

    const handleDataLoaded = useCallback((data: Kline[] | UploadedImage) => {
        setError(null);
        setAnalysisResult(null);
        setSymbol(null);
        setKlineData(null);
        setUploadedImage(null);
        if (Array.isArray(data)) {
            setKlineData(data);
        } else {
            setUploadedImage(data);
        }
    }, []);

    const handleSymbolChange = useCallback((newSymbol: string) => {
        setError(null);
        setAnalysisResult(null);
        setKlineData(null);
        setUploadedImage(null);
        setSymbol(newSymbol);
    }, []);

    const handleClear = useCallback(() => {
        setKlineData(null);
        setUploadedImage(null);
        setAnalysisResult(null);
        setError(null);
        setSymbol(null);
        setAnalysisSource(null);
    }, []);

    const renderContent = () => {
        switch (activeTab) {
            case 'analyzer':
                return (
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                        <div className="lg:col-span-1 flex flex-col gap-6">
                            <UploadPanel onDataLoaded={handleDataLoaded} onClear={handleClear} t={t} symbol={symbol} onSymbolChange={handleSymbolChange}/>
                            <SettingsPanel 
                                leverage={leverage} 
                                setLeverage={setLeverage}
                                tradingType={tradingType}
                                setTradingType={setTradingType} 
                                t={t} 
                            />
                            <button
                                onClick={handleAnalyze}
                                disabled={isLoading || (!klineData && !uploadedImage && !symbol)}
                                className="w-full main-button bg-brand-primary hover:bg-brand-secondary text-white font-bold py-3 px-4 rounded-lg transition duration-300 disabled:bg-gray-500 disabled:cursor-not-allowed flex items-center justify-center"
                            >
                                {isLoading && <LoadingSpinner />}
                                {isLoading ? t.analyzing : t.analyzeNow}
                            </button>
                            {error && (
                                 <div className="bg-red-900/50 border border-brand-danger text-red-300 px-4 py-3 rounded-lg relative flex items-start space-x-2 rtl:space-x-reverse" role="alert">
                                    <ErrorIcon className="h-5 w-5 mt-0.5"/>
                                    <span>{error}</span>
                                </div>
                            )}
                        </div>
                        <div className="lg:col-span-2">
                            <ResultsPanel result={analysisResult} isLoading={isLoading} t={t} analysisSource={analysisSource} language={language} klineData={klineData}/>
                        </div>
                    </div>
                );
            case 'ai-trader':
                return <AiTraderPanel t={t} language={language} />;
            case 'chat':
                return <ChatPanel t={t} language={language} />;
            case 'news':
                return <CryptoNewsPanel t={t} language={language} />;
            default:
                return null;
        }
    };

    return (
        <div dir={language === 'ar' ? 'rtl' : 'ltr'} className={`${language === 'ar' ? 'font-arabic' : 'font-sans'} min-h-screen bg-brand-bg text-brand-text-primary flex flex-col`}>
            <Header language={language} setLanguage={setLanguage} t={t} />
            <main className="flex-grow container mx-auto p-4 md:p-6 lg:p-8">
                <div className="mb-6 glass-card p-2">
                    <div className="border-b border-brand-border">
                        <nav className="-mb-px flex space-x-6 rtl:space-x-reverse overflow-x-auto">
                            <button
                                onClick={() => setActiveTab('analyzer')}
                                className={`${
                                    activeTab === 'analyzer'
                                        ? 'border-brand-primary text-brand-primary'
                                        : 'border-transparent text-brand-text-secondary hover:text-brand-text-primary hover:border-gray-500'
                                } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm flex items-center gap-2`}
                            >
                                <AnalyzerIcon className="w-5 h-5" />
                                {t.analyzerTab}
                            </button>
                             <button
                                onClick={() => setActiveTab('ai-trader')}
                                className={`${
                                    activeTab === 'ai-trader'
                                        ? 'border-brand-primary text-brand-primary'
                                        : 'border-transparent text-brand-text-secondary hover:text-brand-text-primary hover:border-gray-500'
                                } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm flex items-center gap-2`}
                            >
                                <BoltIcon className="w-5 h-5" />
                                {t.aiAssistant}
                            </button>
                            <button
                                onClick={() => setActiveTab('chat')}
                                className={`${
                                    activeTab === 'chat'
                                        ? 'border-brand-primary text-brand-primary'
                                        : 'border-transparent text-brand-text-secondary hover:text-brand-text-primary hover:border-gray-500'
                                } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm flex items-center gap-2`}
                            >
                                <ChatBubbleIcon className="w-5 h-5"/>
                                {t.chatTab}
                            </button>
                             <button
                                onClick={() => setActiveTab('news')}
                                className={`${
                                    activeTab === 'news'
                                        ? 'border-brand-primary text-brand-primary'
                                        : 'border-transparent text-brand-text-secondary hover:text-brand-text-primary hover:border-gray-500'
                                } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm flex items-center gap-2`}
                            >
                                <NewspaperIcon className="w-5 h-5"/>
                                {t.newsTab}
                            </button>
                        </nav>
                    </div>
                </div>

                {renderContent()}

            </main>
            <Footer t={t} />
        </div>
    );
};

export default App;