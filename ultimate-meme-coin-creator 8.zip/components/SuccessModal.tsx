import React from 'react';
import Button from './ui/Button';

interface RemoveLiquidityModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  tokenSymbol: string;
}

const RemoveLiquidityModal: React.FC<RemoveLiquidityModalProps> = ({ isOpen, onClose, onConfirm, tokenSymbol }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50">
      <div className="bg-gray-900 border border-red-500 rounded-lg p-8 max-w-lg w-full text-center shadow-2xl shadow-red-500/20">
        <h2 className="text-2xl font-bold mb-2 text-red-400">تحذير: سحب السيولة</h2>
        <p className="text-gray-400 mb-6">
          سحب السيولة بالكامل سيوقف التداول على التوكن، وقد يؤدي إلى انهيار سعره. تأكد قبل المتابعة.
        </p>
        
        <div className="p-4 bg-gray-800 rounded-lg mb-6 text-left space-y-2">
            <h4 className="font-semibold">المبلغ المتوقع استرداده:</h4>
            <p className="font-mono text-purple-300">~10.5 SOL</p>
            <p className="font-mono text-purple-300">~5,000,000 ${tokenSymbol}</p>
        </div>

        <div className="flex justify-center gap-4">
            <Button onClick={onClose} variant="secondary">
              إلغاء
            </Button>
            <Button onClick={onConfirm} className="bg-red-600 hover:bg-red-700 focus:ring-red-500">
              تأكيد السحب
            </Button>
        </div>
      </div>
    </div>
  );
};

export default RemoveLiquidityModal;
