import React, { useState, useMemo } from 'react';
import type { TokenData } from '../types';
import { Network } from '../types';
import { DEX_OPTIONS } from '../constants';
import Input from './ui/Input';
import Select from './ui/Select';
import Checkbox from './ui/Checkbox';
import Button from './ui/Button';
import RocketIcon from './icons/RocketIcon';
import QuestionMarkCircleIcon from './icons/QuestionMarkCircleIcon';
import { Connection, PublicKey, Keypair, Transaction, SystemProgram, clusterApiUrl, LAMPORTS_PER_SOL } from '@solana/web3.js';
import { createInitializeMintInstruction, getOrCreateAssociatedTokenAccount, mintTo, createSetAuthorityInstruction, AuthorityType, MINT_SIZE, TOKEN_PROGRAM_ID } from '@solana/spl-token';


// --- Internal UI Components ---
const Tooltip: React.FC<{ text: string; children: React.ReactNode }> = ({ text, children }) => (
  <div className="relative flex items-center group">
    {children}
    <div className="absolute bottom-full mb-2 w-max max-w-xs p-2 text-xs text-white bg-gray-800 border border-gray-600 rounded-md shadow-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300 z-10">
      {text}
    </div>
  </div>
);

const ProgressBar: React.FC<{ percentage: number; text: string }> = ({ percentage, text }) => (
    <div className="w-full bg-gray-700 rounded-full h-8">
        <div 
            className="bg-gradient-to-r from-purple-500 to-blue-500 h-8 rounded-full flex items-center justify-center text-sm font-medium transition-all duration-500"
            style={{ width: `${percentage}%` }}
        >
           {text} ({percentage}%)
        </div>
    </div>
);


// --- Main Creator Page Component ---
interface CreatorPageProps {
  onTokenCreated: (tokenData: TokenData, txSignature: string) => void;
  walletAddress: string | null;
  manualSigner: any | null; // Solana Keypair
}

const CreatorPage: React.FC<CreatorPageProps> = ({ onTokenCreated, walletAddress, manualSigner }) => {
  const [formData, setFormData] = useState<TokenData>({
    name: '',
    symbol: '',
    decimals: 9,
    supply: 1000000,
    creatorInfo: '',
    creatorName: '',
    creatorAddress: '',
    logo: undefined,
    recipientAddress: '',
    launchKey: Math.random().toString(36).substring(2, 15),
    network: Network.Solana,
    liquidity: {
        enabled: false,
        percentage: 50,
        dex: undefined,
        lockEnabled: false,
        lockDuration: 365,
        allowRemovalAfterLaunch: true,
    },
    advanced: {
      mintable: false,
      burnable: false,
      renounceOwnership: false,
      taxPercentage: 0
    },
  });
  const [logoPreview, setLogoPreview] = useState<string | null>(null);
  const [progress, setProgress] = useState({ percentage: 0, message: ''});
  const isCreating = progress.percentage > 0 && progress.percentage < 100;
  const [error, setError] = useState<string | null>(null);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    const isCheckbox = type === 'checkbox';
    const checked = isCheckbox ? (e.target as HTMLInputElement).checked : undefined;
  
    const nameParts = name.split('.');
  
    if (nameParts.length > 1) {
      const [section, field] = nameParts;
      setFormData(prev => ({
        ...prev,
        [section]: {
          // eslint-disable-next-line @typescript-eslint/ban-ts-comment
          // @ts-ignore
          ...prev[section],
          [field]: isCheckbox ? checked : value,
        },
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        [name]: isCheckbox ? checked : value,
      }));
    }
  };

  const handleLogoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const reader = new FileReader();
      reader.onloadend = () => {
        setLogoPreview(reader.result as string);
        setFormData(prev => ({ ...prev, logo: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!walletAddress) {
        setError("الرجاء ربط محفظتك أولاً للمتابعة.");
        return;
    }

    if (formData.network !== Network.Solana) {
        setError("حاليًا، يتم دعم إنشاء العملات على شبكة سولانا فقط.");
        return;
    }
    
    // @ts-ignore
    const provider = window.solana;
    if (!manualSigner && (!provider || !provider.isPhantom)) {
        setError("الرجاء التأكد من أن محفظة Phantom مثبتة أو استخدم الاتصال اليدوي.");
