import React, { useState, useEffect, useCallback } from 'react';
import Header from './components/Header';
import Footer from './components/Footer';
import HomePage from './components/HomePage';
import CreatorPage from './components/CreatorPage';
import TokenDetailsPage from './components/TokenDetailsPage';
import type { TokenData, User, Transaction } from './types';
import { Page } from './types';
import Button from './components/ui/Button';
import Input from './components/ui/Input';
import { Keypair } from '@solana/web3.js';


// --- New Page Components defined within App.tsx ---

// LoginPage Component
const LoginPage: React.FC<{ onLogin: (email: string, pass: string) => boolean; onSignup: (email: string, pass: string) => boolean; onNavigate: (page: Page) => void; }> = ({ onLogin, onSignup, onNavigate }) => {
  const [isLoginView, setIsLoginView] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    const success = isLoginView ? onLogin(email, password) : onSignup(email, password);
    if (success) {
      onNavigate(Page.Dashboard);
    } else {
      setError(isLoginView ? 'البريد الإلكتروني أو كلمة المرور غير صحيحة.' : 'هذا المستخدم موجود بالفعل.');
    }
  };

  return (
    <div className="max-w-md mx-auto mt-10 p-8 bg-gray-900/50 border border-gray-700 rounded-lg">
      <h2 className="text-3xl font-bold text-center mb-6 text-purple-400">{isLoginView ? 'تسجيل الدخول' : 'إنشاء حساب جديد'}</h2>
      <form onSubmit={handleSubmit} className="space-y-6">
        <Input label="البريد الإلكتروني" type="email" value={email} onChange={e => setEmail(e.target.value)} required />
        <Input label="كلمة المرور" type="password" value={password} onChange={e => setPassword(e.target.value)} required />
        {error && <p className="text-red-400 text-sm">{error}</p>}
        <Button type="submit" variant="primary" className="w-full">{isLoginView ? 'تسجيل الدخول' : 'إنشاء حساب'}</Button>
      </form>
      <p className="text-center mt-4">
        <button onClick={() => setIsLoginView(!isLoginView)} className="text-purple-400 hover:underline">
          {isLoginView ? 'ليس لديك حساب؟ أنشئ واحدًا' : 'لديك حساب بالفعل؟ سجل الدخول'}
        </button>
      </p>
    </div>
  );
};

// DashboardPage Component
const DashboardPage: React.FC<{ user: User; onNavigate: (page: Page, token?: TokenData) => void; onLogout: () => void }> = ({ user, onNavigate, onLogout }) => {
  return (
    <div className="max-w-6xl mx-auto">
      <div className="flex justify-between items-center mb-8">
        <h2 className="text-3xl font-bold">لوحة التحكم</h2>
        <Button onClick={onLogout} variant="secondary">تسجيل الخروج</Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2 p-6 bg-gray-900/50 border border-gray-700 rounded-lg">
          <h3 className="text-xl font-semibold mb-4 text-purple-400">عملاتي</h3>
          <div className="space-y-4">
            {user.createdTokens.length > 0 ? user.createdTokens.map(token => (
              <div key={token.contractAddress} className="flex justify-between items-center p-3 bg-gray-800 rounded-md">
                <div>
                  <p className="font-bold">{token.name} (${token.symbol})</p>
                  <p className="text-sm text-gray-400">{token.network}</p>
                </div>
                <div className="flex gap-2">
                  <Button size="sm" onClick={() => onNavigate(Page.Details, token)}>عرض التفاصيل</Button>
                </div>
              </div>
            )) : <p className="text-gray-400">لم تقم بإنشاء أي عملات بعد.</p>}
          </div>
        </div>

        <div className="p-6 bg-gray-900/50 border border-gray-700 rounded-lg">
          <h3 className="text-xl font-semibold mb-4 text-purple-400">محفظتي</h3>
          <p className="font-mono text-purple-300 break-all">{user.walletAddress || 'لم يتم ربط أي محفظة'}</p>
           <h3 className="text-xl font-semibold mb-4 mt-6 text-purple-400">معاملاتي</h3>
           <div className="space-y-2 text-sm">
             {user.transactions.length > 0 ? user.transactions.map((tx, i) => (
                <div key={i} className="text-gray-400">
                    <p>{tx.type} for ${tx.tokenSymbol} - <a href={`https://solscan.io/tx/${tx.txHash}?cluster=devnet`} target="_blank" rel="noopener noreferrer" className="font-mono text-xs text-blue-400 hover:underline">{new Date(tx.date).toLocaleDateString()}</a></p>
                </div>
             )) : <p className="text-gray-400">لا يوجد معاملات.</p>}
           </div>
        </div>
      </div>
    </div>
  );
};

// GuidePage Component
const GuidePage: React.FC = () => {
    return (
        <div className="max-w-4xl mx-auto p-8 bg-gray-900/50 border border-gray-700 rounded-lg prose prose-invert prose-headings:text-purple-400 prose-a:text-blue-400">
            <h2>شرح المنصة</h2>
            
            <h3>ما هي المنصة؟</h3>
            <p>Ultimate Meme Coin Creator هي أداة مجانية تسمح لك بإنشاء عملة رقمية (توكن) خاصة بك على شبكات بلوكتشين شهيرة مثل سولانا، BSC، وإيثيريوم، بدون الحاجة لأي خبرة برمجية.</p>

            <h3>شرح الحقول</h3>
            <p>هنا شرح لكل خيار ستجده في صفحة إنشاء التوكن:</p>
            <ul>
                <li><strong>اسم التوكن:</strong> الاسم الكامل لعملتك (مثال: My Cool Coin).</li>
                <li><strong>رمز التوكن:</strong> الرمز المختصر للعملة (مثال: MCC).</li>
                <li><strong>السيولة (Liquidity):</strong> هي ميزة أساسية تسمح للمستخدمين بتداول عملتك. عند تفعيلها، يتم إيداع جزء من عملاتك مع عملة أخرى (مثل SOL أو BNB) في منصة تداول لا مركزية (DEX)، مما يخلق سوقًا لعملتك.</li>
                <li><strong>قفل السيولة:</strong> يعني حجز أموال السيولة لفترة محددة، مما يزيد من ثقة المستثمرين في مشروعك.</li>
            </ul>

            <h3>ربط المحفظة</h3>
            <p>للتفاعل مع المنصة، يجب ربط محفظة Web3 مثل Phantom (لسولانا) أو MetaMask (لإيثيريوم و BSC). اضغط على زر "ربط المحفظة" في الأعلى واتبع التعليمات.</p>

            <h3>تحذيرات هامة</h3>
            <p><strong>الموقع لا يحتفظ بالمفاتيح الخاصة إطلاقًا.</strong> جميع العمليات التي تتطلب أموالًا أو صلاحيات تتم وتُوقّع من خلال محفظتك الشخصية فقط. أنت المسؤول الوحيد عن أمان محفظتك.</p>
        </div>
    );
}

// ManualConnectModal Component
const ManualConnectModal: React.FC<{ isOpen: boolean; onClose: () => void; onConnect: (secretKey: string) => void; }> = ({ isOpen, onClose, onConnect }) => {
    const [secretKey, setSecretKey] = useState('');
    const [error, setError] = useState('');

    if (!isOpen) return null;

    const handleSubmit = () => {
        setError('');
        if (!secretKey.trim()) {
            setError('المفتاح السري لا يمكن أن يكون فارغًا.');
            return;
        }
        try {
            // Basic validation for the array format
            const parsedKey = JSON.parse(secretKey);
            if (!Array.isArray(parsedKey) || parsedKey.length !== 64 || !parsedKey.every(n => typeof n === 'number')) {
                throw new Error('Invalid key format');
            }
            onConnect(secretKey);
        } catch (e) {
            setError('صيغة المفتاح السري غير صالحة. يجب أن تكون مصفوفة من 64 رقمًا، مثال: [1,2,3,...,64]');
        }
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50">
            <div className="bg-gray-900 border border-yellow-500 rounded-lg p-8 max-w-lg w-full shadow-2xl">
                <h2 className="text-2xl font-bold mb-4 text-yellow-400">الاتصال يدويًا</h2>
                <div className="p-4 bg-red-900/50 border border-red-500 rounded-lg mb-4 text-red-300 text-sm">
                    <strong>تحذير أمني خطير:</strong> هذه الطريقة غير آمنة للغاية. لا تستخدمها أبدًا مع محفظة تحتوي على أموال حقيقية. مخصصة للاستخدام الشخصي والتجريبي فقط.
                </div>
                <div className="space-y-4">
                    <Input 
                        label="أدخل مفتاحك السري (Secret Key) بتنسيق Uint8Array"
                        type="text"
                        value={secretKey}
                        onChange={(e) => setSecretKey(e.target.value)}
                        placeholder="[123, 45, 67, ...]"
                    />
                    {error && <p className="text-red-400 text-sm">{error}</p>}
                </div>
                <div className="flex justify-end gap-4 mt-6">
                    <Button onClick={onClose} variant="secondary">إلغاء</Button>
                    <Button onClick={handleSubmit}>اتصال</Button>
                </div>
            </div>
        </div>
    );
};


// --- Main App Component ---
const App: React.FC = () => {
  const [currentPage, setCurrentPage] = useState<Page>(Page.Home);
  const [activeToken, setActiveToken] = useState<TokenData | null>(null);
  const [isNewToken, setIsNewToken] = useState(false);
  
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [usersDb, setUsersDb] = useState<Record<string, User>>({});
  
  // Wallet State
  const [walletAddress, setWalletAddress] = useState<string | null>(null);
  const [isConnecting, setIsConnecting] = useState<boolean>(false);
  const [walletError, setWalletError] = useState<string | null>(null);
  const [isManualConnectOpen, setIsManualConnectOpen] = useState(false);
  const [manualSigner, setManualSigner] = useState<any | null>(null);

  // --- Data Persistence ---
  useEffect(() => {
    try {
      const savedUsers = localStorage.getItem('usersDb');
      if (savedUsers) {
        setUsersDb(JSON.parse(savedUsers));
      }
      const savedUserEmail = localStorage.getItem('currentUserEmail');
      if (savedUserEmail && savedUsers) {
        const users = JSON.parse(savedUsers);
        if (users[savedUserEmail]) {
          setCurrentUser(users[savedUserEmail]);
          setWalletAddress(users[savedUserEmail].walletAddress || null);
        }
      }
    } catch (error) {
      console.error("Failed to parse from localStorage", error);
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('usersDb', JSON.stringify(usersDb));
  }, [usersDb]);

  useEffect(() => {
    if (currentUser) {
      localStorage.setItem('currentUserEmail', currentUser.email);
    } else {
      localStorage.removeItem('currentUserEmail');
    }
  }, [currentUser]);

  // --- Wallet Logic ---
  const handleConnectWallet = useCallback(async () => {
    setIsConnecting(true);
    setWalletError(null);
    setManualSigner(null);
    try {
      // @ts-ignore
      const { solana } = window;
      if (solana && solana.isPhantom) {
        const response = await solana.connect({ onlyIfTrusted: false });
        const newAddress = response.publicKey.toString();
        setWalletAddress(newAddress);
        if (currentUser) {
          const updatedUser = { ...currentUser, walletAddress: newAddress };
          setCurrentUser(updatedUser);
          setUsersDb(prev => ({ ...prev, [currentUser.email]: updatedUser }));
        }
      } else {
        setWalletError("محفظة Phantom غير مثبتة. الرجاء تثبيت الإضافة للمتابعة.");
      }
    } catch (error: any) {
      console.error("Wallet connection failed:", error);
      if (error.message && error.message.includes("User rejected the request")) {
        setWalletError("لقد قمت برفض طلب الاتصال بالمحفظة.");
      } else {
        setWalletError("فشل الاتصال بالمحفظة. الرجاء المحاولة مرة أخرى.");
      }
    } finally {
      setIsConnecting(false);
    }
  }, [currentUser]);

  const handleManualConnect = (secretKeyStr: string) => {
      try {
          const secretKey = Uint8Array.from(JSON.parse(secretKeyStr));
          const keypair = Keypair.fromSecretKey(secretKey);
          setManualSigner(keypair);
          const newAddress = keypair.publicKey.toString();
          setWalletAddress(newAddress);
           if (currentUser) {
              const updatedUser = { ...currentUser, walletAddress: newAddress };
              setCurrentUser(updatedUser);
              setUsersDb(prev => ({ ...prev, [currentUser.email]: updatedUser }));
           }
          setWalletError(null);
          setIsManualConnectOpen(false);
      } catch (error) {
          console.error("Manual connect failed:", error);
          // Error is handled inside the modal
      }
  };


  // --- Auth Logic ---
  const handleLogin = (email: string, pass: string): boolean => {
    const user = usersDb[email];
    if (user && user.password === pass) {
      setCurrentUser(user);
      if(user.walletAddress) setWalletAddress(user.walletAddress);
      setCurrentPage(Page.Dashboard); 
      return true;
    }
    return false;
  };

  const handleSignup = (email: string, pass: string): boolean => {
    if (usersDb[email]) {
      return false; 
    }
    const newUser: User = {
      email,
      password: pass,
      createdTokens: [],
      transactions: [],
      walletAddress: walletAddress || undefined,
    };
    setUsersDb(prev => ({ ...prev, [email]: newUser }));
    setCurrentUser(newUser);
    setCurrentPage(Page.Dashboard);
    return true;
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setWalletAddress(null);
    setManualSigner(null);
    setCurrentPage(Page.Home);
  };

  // --- Navigation & State ---
  const handleNavigate = (page: Page, token?: TokenData) => {
    setCurrentPage(page);
    if (token) {
        setActiveToken(token);
    }
    setIsNewToken(false);
  };

  const handleCreateTokenSuccess = (tokenData: TokenData, txSignature: string) => {
    setActiveToken(tokenData);
    setIsNewToken(true);
    setCurrentPage(Page.Details);

    if (currentUser) {
        const newTransaction: Transaction = {
            type: 'Create Token',
            tokenSymbol: tokenData.symbol,
            date: new Date().toISOString(),
            txHash: txSignature
        };
        const updatedUser = {
            ...currentUser,
            createdTokens: [...currentUser.createdTokens, tokenData],
            transactions: [...currentUser.transactions, newTransaction]
        };
        setCurrentUser(updatedUser);
        setUsersDb(prev => ({ ...prev, [currentUser.email]: updatedUser }));
    }
  };
  
   const handleRemoveLiquidity = (tokenSymbol: string) => {
        if (currentUser) {
            const newTransaction: Transaction = {
                type: 'Remove Liquidity',
                tokenSymbol: tokenSymbol,
                date: new Date().toISOString(),
                txHash: 'SIMULATED_TX_HASH_' + Math.random().toString(36).substring(7) 
            };
            const updatedUser = {
                ...currentUser,
                transactions: [...currentUser.transactions, newTransaction]
            };
            setCurrentUser(updatedUser);
            setUsersDb(prev => ({ ...prev, [currentUser.email]: updatedUser }));
        }
    };
    
   const handleBurnTokens = (tokenSymbol: string, txSignature: string) => {
        if (currentUser) {
            const newTransaction: Transaction = {
                type: 'Burn Token',
                tokenSymbol: tokenSymbol,
                date: new Date().toISOString(),
                txHash: txSignature
            };
            const updatedUser = {
                ...currentUser,
                transactions: [...currentUser.transactions, newTransaction]
            };
            setCurrentUser(updatedUser);
            setUsersDb(prev => ({ ...prev, [currentUser.email]: updatedUser }));
        }
   };


  const renderContent = () => {
    switch (currentPage) {
      case Page.Creator:
        return <CreatorPage onTokenCreated={handleCreateTokenSuccess} walletAddress={walletAddress} manualSigner={manualSigner} />;
      case Page.Details:
        return activeToken ? <TokenDetailsPage token={activeToken} isNew={isNewToken} onNavigateToCreator={() => handleNavigate(Page.Creator)} onRemoveLiquidity={handleRemoveLiquidity} onBurnTokens={handleBurnTokens} walletAddress={walletAddress} manualSigner={manualSigner} /> : <HomePage onNavigateToCreator={() => handleNavigate(Page.Creator)} />;
      case Page.Login:
        return <LoginPage onLogin={handleLogin} onSignup={handleSignup} onNavigate={handleNavigate} />;
      case Page.Dashboard:
        return currentUser ? <DashboardPage user={currentUser} onNavigate={handleNavigate} onLogout={handleLogout} /> : <LoginPage onLogin={handleLogin} onSignup={handleSignup} onNavigate={handleNavigate} />;
      case Page.Guide:
        return <GuidePage />;
      case Page.Home:
      default:
        return <HomePage onNavigateToCreator={() => handleNavigate(Page.Creator)} />;
    }
  };

  return (
    <div className="bg-black text-white min-h-screen flex flex-col">
      <ManualConnectModal 
        isOpen={isManualConnectOpen}
        onClose={() => setIsManualConnectOpen(false)}
        onConnect={handleManualConnect}
      />
      <Header 
        isLoggedIn={!!currentUser}
        onNavigate={handleNavigate}
        onLogout={handleLogout}
        onConnectWallet={handleConnectWallet}
        walletAddress={walletAddress}
        isConnecting={isConnecting}
      />
      <main className="container mx-auto px-4 flex-grow">
        {walletError && (
          <div className="bg-red-500/20 border border-red-500 text-red-300 p-3 rounded-lg mb-6 text-center text-sm flex flex-col items-center gap-2 md:flex-row md:justify-center">
            <span>{walletError}</span>
            {walletError.includes("محفظة Phantom غير مثبتة") && (
              <div className="flex gap-2 mt-2 md:mt-0 md:ms-4">
                 <Button
                    variant="secondary"
                    size="sm"
                    onClick={() => setIsManualConnectOpen(true)}
                  >
                    الاتصال يدويًا
                  </Button>
                <Button
                  variant="secondary"
                  size="sm"
                  href="https://phantom.app/download"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  تثبيت Phantom
                </Button>
              </div>
            )}
          </div>
        )}
        {renderContent()}
      </main>
      <Footer />
    </div>
  );
};

export default App;