// SHΔDØW CORE – apple.js
(() => {
  const ROWS = 5, COLS = 10, TOTAL = ROWS * COLS;
  // إحداثي التفاحة السليمة داخل السبرايت (غيّر حسب الحاجة)
  const GOOD_POS = {x: -128, y: -256};

  const board = document.getElementById('board');
  const cells = [];

  // بناء الشبكة
  for (let i = 0; i < TOTAL; i++) {
    const c = document.createElement('div');
    c.className = 'cell';
    c.dataset.idx = i;
    board.appendChild(c);
    cells.push(c);
  }

  // وظيفة فحص الخلية
  const checkCell = (el) => {
    if (el.__sh) return;           // تم فحصها سابقاً
    el.__sh = true;
    const pos = getComputedStyle(el).backgroundPosition.match(/(-?\d+)px\s+(-?\d+)px/);
    if (!pos) return;
    const x = +pos[1], y = +pos[2];
    if (x === GOOD_POS.x && y === GOOD_POS.y) {
      el.classList.add('safe');    // إطار أخضر
      el.title = 'تفاحة صالحة (Shadow Vision)';
    }
  };

  // فحص أولي + مراقبة تغيّرات DOM
  const scan = () => cells.forEach(checkCell);
  const obs = new MutationObserver(scan);
  obs.observe(board, {childList: true, subtree: true});

  // فحص دوري للتأكد
  setInterval(scan, 400);
  scan(); // تشغيل فوري
})();
