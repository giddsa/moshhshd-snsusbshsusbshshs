export enum Network {
  Solana = 'Solana',
  BSC = 'BSC',
  Ethereum = 'Ethereum',
}

export interface TokenData {
  name: string;
  symbol: string;
  decimals: number;
  supply: number;
  creatorInfo?: string;
  creatorName?: string;
  creatorAddress?: string;
  logo?: string;
  liquidity: {
    enabled: boolean;
    percentage?: number;
    dex?: string;
    lockEnabled?: boolean;
    lockDuration?: number;
    allowRemovalAfterLaunch?: boolean;
  };
  recipientAddress: string;
  launchKey: string;
  network: Network;
  advanced: {
    mintable: boolean;
    burnable: boolean;
    taxPercentage?: number;
    renounceOwnership: boolean;
  };
  contractAddress?: string;
}

export enum Page {
    Home = 'Home',
    Creator = 'Creator',
    Details = 'Details',
    Dashboard = 'Dashboard',
    Guide = 'Guide',
    Login = 'Login'
}


export interface Transaction {
    type: 'Create Token' | 'Add Liquidity' | 'Remove Liquidity' | 'Burn Token';
    tokenSymbol: string;
    date: string;
    txHash: string;
}

export interface User {
    email: string;
    password?: string; // In a real app, this would be a hash
    walletAddress?: string;
    createdTokens: TokenData[];
    transactions: Transaction[];
}