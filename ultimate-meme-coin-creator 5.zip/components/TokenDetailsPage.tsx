import React, { useState } from 'react';
import type { TokenData } from '../types';
import { EXPLORER_URLS } from '../constants';
import CopyIcon from './icons/CopyIcon';
import ExternalLinkIcon from './icons/ExternalLinkIcon';
import Button from './ui/Button';
import RemoveLiquidityModal from './SuccessModal'; // Repurposed for Remove Liquidity
import Input from './ui/Input';

// --- Global Solana instances from scripts ---
declare const solanaWeb3: any;
declare const splToken: any;


interface TokenDetailsPageProps {
  token: TokenData;
  isNew?: boolean;
  onNavigateToCreator: () => void;
  onRemoveLiquidity: (tokenSymbol: string) => void;
  onBurnTokens: (tokenSymbol: string, txSignature: string) => void;
  walletAddress: string | null;
  manualSigner: any | null; // Solana Keypair
}

const DetailRow: React.FC<{ label: string; value: React.ReactNode; isAddress?: boolean; network?: string }> = ({ label, value, isAddress, network }) => {
  const handleCopy = () => {
    if (typeof value === 'string') {
      navigator.clipboard.writeText(value);
    }
  };
  
  const explorerUrl = network && isAddress && typeof value === 'string' ? `${EXPLORER_URLS[network as keyof typeof EXPLORER_URLS]}${value}?cluster=devnet` : '#';

  return (
    <div className="flex justify-between items-center py-3 border-b border-gray-800">
      <span className="text-gray-400">{label}</span>
      <div className="flex items-center gap-2">
        <span className="font-mono text-purple-300 break-all">{value}</span>
        {isAddress && typeof value === 'string' && (
          <>
            <button onClick={handleCopy} title="نسخ العنوان" className="text-gray-400 hover:text-white transition">
              <CopyIcon className="w-4 h-4" />
            </button>
            <a href={explorerUrl} target="_blank" rel="noopener noreferrer" title="عرض على المستكشف" className="text-gray-400 hover:text-white transition">
               <ExternalLinkIcon className="w-4 h-4" />
            </a>
          </>
        )}
      </div>
    </div>
  );
};


const TokenDetailsPage: React.FC<TokenDetailsPageProps> = ({ token, isNew, onNavigateToCreator, onRemoveLiquidity, onBurnTokens, walletAddress, manualSigner }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [burnAmount, setBurnAmount] = useState('');
  const [isBurning, setIsBurning] = useState(false);
  const [burnError, setBurnError] = useState<string | null>(null);

  const explorerUrl = token.contractAddress ? `${EXPLORER_URLS[token.network]}${token.contractAddress}?cluster=devnet` : '#';

  const handleRemoveLiquidityConfirm = () => {
    console.log('Removing liquidity for', token.symbol);
    onRemoveLiquidity(token.symbol);
    setIsModalOpen(false);
    // Here you would trigger the wallet transaction
  };

  const handleBurn = async () => {
      if (!walletAddress || !token.contractAddress) {
          setBurnError("المحفظة غير متصلة أو عنوان العقد غير صالح.");
          return;
      }
      const amount = parseFloat(burnAmount);
      if (isNaN(amount) || amount <= 0) {
          setBurnError("الرجاء إدخال كمية صالحة للحرق.");
          return;
      }

      setIsBurning(true);
      setBurnError(null);

      try {
        const { Connection, PublicKey, Transaction } = solanaWeb3;
        const { getOrCreateAssociatedTokenAccount, createBurnInstruction } = splToken;
        const connection = new Connection(solanaWeb3.clusterApiUrl('devnet'), 'confirmed');
        // @ts-ignore
        const provider = window.solana;
        const fromWallet = new PublicKey(walletAddress);
        const mint = new PublicKey(token.contractAddress);
        const payer = manualSigner || { publicKey: fromWallet, signTransaction: provider.signTransaction };

        const fromTokenAccount = await getOrCreateAssociatedTokenAccount(
            connection,
            payer,
            mint,
            fromWallet
        );

        const transaction = new Transaction().add(
            createBurnInstruction(
                fromTokenAccount.address,
                mint,
                fromWallet, // Authority
                amount * Math.pow(10, token.decimals)
            )
        );

        const { blockhash } = await connection.getLatestBlockhash();
        transaction.recentBlockhash = blockhash;
        transaction.feePayer = fromWallet;

        let signature;
        if (manualSigner) {
            transaction.sign(manualSigner);
            signature = await connection.sendRawTransaction(transaction.serialize());
        } else {
            const signedTransaction = await provider.signTransaction(transaction);
            signature = await connection.sendRawTransaction(signedTransaction.serialize());
        }
        
        await connection.confirmTransaction(signature, 'confirmed');

        onBurnTokens(token.symbol, signature);
        alert("تم حرق العملات بنجاح!");
        setBurnAmount('');

      } catch (err: any) {
          console.error("Burn failed:", err);
          let userMessage = "فشلت عملية الحرق.";
          if (err.message.includes("User rejected the request")) {
              userMessage = "لقد قمت برفض المعاملة في محفظتك.";
          }
          setBurnError(userMessage);
      } finally {
          setIsBurning(false);
      }
  };

  return (
    <>
      <RemoveLiquidityModal 
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onConfirm={handleRemoveLiquidityConfirm}
        tokenSymbol={token.symbol}
      />
      <div className="max-w-4xl mx-auto">
        <div className="flex justify-between items-center mb-6">
            <h2 className="text-4xl font-bold">تفاصيل العملة</h2>
            <Button onClick={onNavigateToCreator}>
                إنشاء توكن جديد 🔁
            </Button>
        </div>

        {isNew && (
            <div className="bg-green-500/20 border border-green-500 text-green-300 p-4 rounded-lg mb-6 text-center">
                <h3 className="font-bold text-xl">تم إنشاء عملتك بنجاح 🎉</h3>
            </div>
        )}

        <div className="p-6 bg-gray-900/50 border border-gray-700 rounded-lg">
          <div className="flex flex-col md:flex-row items-center gap-6 mb-8">
            {token.logo && <img src={token.logo} alt={`${token.name} logo`} className="w-24 h-24 rounded-full border-2 border-purple-500" />}
            <div>
              <h3 className="text-3xl font-bold">{token.name} <span className="text-gray-400">(${token.symbol})</span></h3>
              <p className="text-lg text-gray-400">{token.creatorInfo || 'عملة ميمية جديدة تم إنشاؤها'}</p>
            </div>
          </div>
          
          <div className="space-y-2">
            <DetailRow label="عنوان العقد" value={token.contractAddress} isAddress network={token.network} />
            <DetailRow label="الشبكة" value={token.network} />
            <DetailRow label="إجمالي العرض" value={token.supply.toLocaleString()} />
            <DetailRow label="عنوان المالك" value={token.recipientAddress} isAddress network={token.network} />
            {token.creatorName && <DetailRow label="اسم المنشئ" value={token.creatorName} />}
            {token.creatorAddress && <DetailRow label="عنوان المنشئ" value={token.creatorAddress} isAddress network={token.network} />}
          </div>

           <div className="mt-8 flex flex-col md:flex-row gap-4">
                <Button 
                    variant="primary" 
                    className="w-full flex-1"
                    href={explorerUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                >
                    عرض العملة على المستكشف <ExternalLinkIcon className="w-5 h-5 ms-2" />
                </Button>
                {token.liquidity.enabled && token.liquidity.allowRemovalAfterLaunch && (
                    <Button variant="secondary" className="w-full md:w-auto bg-red-600/50 hover:bg-red-600 border border-red-500" onClick={() => setIsModalOpen(true)}>
                        🔓 سحب السيولة
                    </Button>
                )}
           </div>
        </div>

        {token.advanced.burnable && (
            <div className="mt-8 p-6 bg-gray-900/50 border border-gray-700 rounded-lg">
                <h3 className="text-2xl font-bold mb-4">حرق العملات</h3>
                <p className="text-gray-400 mb-4 text-sm">
                    حرق العملات يزيلها من العرض المتداول بشكل دائم. هذه العملية لا يمكن التراجع عنها.
                </p>
                <div className="flex flex-col sm:flex-row gap-4">
                    <div className="flex-grow">
                        <Input 
                            label={`أدخل الكمية للحرق (بالـ ${token.symbol})`} 
                            type="number" 
                            value={burnAmount}
                            onChange={(e) => setBurnAmount(e.target.value)}
                            placeholder="e.g., 100000"
                            disabled={isBurning}
                        />
                    </div>
                    <Button onClick={handleBurn} disabled={isBurning || !burnAmount} className="self-end h-[42px]">
                        {isBurning ? 'جاري الحرق...' : `حرق ${token.symbol}`}
                    </Button>
                </div>
                {burnError && <p className="text-red-400 text-sm mt-2">{burnError}</p>}
            </div>
        )}
      </div>
    </>
  );
};

export default TokenDetailsPage;