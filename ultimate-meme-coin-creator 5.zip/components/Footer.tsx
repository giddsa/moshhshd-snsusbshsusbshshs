import React from 'react';
import Button from './ui/Button';

const Footer: React.FC = () => {
  return (
    <footer className="text-center py-6 mt-12 space-y-4">
       <Button 
         variant="secondary" 
         size="sm" 
         onClick={() => window.location.href = 'mailto:support@example.com'}
       >
         مساعدة / تواصل معنا
       </Button>
      <p className="text-gray-500 text-sm">
        تم الإنشاء بواسطة الذكاء الاصطناعي — Ultimate Meme Coin Creator
      </p>
    </footer>
  );
};

export default Footer;
