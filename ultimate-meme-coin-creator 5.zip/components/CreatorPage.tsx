import React, { useState, useMemo } from 'react';
import type { TokenData } from '../types';
import { Network } from '../types';
import { DEX_OPTIONS } from '../constants';
import Input from './ui/Input';
import Select from './ui/Select';
import Checkbox from './ui/Checkbox';
import Button from './ui/Button';
import RocketIcon from './icons/RocketIcon';
import QuestionMarkCircleIcon from './icons/QuestionMarkCircleIcon';

// --- Global Solana instances from scripts ---
declare const solanaWeb3: any;
declare const splToken: any;

// --- Internal UI Components ---
const Tooltip: React.FC<{ text: string; children: React.ReactNode }> = ({ text, children }) => (
  <div className="relative flex items-center group">
    {children}
    <div className="absolute bottom-full mb-2 w-max max-w-xs p-2 text-xs text-white bg-gray-800 border border-gray-600 rounded-md shadow-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300 z-10">
      {text}
    </div>
  </div>
);

const ProgressBar: React.FC<{ percentage: number; text: string }> = ({ percentage, text }) => (
    <div className="w-full bg-gray-700 rounded-full h-8">
        <div 
            className="bg-gradient-to-r from-purple-500 to-blue-500 h-8 rounded-full flex items-center justify-center text-sm font-medium transition-all duration-500"
            style={{ width: `${percentage}%` }}
        >
           {text} ({percentage}%)
        </div>
    </div>
);


// --- Main Creator Page Component ---
interface CreatorPageProps {
  onTokenCreated: (tokenData: TokenData, txSignature: string) => void;
  walletAddress: string | null;
  manualSigner: any | null; // Solana Keypair
}

const CreatorPage: React.FC<CreatorPageProps> = ({ onTokenCreated, walletAddress, manualSigner }) => {
  const [formData, setFormData] = useState<TokenData>({
    name: '',
    symbol: '',
    decimals: 9,
    supply: 1000000,
    creatorInfo: '',
    creatorName: '',
    creatorAddress: '',
    logo: undefined,
    recipientAddress: '',
    launchKey: Math.random().toString(36).substring(2, 15),
    network: Network.Solana,
    liquidity: {
        enabled: false,
        percentage: 50,
        dex: undefined,
        lockEnabled: false,
        lockDuration: 365,
        allowRemovalAfterLaunch: true,
    },
    advanced: {
      mintable: false,
      burnable: false,
      renounceOwnership: false,
      taxPercentage: 0
    },
  });
  const [logoPreview, setLogoPreview] = useState<string | null>(null);
  const [progress, setProgress] = useState({ percentage: 0, message: ''});
  const isCreating = progress.percentage > 0 && progress.percentage < 100;
  const [error, setError] = useState<string | null>(null);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    const isCheckbox = type === 'checkbox';
    const checked = isCheckbox ? (e.target as HTMLInputElement).checked : undefined;
  
    const nameParts = name.split('.');
  
    if (nameParts.length > 1) {
      const [section, field] = nameParts;
      setFormData(prev => ({
        ...prev,
        [section]: {
          // eslint-disable-next-line @typescript-eslint/ban-ts-comment
          // @ts-ignore
          ...prev[section],
          [field]: isCheckbox ? checked : value,
        },
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        [name]: isCheckbox ? checked : value,
      }));
    }
  };

  const handleLogoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const reader = new FileReader();
      reader.onloadend = () => {
        setLogoPreview(reader.result as string);
        setFormData(prev => ({ ...prev, logo: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!walletAddress) {
        setError("الرجاء ربط محفظتك أولاً للمتابعة.");
        return;
    }

    if (formData.network !== Network.Solana) {
        setError("حاليًا، يتم دعم إنشاء العملات على شبكة سولانا فقط.");
        return;
    }
    
    // @ts-ignore
    const provider = window.solana;
    if (!manualSigner && (!provider || !provider.isPhantom)) {
        setError("الرجاء التأكد من أن محفظة Phantom مثبتة أو استخدم الاتصال اليدوي.");
        return;
    }

    setProgress({ percentage: 10, message: 'الاتصال بشبكة سولانا...'});
    const { Connection, PublicKey, Keypair, Transaction, SystemProgram } = solanaWeb3;
    const { createMint, getOrCreateAssociatedTokenAccount, mintTo, createSetAuthorityInstruction, AuthorityType } = splToken;
    const connection = new Connection(solanaWeb3.clusterApiUrl('devnet'), 'confirmed');
    
    const fromWallet = manualSigner ? manualSigner.publicKey : new PublicKey(walletAddress);

    try {
        const mint = Keypair.generate();
        setProgress({ percentage: 25, message: 'تحضير العقد الذكي...'});

        const lamports = await connection.getMinimumBalanceForRentExemption(splToken.MINT_SIZE);

        const createMintTx = new Transaction().add(
            SystemProgram.createAccount({
                fromPubkey: fromWallet,
                newAccountPubkey: mint.publicKey,
                space: splToken.MINT_SIZE,
                lamports,
                programId: splToken.TOKEN_PROGRAM_ID,
            }),
            splToken.createInitializeMintInstruction(
                mint.publicKey,
                formData.decimals,
                fromWallet,
                formData.advanced.mintable ? fromWallet : null, // Mint Authority
                splToken.TOKEN_PROGRAM_ID
            )
        );

        setProgress({ percentage: 50, message: 'في انتظار توقيع معاملة الإنشاء...'});
        
        const { blockhash } = await connection.getLatestBlockhash();
        createMintTx.recentBlockhash = blockhash;
        createMintTx.feePayer = fromWallet;

        let signature;
        if (manualSigner) {
            createMintTx.sign(manualSigner, mint);
            signature = await connection.sendRawTransaction(createMintTx.serialize());
        } else {
            createMintTx.partialSign(mint);
            const signedTx = await provider.signTransaction(createMintTx);
            signature = await connection.sendRawTransaction(signedTx.serialize());
        }
        await connection.confirmTransaction(signature, 'confirmed');

        setProgress({ percentage: 75, message: 'إنشاء حساب التوكن وسك العملات...'});
        
        const recipientPubKey = formData.recipientAddress ? new PublicKey(formData.recipientAddress) : fromWallet;
        const payer = manualSigner || { publicKey: fromWallet, signTransaction: provider.signTransaction };

        const toTokenAccount = await getOrCreateAssociatedTokenAccount(
            connection,
            payer, 
            mint.publicKey,
            recipientPubKey
        );

        const mintTransaction = new Transaction().add(
            mintTo(
                mint.publicKey,
                toTokenAccount.address,
                fromWallet, // Mint authority
                formData.supply * Math.pow(10, formData.decimals)
            )
        );
        
        const { blockhash: mintBlockhash } = await connection.getLatestBlockhash();
        mintTransaction.recentBlockhash = mintBlockhash;
        mintTransaction.feePayer = fromWallet;

        let mintSignature;
        if(manualSigner) {
            mintTransaction.sign(manualSigner);
            mintSignature = await connection.sendRawTransaction(mintTransaction.serialize());
        } else {
            const signedMintTx = await provider.signTransaction(mintTransaction);
            mintSignature = await connection.sendRawTransaction(signedMintTx.serialize());
        }
        await connection.confirmTransaction(mintSignature, 'confirmed');
       
        if (formData.advanced.renounceOwnership) {
          setProgress({ percentage: 90, message: 'التنازل عن ملكية السك...'});
          const renounceTx = new Transaction().add(
            createSetAuthorityInstruction(
              mint.publicKey,
              fromWallet,
              AuthorityType.MintTokens,
              null
            )
          );
          
          const { blockhash: renounceBlockhash } = await connection.getLatestBlockhash();
          renounceTx.recentBlockhash = renounceBlockhash;
          renounceTx.feePayer = fromWallet;

          if (manualSigner) {
              renounceTx.sign(manualSigner);
              await connection.sendRawTransaction(renounceTx.serialize());
          } else {
              const signedRenounceTx = await provider.signTransaction(renounceTx);
              await connection.sendRawTransaction(signedRenounceTx.serialize());
          }
        }

        setProgress({ percentage: 100, message: 'تم بنجاح ✅' });
        const finalTokenData = { ...formData, contractAddress: mint.publicKey.toBase58(), recipientAddress: recipientPubKey.toBase58() };
        
        await new Promise(resolve => setTimeout(resolve, 1000));
        onTokenCreated(finalTokenData, mintSignature);

    } catch (err: any) {
        console.error("Token creation failed:", err);
        let userMessage = "فشلت عملية إنشاء العملة.";
        if (err.message && err.message.includes("User rejected the request")) {
            userMessage = "لقد قمت برفض المعاملة في محفظتك.";
        }
        setError(userMessage);
        setProgress({ percentage: 0, message: '' });
    }
  };

  const dexOptions = useMemo(() => DEX_OPTIONS[formData.network], [formData.network]);

  const renderFieldWithTooltip = (label: string, tooltipText: string, field: React.ReactNode) => (
    <div className="flex flex-col">
        <div className="flex items-center gap-2 mb-1">
            <label className="block text-sm font-medium text-gray-300">{label}</label>
            <Tooltip text={tooltipText}>
                <QuestionMarkCircleIcon className="w-4 h-4 text-gray-400" />
            </Tooltip>
        </div>
        {field}
    </div>
  );

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-yellow-500/10 border border-yellow-500 text-yellow-300 p-4 rounded-lg mb-6 text-center text-sm">
        <strong>تنبيه هام:</strong> جميع العمليات تتم على شبكة سولانا التجريبية (Devnet). لن يتم استخدام أي أموال حقيقية.
      </div>
      <h2 className="text-3xl font-bold text-center mb-8">إنشاء توكن جديد</h2>
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Basic Info */}
        <div className="p-6 bg-gray-900/50 border border-gray-700 rounded-lg">
          <h3 className="text-xl font-semibold mb-4 text-purple-400">المعلومات الأساسية</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {renderFieldWithTooltip("اسم التوكن", "الاسم الكامل لعملتك.", <Input name="name" value={formData.name} onChange={handleInputChange} required />)}
            {renderFieldWithTooltip("رمز التوكن", "الرمز المختصر لعملتك (عادة 3-5 أحرف).", <Input name="symbol" value={formData.symbol} onChange={handleInputChange} required />)}
            {renderFieldWithTooltip("الكسور العشرية", "عدد الخانات العشرية التي تدعمها عملتك (9 هو الشائع لسولانا).", <Input name="decimals" type="number" value={formData.decimals} onChange={handleInputChange} required />)}
            {renderFieldWithTooltip("إجمالي العرض", "الكمية الإجمالية من العملات التي سيتم إنشاؤها.", <Input name="supply" type="number" value={formData.supply} onChange={handleInputChange} required />)}
          </div>
        </div>

        {/* Creator Info & Logo */}
        <div className="p-6 bg-gray-900/50 border border-gray-700 rounded-lg">
            <h3 className="text-xl font-semibold mb-4 text-purple-400">معلومات المنشئ والشعار (اختياري)</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-start">
                 <div className="space-y-4">
                     {renderFieldWithTooltip("اسم المنشئ", "اسمك أو اسم الفريق.", <Input name="creatorName" value={formData.creatorName} onChange={handleInputChange} />)}
                     {renderFieldWithTooltip("عنوان المُنشئ", "عنوان محفظة المنشئ للعرض العام.", <Input name="creatorAddress" value={formData.creatorAddress} onChange={handleInputChange} />)}
                 </div>
                 <div className="space-y-4">
                     {renderFieldWithTooltip("معلومات المنشئ", "وصف قصير عنك أو عن المشروع.", <Input name="creatorInfo" value={formData.creatorInfo} onChange={handleInputChange} />)}
                     <div className="flex items-center gap-4">
                         {renderFieldWithTooltip("شعار صغير", "ارفع صورة شعار لعملتك.", <Input name="logo" type="file" accept="image/*" onChange={handleLogoChange} />)}
                         {logoPreview && <img src={logoPreview} alt="Logo Preview" className="w-12 h-12 rounded-full" />}
                     </div>
                 </div>
             </div>
        </div>
        
        {/* Liquidity Pool */}
        <div className="p-6 bg-gray-900/50 border border-gray-700 rounded-lg">
            <h3 className="text-xl font-semibold mb-4 text-purple-400">مجموعة السيولة (Liquidity Pool)</h3>
            <div className="space-y-4">
                {renderFieldWithTooltip("تفعيل مجموعة السيولة", "إنشاء مجمع سيولة يسمح بتداول عملتك على منصة لا مركزية (DEX).", <Checkbox name="liquidity.enabled" label="تفعيل" checked={formData.liquidity.enabled} onChange={handleInputChange} />)}
                {formData.liquidity.enabled && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4 border-t border-gray-700">
                        {renderFieldWithTooltip("نسبة السيولة (%)", "النسبة المئوية من إجمالي العرض التي سيتم إيداعها في مجمع السيولة.", <Input name="liquidity.percentage" type="number" value={formData.liquidity.percentage} onChange={handleInputChange} />)}
                        {renderFieldWithTooltip("اختيار DEX", "المنصة اللامركزية التي سيتم إنشاء مجمع السيولة عليها.", <Select name="liquidity.dex" value={formData.liquidity.dex} onChange={handleInputChange} options={dexOptions} />)}
                        {renderFieldWithTooltip("قفل السيولة", "حجز أموال السيولة لفترة زمنية لزيادة ثقة المستثمرين.", <Checkbox name="liquidity.lockEnabled" label="قفل السيولة" checked={formData.liquidity.lockEnabled} onChange={handleInputChange} />)}
                        {formData.liquidity.lockEnabled && renderFieldWithTooltip("مدة القفل بالأيام", "عدد الأيام التي ستبقى فيها السيولة مقفلة.", <Input name="liquidity.lockDuration" type="number" value={formData.liquidity.lockDuration} onChange={handleInputChange} />)}
                        {renderFieldWithTooltip("السماح بسحب السيولة", "السماح لمالك العقد بسحب السيولة بعد انتهاء فترة القفل.", <Checkbox name="liquidity.allowRemovalAfterLaunch" label="السماح بالسحب بعد الإطلاق" checked={formData.liquidity.allowRemovalAfterLaunch} onChange={handleInputChange} />)}
                    </div>
                )}
            </div>
        </div>

        {/* Destination & Network */}
        <div className="p-6 bg-gray-900/50 border border-gray-700 rounded-lg">
          <h3 className="text-xl font-semibold mb-4 text-purple-400">الوجهة والشبكة</h3>
             <div className="space-y-4">
                {renderFieldWithTooltip("عنوان المستلم (رمز المالك)", "عنوان المحفظة التي ستستلم كل العملات التي تم إنشاؤها. سيتم استخدام عنوان محفظتك المتصلة إذا ترك فارغًا.", <Input name="recipientAddress" placeholder={walletAddress || ''} value={formData.recipientAddress} onChange={handleInputChange} />)}
                {renderFieldWithTooltip("رمز الإطلاق", "رمز فريد يتم إنشاؤه تلقائيًا لهذه العملية.", <Input name="launchKey" value={formData.launchKey} onChange={handleInputChange} readOnly />)}
                {renderFieldWithTooltip("اختر الشبكة", "شبكة البلوكتشين التي سيتم إطلاق عملتك عليها.", <Select name="network" value={formData.network} onChange={(e) => {
                    handleInputChange(e);
                    setFormData(prev => ({ ...prev, liquidity: { ...prev.liquidity, dex: undefined }}));
                }} options={Object.values(Network)} />)}
            </div>
        </div>
        
        {/* Advanced Options */}
        <div className="p-6 bg-gray-900/50 border border-gray-700 rounded-lg">
            <h3 className="text-xl font-semibold mb-4 text-purple-400">خيارات متقدمة</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {renderFieldWithTooltip("قابل للسك (Mintable)", "السماح بإنشاء عملات جديدة بعد الإطلاق الأولي. إذا تم إلغاء تحديده، فسيتم تعطيل سلطة السك.", <Checkbox name="advanced.mintable" label="قابل للسك" checked={formData.advanced.mintable} onChange={handleInputChange} />)}
                {renderFieldWithTooltip("قابل للحرق (Burnable)", "السماح بإرسال العملات إلى عنوان ميت لإزالتها من العرض المتداول.", <Checkbox name="advanced.burnable" label="قابل للحرق" checked={formData.advanced.burnable} onChange={handleInputChange} />)}
                {renderFieldWithTooltip("التنازل عن الملكية", "التخلي عن ملكية العقد، مما يجعله غير قابل للتغيير ويزيد الثقة. هذا الخيار يعطل سلطة السك بشكل دائم.", <Checkbox name="advanced.renounceOwnership" label="التنازل عن الملكية" checked={formData.advanced.renounceOwnership} onChange={handleInputChange} />)}
                {renderFieldWithTooltip("ضريبة المعاملة (%)", "فرض رسوم صغيرة على كل معاملة، والتي يمكن إرسالها إلى محفظة محددة.", <Input name="advanced.taxPercentage" type="number" value={formData.advanced.taxPercentage} onChange={handleInputChange} />)}
            </div>
        </div>
        
        {error && <div className="text-center p-3 bg-red-500/20 border border-red-500 text-red-300 rounded-lg">{error}</div>}

        {/* Submit */}
        <div className="pt-4">
          {progress.percentage > 0 ? (
            <ProgressBar percentage={progress.percentage} text={progress.message} />
          ) : (
            <div className="text-center">
                <Button type="submit" size="lg" variant="primary" disabled={isCreating}>
                    إنشاء العملة الآن <RocketIcon className="w-6 h-6 ms-2" />
                </Button>
            </div>
          )}
        </div>
      </form>
    </div>
  );
};

export default CreatorPage;