import React from 'react';
import WalletIcon from './icons/WalletIcon';
import { Page } from '../types';

interface HeaderProps {
  isLoggedIn: boolean;
  onNavigate: (page: Page) => void;
  onLogout: () => void;
  onConnectWallet: () => void;
  walletAddress: string | null;
  isConnecting: boolean;
}

const NavLink: React.FC<{onClick: () => void, children: React.ReactNode}> = ({ onClick, children }) => (
    <button onClick={onClick} className="text-gray-300 hover:text-white transition-colors">{children}</button>
);

const Header: React.FC<HeaderProps> = ({ isLoggedIn, onNavigate, onLogout, onConnectWallet, walletAddress, isConnecting }) => {
  let buttonText = 'ربط المحفظة';
  if (isConnecting) {
    buttonText = 'جاري الاتصال...';
  } else if (walletAddress) {
    buttonText = `${walletAddress.substring(0, 6)}...${walletAddress.substring(walletAddress.length - 4)}`;
  }

  return (
    <header className="container mx-auto px-4 py-6">
      <div className="flex justify-between items-center">
        <h1 
            className="text-2xl md:text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-blue-500 cursor-pointer"
            onClick={() => onNavigate(Page.Home)}
        >
          Ultimate Meme Coin Creator
        </h1>
        <nav className="hidden md:flex items-center gap-6 text-sm font-semibold">
           <NavLink onClick={() => onNavigate(Page.Creator)}>إنشاء توكن</NavLink>
           {isLoggedIn && <NavLink onClick={() => onNavigate(Page.Dashboard)}>لوحة التحكم</NavLink>}
           <NavLink onClick={() => onNavigate(Page.Guide)}>شرح المنصة</NavLink>
           {!isLoggedIn && <NavLink onClick={() => onNavigate(Page.Login)}>تسجيل الدخول</NavLink>}
        </nav>
        <button
          onClick={onConnectWallet}
          disabled={isConnecting || !!walletAddress}
          className="flex items-center gap-2 px-4 py-2 text-sm font-semibold border-2 border-purple-500 rounded-lg hover:bg-purple-500/20 transition-all duration-300 disabled:opacity-70 disabled:cursor-not-allowed"
        >
          <WalletIcon className="w-5 h-5" />
          {buttonText}
        </button>
      </div>
    </header>
  );
};

export default Header;
