
import React from 'react';
import Button from './ui/Button';
import RocketIcon from './icons/RocketIcon';

interface HomePageProps {
  onNavigateToCreator: () => void;
}

const HomePage: React.FC<HomePageProps> = ({ onNavigateToCreator }) => {
  return (
    <div className="flex flex-col items-center justify-center text-center py-20 md:py-32">
      <h2 className="text-4xl md:text-6xl font-extrabold leading-tight mb-6">
        أنشئ عملتك الميمية مجانًا
        <br />
        <span className="bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-blue-500">
          على شبكة سولانا أو غيرها!
        </span>
      </h2>
      <p className="text-gray-400 mb-10 max-w-2xl">
        أطلق عملة الميم الخاصة بك في دقائق معدودة. بدون برمجة، بدون رسوم، وبدعم كامل لخيارات السيولة والخصائص المتقدمة.
      </p>
      <Button onClick={onNavigateToCreator} size="lg" variant="primary">
        ابدأ الآن <RocketIcon className="w-6 h-6 ms-2" />
      </Button>
    </div>
  );
};

export default HomePage;
