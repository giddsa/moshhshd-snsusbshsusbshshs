
import { Network } from './types';

export const EXPLORER_URLS: Record<Network, string> = {
  [Network.Solana]: 'https://explorer.solana.com/address/',
  [Network.BSC]: 'https://bscscan.com/token/',
  [Network.Ethereum]: 'https://etherscan.io/token/',
};

export const DEX_OPTIONS: Record<Network, string[]> = {
    [Network.Solana]: ['Raydium', 'Orca', 'Serum'],
    [Network.BSC]: ['PancakeSwap', 'Biswap'],
    [Network.Ethereum]: ['Uniswap', 'Sushiswap']
}
