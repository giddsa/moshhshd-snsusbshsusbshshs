/*
script_chart.js – نسخة ذكية (ترند + حجم + ATR ديناميكي)
- يدخل فقط مع الترند القوي
- يتأكد من حجم فوق المتوسط
- هدف 1:3، وقف ديناميكي
- يعمل على GitHub Pages (CORS-safe)
*/
const BINANCE_API_KEY = "O8rmKGFBvpqWzqZlAksLEOzvf7ahjVIgpL0SSsRRuki6Kb9tyJZ7BxJ7i6WvLp8r";
const ctx = document.getElementById('candlesChart').getContext('2d');
let candlesChart = null;
let lastRecommendation = null;

/* ---------- helpers ---------- */
const toCandleData = k => k.map(d => ({
  x: new Date(d[0]),
  o: parseFloat(d[1]),
  h: parseFloat(d[2]),
  l: parseFloat(d[3]),
  c: parseFloat(d[4])
}));

/* ---------- chart ---------- */
function createChart(candles){
  if(candlesChart){
    candlesChart.data.datasets[0].data = candles;
    candlesChart.update();
    return;
  }
  candlesChart = new Chart(ctx,{
    type:'candlestick',
    data:{datasets:[{label:'Candles',data:candles}]},
    options:{
      animation:false,
      maintainAspectRatio:false,
      plugins:{legend:{display:false},tooltip:{mode:'index',intersect:false},annotation:{annotations:{}}},
      scales:{
        x:{type:'time',time:{tooltipFormat:'dd MMM yyyy HH:mm'},ticks:{color:'#cfe8ff'}},
        y:{position:'right',ticks:{color:'#cfe8ff'}}
      }
    }
  });
}

/* ---------- annotations ---------- */
function setTradeAnnotations(entry,stop,target){
  if(!candlesChart) return;
  const ann={};
  if(entry!=null) ann.entryLine  ={type:'line',yMin:entry,yMax:entry,borderColor:'rgba(54,144,255,.9)',borderWidth:2,label:{enabled:true,content:'Entry',position:'start',backgroundColor:'rgba(54,144,255,.2)',color:'#e6f5ff'}};
  if(stop !=null) ann.stopLine   ={type:'line',yMin:stop ,yMax:stop ,borderColor:'rgba(255,60,60,.95)',borderWidth:2,label:{enabled:true,content:'Stop Loss',position:'start',backgroundColor:'rgba(255,60,60,.12)',color:'#ffecec'}};
  if(target!=null) ann.targetLine={type:'line',yMin:target,yMax:target,borderColor:'rgba(46,200,120,.95)',borderWidth:2,label:{enabled:true,content:'Take Profit',position:'start',backgroundColor:'rgba(46,200,120,.12)',color:'#eafff0'}};
  candlesChart.options.plugins.annotation.annotations=ann;
  candlesChart.update();
}

/* ---------- Binance call (CORS-safe) ---------- */
async function fetchKlines(symbol,interval='1h',limit=200){
  const url = `https://data.binance.com/api/v3/klines?symbol=${symbol.toUpperCase()}&interval=${interval}&limit=${limit}`;
  const headers={};
  if(BINANCE_API_KEY) headers['X-MBX-APIKEY']=BINANCE_API_KEY;
  const res=await fetch(url,{headers});
  if(!res.ok) throw new Error(`Binance API ${res.status} ${res.statusText}`);
  const data=await res.json();
  if(data.code) throw new Error(JSON.stringify(data));
  return data;
}

/* ---------- المؤشرات المحسّنة ---------- */
function smartRecommendation(klines){
  const c=klines.map(k=>parseFloat(k[4]));
  const v=klines.map(k=>parseFloat(k[5])); // volume
  if(c.length<60) return null;

  const ema=(v,p)=>{const k=2/(p+1);let r=v[0];return v.map(x=>r=x*k+r*(1-k))};
  const sma=(v,p)=>{const out=[];for(let i=0;i<v.length;i++){if(i+1<p) out.push(null);else{let s=0;for(let j=i+1-p;j<=i;j++) s+=v[j]; out.push(s/p);}}return out;};

  const high=klines.map(k=>parseFloat(k[2]));
  const low=klines.map(k=>parseFloat(k[3]));
  const atrArr=[];
  for(let i=1;i<c.length;i++){
    const tr=Math.max(high[i]-low[i],Math.abs(high[i]-c[i-1]),Math.abs(low[i]-c[i-1]));
    atrArr.push(tr);
  }
  const atr=sma(atrArr,14).filter(Boolean).pop() || (Math.max(...high)-Math.min(...low))/50;

  const ema50=ema(c,50);
  const ema200=ema(c,200);
  const volSMA=sma(v,20).filter(Boolean).pop() || 1;
  const lastVol=v[v.length-1];
  const lastE50=ema50[ema50.length-1];
  const lastE200=ema200[ema200.length-1];
  const lastPrice=c[c.length-1];

  // فلاتر الترند والحجم
  const trendUp=lastE50>lastE200 && lastPrice>lastE50;
  const trendDown=lastE50<lastE200 && lastPrice<lastE50;
  const volOk=lastVol>volSMA*1.05; // حجم أعلى من المتوسط 5%

  let signal=null,entry=null,stop=null,target=null;

  if(trendUp && volOk){
    signal='شراء';
    entry=lastPrice;
    stop=+(entry-1.2*atr).toFixed(8); // وقف أقرب قليلاً
    target=+(entry+3.0*(entry-stop)).toFixed(8); // 1:3
  }else if(trendDown && volOk){
    signal='بيع';
    entry=lastPrice;
    stop=+(entry+1.2*atr).toFixed(8);
    target=+(entry-3.0*(stop-entry)).toFixed(8); // 1:3
  }

  return signal? {coin:'BTCUSDT',signal,entry,stop,target,trendUp,volRatio:(lastVol/volSMA).toFixed(2)} : null;
}

/* ---------- UI ---------- */
const $=id=>document.getElementById(id);
const symbolInput=$('symbolInput'),updateBtn=$('updateChartBtn'),recBtn=$('showLastRecBtn');
const intervalSel=$('chartInterval'),limitSel=$('chartLimit'),title=$('chartTitle'),sub=$('chartSubtitle');

async function updateForSymbol(sym){
  try{
    title.textContent=sym.toUpperCase();
    sub.textContent='جاري جلب الشموع من Binance...';
    const klines=await fetchKlines(sym,intervalSel.value,parseInt(limitSel.value,10));
    const candles=toCandleData(klines);
    createChart(candles);
    sub.textContent=`آخر ${candles.length} شمعة — interval ${intervalSel.value}`;

    const rec=smartRecommendation(klines);
    lastRecommendation=rec;
    if(rec){
      setTradeAnnotations(rec.entry,rec.stop,rec.target);
      sub.textContent+=` — توصية: ${rec.signal} (ترند: ${rec.trendUp?'صاعد':'هابط'}، حجم: ${rec.volRatio}x)`;
    }else{
      setTradeAnnotations(null,null,null);
      sub.textContent+=' — لا توصية قوية (ترند ضعيف أو حجم منخفض)';
    }
  }catch(err){
    let msg=err.message||String(err);
    if(msg.includes('Failed to fetch')||msg.includes('NetworkError'))
      msg='لا يمكن الوصول لـ Binance – تأكد من اتصالك أو من HTTPS';
    sub.textContent='خطأ في جلب البيانات: '+msg;
  }
}

updateBtn.addEventListener('click',()=>{
  const s=symbolInput.value.trim().toUpperCase();
  if(!s){alert('ادخل رمز زوج مثل BTCUSDT');return;}
  updateForSymbol(s);
});
recBtn.addEventListener('click',()=>{
  if(!candlesChart){alert('لم يتم تحميل المخطط بعد');return;}
  if(!lastRecommendation){alert('لا توصية حالياً');return;}
  setTradeAnnotations(lastRecommendation.entry,lastRecommendation.stop,lastRecommendation.target);
});

/* ---------- تفعيل أولي ---------- */
symbolInput.value='BTCUSDT';
updateForSymbol('BTCUSDT');
