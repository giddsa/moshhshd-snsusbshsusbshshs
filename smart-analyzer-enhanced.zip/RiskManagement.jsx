// file: smart-analyzer-project/RiskManagement.jsx
import React, { useState, useCallback, useMemo } from 'react';

const RiskManagement = () => {
    const [accountBalance, setAccountBalance] = useState(10000); // رصيد افتراضي 10000$
    const [riskPercentage, setRiskPercentage] = useState(1); // نسبة المخاطرة الافتراضية 1%
    const [entryPrice, setEntryPrice] = useState(100); // سعر الدخول الافتراضي
    const [stopLossPips, setStopLossPips] = useState(50); // عدد النقاط المتوقعة لوقف الخسارة
    const [takeProfitRatio, setTakeProfitRatio] = useState(2); // نسبة المخاطرة/العائد الافتراضية 2:1
    const [tradeType, setTradeType] = useState('buy'); // نوع الصفقة: شراء (buy) أو بيع (sell)

    const handleCalculate = useCallback(() => {
        const riskAmount = (accountBalance * riskPercentage) / 100;
        const pipsValue = 0.0001; // قيمة النقطة الواحدة (افتراض لزوج عملات عادي)

        // حجم اللوت (Lot Size) بناءً على المخاطرة
        const lotSize = riskAmount / (stopLossPips * pipsValue * 10000); // 10000 لتعديل قيمة النقطة

        // حساب نقاط وقف الخسارة وجني الأرباح
        let stopLossPrice;
        let takeProfitPrice;

        if (tradeType === 'buy') {
            // الشراء: وقف الخسارة تحت سعر الدخول، جني الأرباح فوق سعر الدخول
            stopLossPrice = entryPrice - (stopLossPips * pipsValue);
            takeProfitPrice = entryPrice + (stopLossPips * takeProfitRatio * pipsValue);
        } else {
            // البيع: وقف الخسارة فوق سعر الدخول، جني الأرباح تحت سعر الدخول
            stopLossPrice = entryPrice + (stopLossPips * pipsValue);
            takeProfitPrice = entryPrice - (stopLossPips * takeProfitRatio * pipsValue);
        }

        return {
            riskAmount: riskAmount.toFixed(2),
            lotSize: lotSize > 0 ? lotSize.toFixed(2) : '0.00',
            stopLossPrice: stopLossPrice.toFixed(4),
            takeProfitPrice: takeProfitPrice.toFixed(4),
            riskRewardRatio: `${takeProfitRatio}:1`,
        };
    }, [accountBalance, riskPercentage, entryPrice, stopLossPips, takeProfitRatio, tradeType]);

    const results = useMemo(() => handleCalculate(), [handleCalculate]);

    // مكون حقل الإدخال
    const InputField = ({ label, value, onChange, type = 'number', unit = '' }) => (
        <div className="flex flex-col space-y-1">
            <label className="text-brand-text-secondary text-sm">{label}</label>
            <div className="flex items-center bg-brand-bg rounded-md border border-brand-border px-3">
                <input
                    type={type}
                    value={value}
                    onChange={(e) => onChange(parseFloat(e.target.value) || 0)}
                    className="flex-grow bg-transparent text-brand-text-primary p-2 focus:outline-none"
                    min="0"
                    step={type === 'number' && value < 1 ? '0.01' : '1'}
                />
                {unit && <span className="text-brand-text-secondary">{unit}</span>}
            </div>
        </div>
    );

    // مكون عرض النتيجة
    const ResultCard = ({ title, value, colorClass = 'text-brand-primary' }) => (
        <div className="bg-brand-bg p-3 rounded-lg border border-brand-border">
            <p className="text-brand-text-secondary text-xs">{title}</p>
            <p className={`text-xl font-bold ${colorClass}`}>{value}</p>
        </div>
    );

    return (
        <div className="p-6 font-arabic bg-brand-surface rounded-lg shadow-xl border border-brand-border">
            <h2 className="text-2xl font-bold text-brand-text-primary mb-6 border-b border-brand-border pb-2">حاسبة إدارة المخاطر (R:R)</h2>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
                <InputField label="رصيد الحساب ($)" value={accountBalance} onChange={setAccountBalance} unit="$" />
                <InputField label="نسبة المخاطرة (%)" value={riskPercentage} onChange={setRiskPercentage} unit="%" />
                <InputField label="سعر الدخول" value={entryPrice} onChange={setEntryPrice} />
                <InputField label="نقاط وقف الخسارة (Pips)" value={stopLossPips} onChange={setStopLossPips} />
                <InputField label="نسبة العائد (R:R)" value={takeProfitRatio} onChange={setTakeProfitRatio} unit=":1" />

                <div className="flex flex-col space-y-1">
                    <label className="text-brand-text-secondary text-sm">نوع الصفقة</label>
                    <div className="flex bg-brand-bg rounded-md border border-brand-border p-1">
                        <button
                            onClick={() => setTradeType('buy')}
                            className={`flex-1 p-2 rounded-md transition-colors ${tradeType === 'buy' ? 'bg-brand-success text-white' : 'text-brand-text-primary hover:bg-brand-border'}`}
                        >
                            شراء (Long)
                        </button>
                        <button
                            onClick={() => setTradeType('sell')}
                            className={`flex-1 p-2 rounded-md transition-colors ${tradeType === 'sell' ? 'bg-brand-danger text-white' : 'text-brand-text-primary hover:bg-brand-border'}`}
                        >
                            بيع (Short)
                        </button>
                    </div>
                </div>
            </div>

            <h3 className="text-xl font-semibold text-brand-text-primary mb-4 border-b border-brand-border pb-2">النتائج المقترحة</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <ResultCard title="مبلغ المخاطرة" value={`$${results.riskAmount}`} colorClass="text-brand-danger" />
                <ResultCard title="حجم اللوت المقترح" value={results.lotSize} colorClass="text-brand-primary" />
                <ResultCard title="وقف الخسارة (SL)" value={results.stopLossPrice} colorClass="text-brand-danger" />
                <ResultCard title="جني الأرباح (TP)" value={results.takeProfitPrice} colorClass="text-brand-success" />
                <ResultCard title="نسبة المخاطرة/العائد" value={results.riskRewardRatio} colorClass="text-brand-primary" />
            </div>
        </div>
    );
};

export default RiskManagement;
