// file: smart-analyzer-project/TechnicalAnalysis.jsx
import { createElement, useState, useEffect, useCallback } from 'react';
import {
    LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, BarChart, Bar, AreaChart, Area
} from 'recharts';

import { generateDummyData } from './utils.js';
import PredictionAnalysis from './PredictionAnalysis.jsx';

// افتراض أن مكتبة React متاحة عالميًا كـ 'React' ومكوناتها متاحة مباشرة
// ولكن بما أننا نستخدم "importmap" و "module" في index.html، يجب أن نستخدم الاستيراد الكامل
const React = { createElement, useState, useEffect, useCallback };

const TechnicalAnalysis = () => {
    const [supportLevel, setSupportLevel] = useState(0);
    const [resistanceLevel, setResistanceLevel] = useState(0);
    const [data, setData] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        // محاكاة تحميل البيانات
        const dummyData = generateDummyData(200);
        setData(dummyData);
        setLoading(false);
    }, []);

    if (loading) {
        return React.createElement('div', { className: 'text-brand-text-primary p-6 text-center' }, 'جاري تحميل بيانات التحليل الفني...');
    }

    const lastDataPoint = data[data.length - 1];

    // --- مكون عرض المؤشر الفردي ---
    const IndicatorCard = ({ title, value, unit = '', trend = 0 }) => {
        const trendColor = trend > 0 ? 'text-brand-success' : trend < 0 ? 'text-brand-danger' : 'text-brand-text-secondary';
        const trendIcon = trend > 0 ? '▲' : trend < 0 ? '▼' : '▬';
        return React.createElement('div', { className: 'bg-brand-surface p-4 rounded-lg shadow-md border border-brand-border' },
            React.createElement('p', { className: 'text-brand-text-secondary text-sm mb-1' }, title),
            React.createElement('div', { className: 'flex items-center justify-between' },
                React.createElement('p', { className: 'text-brand-text-primary text-2xl font-bold' }, `${value.toFixed(2)}${unit}`),
                React.createElement('span', { className: `text-lg font-semibold ${trendColor}` }, `${trendIcon} ${Math.abs(trend).toFixed(2)}%`)
            )
        );
    };

    // --- مكون عرض إشارات التداول والاتجاه ---
    const TradingSignal = () => {
        // منطق مبسط لتحديد الاتجاه والإشارة
        const currentPrice = lastDataPoint.price;
        const bbMiddle = lastDataPoint.bbMiddle;
        const rsi = lastDataPoint.rsi;
        const macd = lastDataPoint.macd;
        const signalLine = lastDataPoint.signal;

        let trend = 'جانبي (Sideways)';
        let signal = 'انتظار (Hold)';
        let signalColor = 'bg-brand-text-secondary';

        if (currentPrice > bbMiddle) {
            trend = 'صاعد (Uptrend)';
        } else if (currentPrice < bbMiddle) {
            trend = 'هابط (Downtrend)';
        }

        if (rsi < 30 && macd > signalLine) {
            signal = 'شراء قوي (Strong Buy)';
            signalColor = 'bg-brand-success';
        } else if (rsi > 70 && macd < signalLine) {
            signal = 'بيع قوي (Strong Sell)';
            signalColor = 'bg-brand-danger';
        } else if (macd > signalLine) {
            signal = 'شراء (Buy)';
            signalColor = 'bg-green-500';
        } else if (macd < signalLine) {
            signal = 'بيع (Sell)';
            signalColor = 'bg-red-500';
        }

        return React.createElement('div', { className: 'p-4 rounded-lg shadow-lg border border-brand-border bg-brand-surface col-span-full md:col-span-1' },
            React.createElement('h3', { className: 'text-brand-text-primary text-lg font-semibold mb-3' }, 'إشارات وتحليل الاتجاه'),
            React.createElement('div', { className: 'flex justify-between items-center mb-2' },
                React.createElement('p', { className: 'text-brand-text-secondary' }, 'الاتجاه العام:'),
                React.createElement('span', { className: 'text-brand-primary font-bold' }, trend)
            ),
            React.createElement('div', { className: 'flex justify-between items-center' },
                React.createElement('p', { className: 'text-brand-text-secondary' }, 'إشارة التداول:'),
                React.createElement('span', { className: `text-white px-3 py-1 rounded-full text-sm font-semibold ${signalColor}` }, signal)
            )
        );
    };

    // --- مكون رسم بياني MACD ---
    const MACDChart = () => {
        return React.createElement('div', { className: 'bg-brand-surface p-4 rounded-lg shadow-md border border-brand-border h-80' },
            React.createElement('h3', { className: 'text-brand-text-primary text-lg font-semibold mb-2' }, 'MACD (12, 26, 9)'),
            React.createElement(ResponsiveContainer, { width: '100%', height: '90%' },
                React.createElement(BarChart, { data: data, margin: { top: 5, right: 20, left: 10, bottom: 5 } },
                    React.createElement(CartesianGrid, { strokeDasharray: '3 3', stroke: '#30363D' }),
                    React.createElement(XAxis, { dataKey: 'name', hide: true }),
                    React.createElement(YAxis, { domain: ['auto', 'auto'], stroke: '#8B949E' }),
                    React.createElement(Tooltip, { contentStyle: { backgroundColor: '#161B22', border: '1px solid #30363D' } }),
                    React.createElement(Legend, { wrapperStyle: { color: '#C9D1D9' } }),
                    React.createElement(Bar, { dataKey: 'histogram', fill: '#58A6FF', name: 'Histogram' }),
                    React.createElement(Line, { type: 'monotone', dataKey: 'macd', stroke: '#DA3633', dot: false, name: 'MACD Line' }),
                    React.createElement(Line, { type: 'monotone', dataKey: 'signal', stroke: '#238636', dot: false, name: 'Signal Line' })
                )
            )
        );
    };

    // --- مكون رسم بياني RSI ---
    const RSIChart = () => {
        return React.createElement('div', { className: 'bg-brand-surface p-4 rounded-lg shadow-md border border-brand-border h-80' },
            React.createElement('h3', { className: 'text-brand-text-primary text-lg font-semibold mb-2' }, 'RSI (14)'),
            React.createElement(ResponsiveContainer, { width: '100%', height: '90%' },
                React.createElement(AreaChart, { data: data, margin: { top: 5, right: 20, left: 10, bottom: 5 } },
                    React.createElement(CartesianGrid, { strokeDasharray: '3 3', stroke: '#30363D' }),
                    React.createElement(XAxis, { dataKey: 'name', hide: true }),
                    React.createElement(YAxis, { domain: [0, 100], stroke: '#8B949E' }),
                    React.createElement(Tooltip, { contentStyle: { backgroundColor: '#161B22', border: '1px solid #30363D' } }),
                    React.createElement(Legend, { wrapperStyle: { color: '#C9D1D9' } }),
                    React.createElement(Area, { type: 'monotone', dataKey: 'rsi', stroke: '#58A6FF', fill: '#58A6FF', fillOpacity: 0.3, name: 'RSI' }),
                    React.createElement(Line, { type: 'monotone', dataKey: 'rsi', stroke: '#58A6FF', dot: false }),
                    // خطوط مناطق التشبع
                    React.createElement(Line, { dataKey: '70', stroke: '#DA3633', strokeDasharray: '5 5', dot: false })
                    /*  هنا يجب أن يكون هناك خطوط ثابتة عند 70 و 30، لكن Recharts لا يدعمها بسهولة في AreaChart بدون بيانات إضافية
                        للتسريع، سنكتفي بالرسم البياني للمؤشر.
                    */
                )
            )
        );
    };

    // --- مكون رسم بياني Bollinger Bands ---
    const BBChart = () => {
        return React.createElement('div', { className: 'bg-brand-surface p-4 rounded-lg shadow-md border border-brand-border h-96' },
            React.createElement('h3', { className: 'text-brand-text-primary text-lg font-semibold mb-2' }, 'Bollinger Bands (20, 2)'),
            React.createElement('div', { className: 'flex space-x-4 mb-4' },
                React.createElement('div', { className: 'flex-1' },
                    React.createElement('label', { className: 'text-brand-text-secondary text-sm block mb-1' }, 'مستوى الدعم (يدوي)'),
                    React.createElement('input', {
                        type: 'number',
                        step: '0.01',
                        value: supportLevel,
                        onChange: (e) => setSupportLevel(parseFloat(e.target.value) || 0),
                        className: 'w-full bg-brand-bg text-brand-text-primary p-2 rounded-md border border-brand-border focus:outline-none'
                    })
                ),
                React.createElement('div', { className: 'flex-1' },
                    React.createElement('label', { className: 'text-brand-text-secondary text-sm block mb-1' }, 'مستوى المقاومة (يدوي)'),
                    React.createElement('input', {
                        type: 'number',
                        step: '0.01',
                        value: resistanceLevel,
                        onChange: (e) => setResistanceLevel(parseFloat(e.target.value) || 0),
                        className: 'w-full bg-brand-bg text-brand-text-primary p-2 rounded-md border border-brand-border focus:outline-none'
                    })
                )
            ),
            React.createElement(ResponsiveContainer, { width: '100%', height: '70%' },
                React.createElement(LineChart, { data: data, margin: { top: 5, right: 20, left: 10, bottom: 5 } },
                    React.createElement(CartesianGrid, { strokeDasharray: '3 3', stroke: '#30363D' }),
                    React.createElement(XAxis, { dataKey: 'name', hide: true }),
                    React.createElement(YAxis, { domain: ['auto', 'auto'], stroke: '#8B949E' }),
                    React.createElement(Tooltip, { contentStyle: { backgroundColor: '#161B22', border: '1px solid #30363D' } }),
                    React.createElement(Legend, { wrapperStyle: { color: '#C9D1D9' } }),
                    React.createElement(Line, { type: 'monotone', dataKey: 'price', stroke: '#C9D1D9', dot: false, name: 'Price' }),
                    React.createElement(Line, { type: 'monotone', dataKey: 'bbUpper', stroke: '#DA3633', dot: false, name: 'Upper Band' }),
                    React.createElement(Line, { type: 'monotone', dataKey: 'bbMiddle', stroke: '#58A6FF', dot: false, name: 'Middle Band' }),
                    React.createElement(Line, { type: 'monotone', dataKey: 'bbLower', stroke: '#238636', dot: false, name: 'Lower Band' }),
                    // خط الدعم اليدوي
                    supportLevel > 0 && React.createElement(Line, { dataKey: 'support', stroke: '#FFD700', strokeDasharray: '3 3', dot: false, name: `Support (${supportLevel})`, data: data.map(d => ({ ...d, support: supportLevel })) }),
                    // خط المقاومة اليدوي
                    resistanceLevel > 0 && React.createElement(Line, { dataKey: 'resistance', stroke: '#FF4500', strokeDasharray: '3 3', dot: false, name: `Resistance (${resistanceLevel})`, data: data.map(d => ({ ...d, resistance: resistanceLevel })) })
                )
            )
        );
    };


    return React.createElement('div', { className: 'p-6 space-y-6 font-arabic' },
        // 1. التنبؤات والاحتمالات
        React.createElement(PredictionAnalysis, { lastDataPoint: lastDataPoint }),

        // 2. ملخص المؤشرات والإشارات
        React.createElement('div', { className: 'grid grid-cols-2 md:grid-cols-4 gap-4' },
            React.createElement(IndicatorCard, { title: 'السعر الحالي', value: lastDataPoint.price, unit: '$', trend: ((lastDataPoint.price - data[data.length - 2].price) / data[data.length - 2].price) * 100 }),
            React.createElement(IndicatorCard, { title: 'RSI', value: lastDataPoint.rsi, unit: '', trend: 0 }), // لا يمكن حساب ترند RSI بسهولة من البيانات الوهمية
            React.createElement(IndicatorCard, { title: 'MACD', value: lastDataPoint.macd, unit: '', trend: 0 }),
            React.createElement(TradingSignal, {})
        ),

        // 3. الرسوم البيانية
        // 4. تحليل الصورة (محاكاة)
        React.createElement('div', { className: 'bg-brand-surface p-4 rounded-lg shadow-md border border-brand-border' },
            React.createElement('h3', { className: 'text-brand-text-primary text-lg font-semibold mb-2' }, 'تحليل سريع للرسم البياني (محاكاة)'),
            React.createElement('p', { className: 'text-brand-text-secondary text-sm mb-4' }, 'يمكنك رفع صورة للرسم البياني للحصول على توصيات فورية باستخدام الذكاء الاصطناعي متعدد الوسائط.'),
            React.createElement('button', { className: 'bg-brand-secondary text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors' }, 'رفع صورة للتحليل (ميزة متقدمة)'),
            React.createElement('p', { className: 'text-brand-text-secondary text-xs mt-2' }, 'ملاحظة: هذه الميزة تتطلب تكامل واجهة برمجة تطبيقات (API) للذكاء الاصطناعي متعدد الوسائط (مثل Gemini Pro Vision) للعمل بشكل فعلي.')
        ),

        // 5. الرسوم البيانية
        React.createElement('div', { className: 'grid grid-cols-1 lg:grid-cols-2 gap-6' },
            React.createElement(BBChart, {}),
            React.createElement(RSIChart, {}),
            React.createElement('div', { className: 'lg:col-span-2' }, React.createElement(MACDChart, {})) // MACD يأخذ عرض كامل
        )
    );
};

export default TechnicalAnalysis;
