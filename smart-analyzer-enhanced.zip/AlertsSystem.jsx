// file: smart-analyzer-project/AlertsSystem.jsx
import React, { useState, useCallback } from 'react';

const AlertsSystem = () => {
    const [alerts, setAlerts] = useState([
        { id: 1, type: 'Price', condition: 'BTC/USD يصل إلى 70,000$', active: true, color: 'text-brand-success' },
        { id: 2, type: 'Indicator', condition: 'RSI لـ ETH/USD ينخفض إلى ما دون 30', active: true, color: 'text-brand-danger' },
        { id: 3, type: 'Signal', condition: 'تقاطع MACD صاعد لـ XRP/USD', active: false, color: 'text-brand-primary' },
    ]);
    const [newAlertPrice, setNewAlertPrice] = useState(65000);
    const [newAlertAsset, setNewAlertAsset] = useState('BTC/USD');

    const addPriceAlert = useCallback(() => {
        const newAlert = {
            id: Date.now(),
            type: 'Price',
            condition: `${newAlertAsset} يصل إلى ${newAlertPrice}$`,
            active: true,
            color: 'text-brand-primary'
        };
        setAlerts(prev => [...prev, newAlert]);
        setNewAlertPrice(0);
        setNewAlertAsset('');
    }, [newAlertPrice, newAlertAsset]);

    const toggleAlert = useCallback((id) => {
        setAlerts(prev => prev.map(alert =>
            alert.id === id ? { ...alert, active: !alert.active } : alert
        ));
    }, []);

    const removeAlert = useCallback((id) => {
        setAlerts(prev => prev.filter(alert => alert.id !== id));
    }, []);

    return (
        <div className="p-6 font-arabic bg-brand-surface rounded-lg shadow-xl border border-brand-border">
            <h2 className="text-2xl font-bold text-brand-text-primary mb-6 border-b border-brand-border pb-2">نظام الإشعارات والتنبيهات (محاكاة)</h2>

            {/* قسم إضافة تنبيه جديد */}
            <div className="mb-6 p-4 bg-brand-bg rounded-lg border border-brand-border space-y-4">
                <h3 className="text-lg font-semibold text-brand-text-primary">إعداد تنبيه سعر جديد</h3>
                <div className="flex space-x-4">
                    <input
                        type="text"
                        placeholder="أصل التداول (مثال: BTC/USD)"
                        value={newAlertAsset}
                        onChange={(e) => setNewAlertAsset(e.target.value)}
                        className="flex-1 bg-brand-surface text-brand-text-primary p-2 rounded-md border border-brand-border focus:outline-none"
                    />
                    <input
                        type="number"
                        placeholder="السعر المستهدف"
                        value={newAlertPrice}
                        onChange={(e) => setNewAlertPrice(parseFloat(e.target.value) || 0)}
                        className="flex-1 bg-brand-surface text-brand-text-primary p-2 rounded-md border border-brand-border focus:outline-none"
                    />
                    <button
                        onClick={addPriceAlert}
                        className="bg-brand-success text-white px-4 py-2 rounded-md hover:bg-green-700 transition-colors"
                        disabled={!newAlertAsset || !newAlertPrice}
                    >
                        إضافة تنبيه
                    </button>
                </div>
                <p className="text-brand-text-secondary text-xs">ملاحظة: في تطبيق حقيقي، سيتم إرسال هذه التنبيهات عبر البريد الإلكتروني أو الإشعارات اللحظية عند تحقق الشرط على الخادم.</p>
            </div>

            {/* قائمة التنبيهات النشطة */}
            <h3 className="text-lg font-semibold text-brand-text-primary mb-3">التنبيهات النشطة ({alerts.filter(a => a.active).length})</h3>
            <div className="space-y-3">
                {alerts.map(alert => (
                    <div key={alert.id} className={`flex justify-between items-center p-3 rounded-lg border ${alert.active ? 'bg-brand-bg border-brand-primary' : 'bg-brand-border border-brand-text-secondary opacity-50'}`}>
                        <div className="flex-1">
                            <p className={`font-semibold ${alert.color}`}>{alert.condition}</p>
                            <span className="text-xs text-brand-text-secondary">{alert.type} Alert</span>
                        </div>
                        <div className="flex items-center space-x-2">
                            <button
                                onClick={() => toggleAlert(alert.id)}
                                className={`text-sm px-3 py-1 rounded-full transition-colors ${alert.active ? 'bg-brand-danger text-white hover:bg-red-700' : 'bg-brand-success text-white hover:bg-green-700'}`}
                            >
                                {alert.active ? 'إيقاف' : 'تفعيل'}
                            </button>
                            <button
                                onClick={() => removeAlert(alert.id)}
                                className="text-brand-text-secondary hover:text-brand-danger transition-colors"
                            >
                                حذف
                            </button>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default AlertsSystem;
