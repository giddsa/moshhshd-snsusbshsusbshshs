// file: smart-analyzer-project/PredictionAnalysis.jsx
import React, { useMemo } from 'react';

// دالة مبسطة لحساب احتمالية النجاح بناءً على المؤشرات
// في تطبيق حقيقي، ستعتمد هذه الدالة على باك تيست لبيانات تاريخية
const calculateSuccessProbability = (rsi, macd, signal) => {
    let score = 50; // احتمالية أساسية

    // تأثير RSI
    if (rsi < 30) { // تشبع بيع (إشارة شراء)
        score += 15;
    } else if (rsi > 70) { // تشبع شراء (إشارة بيع)
        score += 15;
    } else if (rsi >= 30 && rsi <= 70) {
        score += 5; // منطقة حيادية
    }

    // تأثير MACD
    if (macd > signal) { // تقاطع صاعد (إشارة شراء)
        score += 10;
    } else if (macd < signal) { // تقاطع هابط (إشارة بيع)
        score += 10;
    }

    // ضمان أن الاحتمالية بين 0 و 100
    return Math.min(95, Math.max(5, score));
};

const PredictionAnalysis = ({ lastDataPoint }) => {
    const { rsi, macd, signal } = lastDataPoint;

    const probability = useMemo(() => {
        if (!rsi || !macd || !signal) return 50;
        return calculateSuccessProbability(rsi, macd, signal);
    }, [rsi, macd, signal]);

    const scenarios = useMemo(() => {
        // افتراض: الصفقة تستهدف ربح 2R ومخاطرة 1R
        const riskAmount = 100; // مبلغ افتراضي للمخاطرة
        const profitAmount = riskAmount * 2; // الربح المتوقع (2R)

        // السيناريوهات بناءً على الاحتمالية
        const bestCaseProfit = profitAmount * 1.5; // ربح أكبر
        const expectedProfit = profitAmount;
        const worstCaseLoss = -riskAmount * 1.5; // خسارة أكبر

        return {
            best: {
                label: 'أفضل سيناريو (ربح عالي)',
                value: `+${bestCaseProfit.toFixed(2)}$`,
                color: 'text-brand-success',
            },
            expected: {
                label: 'السيناريو المتوقع (2R)',
                value: `+${expectedProfit.toFixed(2)}$`,
                color: 'text-brand-primary',
            },
            worst: {
                label: 'أسوأ سيناريو (خسارة عالية)',
                value: `${worstCaseLoss.toFixed(2)}$`,
                color: 'text-brand-danger',
            },
        };
    }, []);

    return (
        <div className="p-6 font-arabic bg-brand-surface rounded-lg shadow-xl border border-brand-border">
            <h2 className="text-2xl font-bold text-brand-text-primary mb-6 border-b border-brand-border pb-2">التنبؤات والاحتمالات</h2>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {/* بطاقة احتمالية النجاح */}
                <div className="md:col-span-1 bg-brand-bg p-4 rounded-lg border border-brand-border text-center">
                    <p className="text-brand-text-secondary text-sm mb-2">احتمالية نجاح الصفقة</p>
                    <p className={`text-5xl font-extrabold ${probability > 60 ? 'text-brand-success' : probability < 40 ? 'text-brand-danger' : 'text-brand-primary'}`}>
                        {probability.toFixed(0)}%
                    </p>
                    <p className="text-brand-text-secondary text-xs mt-2">بناءً على تحليل المؤشرات الفنية (RSI, MACD)</p>
                </div>

                {/* بطاقات السيناريوهات */}
                <div className="md:col-span-2 space-y-3">
                    {Object.values(scenarios).map((scenario, index) => (
                        <div key={index} className="flex justify-between items-center bg-brand-bg p-3 rounded-lg border border-brand-border">
                            <p className="text-brand-text-primary font-semibold">{scenario.label}</p>
                            <p className={`text-xl font-bold ${scenario.color}`}>{scenario.value}</p>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

export default PredictionAnalysis;
