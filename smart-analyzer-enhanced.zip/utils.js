// file: smart-analyzer-project/utils.js

/**
 * دالة لحساب المتوسط المتحرك البسيط (SMA)
 * @param {number[]} data - مصفوفة من الأرقام (أسعار الإغلاق)
 * @param {number} period - الفترة الزمنية للمتوسط
 * @returns {number[]} - مصفوفة المتوسطات المتحركة
 */
export const calculateSMA = (data, period) => {
    const sma = [];
    for (let i = 0; i < data.length; i++) {
        if (i < period - 1) {
            sma.push(null);
        } else {
            const slice = data.slice(i - period + 1, i + 1);
            const sum = slice.reduce((a, b) => a + b, 0);
            sma.push(sum / period);
        }
    }
    return sma;
};

/**
 * دالة لحساب المتوسط المتحرك الأسي (EMA)
 * @param {number[]} data - مصفوفة من الأرقام (أسعار الإغلاق)
 * @param {number} period - الفترة الزمنية للمتوسط
 * @returns {number[]} - مصفوفة المتوسطات المتحركة الأسية
 */
export const calculateEMA = (data, period) => {
    const k = 2 / (period + 1);
    const ema = [];
    let currentEMA = null;

    for (let i = 0; i < data.length; i++) {
        if (currentEMA === null) {
            // استخدام SMA كنقطة بداية لـ EMA
            if (i >= period - 1) {
                const slice = data.slice(i - period + 1, i + 1);
                currentEMA = slice.reduce((a, b) => a + b, 0) / period;
                ema.push(currentEMA);
            } else {
                ema.push(null);
            }
        } else {
            currentEMA = (data[i] - currentEMA) * k + currentEMA;
            ema.push(currentEMA);
        }
    }
    return ema;
};

/**
 * دالة لحساب مؤشر القوة النسبية (RSI)
 * @param {number[]} data - مصفوفة من الأرقام (أسعار الإغلاق)
 * @param {number} period - الفترة الزمنية (عادة 14)
 * @returns {number[]} - مصفوفة قيم RSI
 */
export const calculateRSI = (data, period = 14) => {
    const rsi = [];
    const changes = [];

    for (let i = 1; i < data.length; i++) {
        changes.push(data[i] - data[i - 1]);
    }

    let avgGain = 0;
    let avgLoss = 0;

    for (let i = 0; i < data.length; i++) {
        if (i < period) {
            rsi.push(null);
            if (i === period - 1) {
                let initialGain = 0;
                let initialLoss = 0;
                for (let j = 0; j < period; j++) {
                    const change = changes[j];
                    if (change > 0) {
                        initialGain += change;
                    } else {
                        initialLoss += Math.abs(change);
                    }
                }
                avgGain = initialGain / period;
                avgLoss = initialLoss / period;
                const rs = avgLoss === 0 ? 100 : avgGain / avgLoss;
                rsi[i] = 100 - (100 / (1 + rs));
            }
        } else {
            const currentChange = changes[i - 1];
            let currentGain = currentChange > 0 ? currentChange : 0;
            let currentLoss = currentChange < 0 ? Math.abs(currentChange) : 0;

            avgGain = (avgGain * (period - 1) + currentGain) / period;
            avgLoss = (avgLoss * (period - 1) + currentLoss) / period;

            const rs = avgLoss === 0 ? 100 : avgGain / avgLoss;
            rsi.push(100 - (100 / (1 + rs)));
        }
    }
    return rsi;
};

/**
 * دالة لحساب مؤشر MACD
 * @param {number[]} data - مصفوفة من الأرقام (أسعار الإغلاق)
 * @param {number} fastPeriod - الفترة السريعة (عادة 12)
 * @param {number} slowPeriod - الفترة البطيئة (عادة 26)
 * @param {number} signalPeriod - فترة خط الإشارة (عادة 9)
 * @returns {{macd: number[], signal: number[], histogram: number[]}} - قيم MACD
 */
export const calculateMACD = (data, fastPeriod = 12, slowPeriod = 26, signalPeriod = 9) => {
    const fastEMA = calculateEMA(data, fastPeriod);
    const slowEMA = calculateEMA(data, slowPeriod);
    const macd = [];

    for (let i = 0; i < data.length; i++) {
        if (fastEMA[i] !== null && slowEMA[i] !== null) {
            macd.push(fastEMA[i] - slowEMA[i]);
        } else {
            macd.push(null);
        }
    }

    const signal = calculateEMA(macd.filter(v => v !== null), signalPeriod);
    const histogram = [];

    let signalIndex = 0;
    for (let i = 0; i < data.length; i++) {
        if (macd[i] !== null) {
            histogram.push(macd[i] - signal[signalIndex]);
            signalIndex++;
        } else {
            histogram.push(null);
        }
    }

    return { macd, signal, histogram };
};

/**
 * دالة لحساب مؤشر Bollinger Bands
 * @param {number[]} data - مصفوفة من الأرقام (أسعار الإغلاق)
 * @param {number} period - الفترة الزمنية (عادة 20)
 * @param {number} stdDev - الانحراف المعياري (عادة 2)
 * @returns {{middle: number[], upper: number[], lower: number[]}} - قيم Bollinger Bands
 */
export const calculateBollingerBands = (data, period = 20, stdDev = 2) => {
    const bands = { middle: [], upper: [], lower: [] };

    for (let i = 0; i < data.length; i++) {
        if (i < period - 1) {
            bands.middle.push(null);
            bands.upper.push(null);
            bands.lower.push(null);
        } else {
            const slice = data.slice(i - period + 1, i + 1);
            const sma = slice.reduce((a, b) => a + b, 0) / period;

            // حساب الانحراف المعياري
            const variance = slice.map(x => Math.pow(x - sma, 2)).reduce((a, b) => a + b, 0) / period;
            const standardDeviation = Math.sqrt(variance);

            const upperBand = sma + standardDeviation * stdDev;
            const lowerBand = sma - standardDeviation * stdDev;

            bands.middle.push(sma);
            bands.upper.push(upperBand);
            bands.lower.push(lowerBand);
        }
    }
    return bands;
};

// دالة مولدة لبيانات وهمية (للتجربة)
export const generateDummyData = (count = 100) => {
    const data = [];
    let price = 100;
    for (let i = 0; i < count; i++) {
        // محاكاة حركة سعر عشوائية
        price += (Math.random() - 0.5) * 2;
        price = Math.max(10, price); // منع السعر من الانخفاض الشديد
        data.push({
            name: `Day ${i + 1}`,
            price: parseFloat(price.toFixed(2)),
        });
    }

    const prices = data.map(d => d.price);
    const rsi = calculateRSI(prices);
    const macd = calculateMACD(prices);
    const bb = calculateBollingerBands(prices);

    return data.map((d, i) => ({
        ...d,
        rsi: rsi[i],
        macd: macd.macd[i],
        signal: macd.signal[i] !== undefined ? macd.signal[i] : null,
        histogram: macd.histogram[i],
        bbMiddle: bb.middle[i],
        bbUpper: bb.upper[i],
        bbLower: bb.lower[i],
    })).filter(d => d.rsi !== null); // تصفية البيانات التي لا تحتوي على مؤشرات محسوبة
};
