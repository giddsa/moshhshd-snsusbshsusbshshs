// file: smart-analyzer-project/index.js
import React from 'react';
import ReactDOM from 'react-dom/client';
import TechnicalAnalysis from './TechnicalAnalysis.jsx';
import RiskManagement from './RiskManagement.jsx';
import AlertsSystem from './AlertsSystem.jsx';
import DailyReport from './DailyReport.jsx';

// هذا الملف سيحل محل ملف index-Xe5fYa_o.js المجمع في النهاية،
// ولكن حاليًا سنستخدمه لتشغيل المكون الجديد فقط.

// دالة لتشغيل المكون الجديد
function renderTechnicalAnalysis() {
    const container = document.getElementById('technical-analysis-root');
    if (container) {
        // نستخدم createRoot من react-dom/client
        const root = ReactDOM.createRoot(container);
        root.render(
            React.createElement(React.StrictMode, null,
                React.createElement(DailyReport, null),
                React.createElement(AlertsSystem, null),
                React.createElement(RiskManagement, null),
                React.createElement(TechnicalAnalysis, null)
            )
        );
    }
}

// التأكد من تحميل React و ReactDOM
// بما أننا نستخدم importmap، يجب أن تكون متاحة
renderTechnicalAnalysis();
