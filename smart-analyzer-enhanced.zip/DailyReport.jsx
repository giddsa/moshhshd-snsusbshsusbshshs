// file: smart-analyzer-project/DailyReport.jsx
import React from 'react';

const DailyReport = () => {
    const reportData = [
        { asset: 'BTC/USD', signal: 'شراء قوي', reason: 'تقاطع MACD إيجابي و RSI يخرج من منطقة التشبع البيعي.', color: 'bg-brand-success' },
        { asset: 'ETH/USD', signal: 'بيع', reason: 'السعر يلامس الحد العلوي لـ Bollinger Bands.', color: 'bg-brand-danger' },
        { asset: 'XRP/USD', signal: 'انتظار', reason: 'السعر يتحرك في نطاق جانبي، المؤشرات محايدة.', color: 'bg-brand-primary' },
    ];

    return (
        <div className="p-6 font-arabic bg-brand-surface rounded-lg shadow-xl border border-brand-border">
            <h2 className="text-2xl font-bold text-brand-text-primary mb-6 border-b border-brand-border pb-2">ملخص التحليل اليومي</h2>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {reportData.map((item, index) => (
                    <div key={index} className="bg-brand-bg p-4 rounded-lg border border-brand-border space-y-2">
                        <div className="flex justify-between items-center">
                            <h3 className="text-xl font-bold text-brand-text-primary">{item.asset}</h3>
                            <span className={`text-white text-sm px-3 py-1 rounded-full font-semibold ${item.color}`}>{item.signal}</span>
                        </div>
                        <p className="text-brand-text-secondary text-sm">{item.reason}</p>
                        <p className="text-xs text-brand-primary font-semibold">المخاطرة المقترحة: 1%</p>
                    </div>
                ))}
            </div>

            <div className="mt-6 p-4 bg-brand-bg rounded-lg border border-brand-border">
                <h3 className="text-lg font-semibold text-brand-text-primary mb-2">إحصائيات الأداء الأسبوعي (محاكاة)</h3>
                <div className="flex justify-between text-sm text-brand-text-secondary">
                    <p>إجمالي الإشارات: <span className="text-brand-primary font-bold">25</span></p>
                    <p>إشارات ناجحة: <span className="text-brand-success font-bold">18 (72%)</span></p>
                    <p>إشارات فاشلة: <span className="text-brand-danger font-bold">7 (28%)</span></p>
                </div>
            </div>
        </div>
    );
};

export default DailyReport;
