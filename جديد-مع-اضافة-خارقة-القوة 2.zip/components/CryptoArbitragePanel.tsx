import React, { useState, useCallback } from 'react';
import { Translation } from '../types';
import { LoadingSpinner, ArrowsRightLeftIcon, CheckCircleIcon } from './Icons';

interface ArbitrageOpportunity {
    id: string;
    symbol: string;
    buyExchange: string;
    buyPrice: number;
    sellExchange: string;
    sellPrice: number;
    profit: number;
}

const exampleExchanges = ['Binance', 'Kraken', 'Coinbase', 'Bybit', 'OKX'];
const examplePairs = ['BTC/USDT', 'ETH/USDT', 'SOL/USDT', 'XRP/USDT'];

const generateMockOpportunities = (): ArbitrageOpportunity[] => {
    const opportunities: ArbitrageOpportunity[] = [];
    const numOpportunities = Math.floor(Math.random() * 4) + 1; // 1 to 4 opportunities

    for (let i = 0; i < numOpportunities; i++) {
        const pair = examplePairs[Math.floor(Math.random() * examplePairs.length)];
        const basePrice = pair.startsWith('BTC') ? 65000 : (pair.startsWith('ETH') ? 3500 : (pair.startsWith('SOL') ? 150 : 0.5));
        
        const price1 = basePrice * (1 + (Math.random() - 0.5) * 0.005); // Small variation
        const price2 = price1 * (1 + (Math.random() * 0.008 + 0.002)); // 0.2% to 1.0% higher

        const exchanges = [...exampleExchanges].sort(() => 0.5 - Math.random());
        const [buyExchange, sellExchange] = exchanges;
        
        const profit = ((price2 - price1) / price1) * 100;

        if (profit > 0.1) { // Only show somewhat meaningful profits
            opportunities.push({
                id: `${pair}-${i}`,
                symbol: pair,
                buyExchange,
                buyPrice: price1,
                sellExchange,
                sellPrice: price2,
                profit,
            });
        }
    }
    return opportunities.sort((a,b) => b.profit - a.profit);
};


export const CryptoArbitragePanel: React.FC<{ t: Translation }> = ({ t }) => {
    const [isLoading, setIsLoading] = useState(false);
    const [opportunities, setOpportunities] = useState<ArbitrageOpportunity[]>([]);

    const handleScan = useCallback(() => {
        setIsLoading(true);
        setOpportunities([]);
        setTimeout(() => {
            setOpportunities(generateMockOpportunities());
            setIsLoading(false);
        }, 1500); // Simulate network latency
    }, []);

    return (
        <div className="space-y-8">
            <div className="glass-card p-6">
                <h2 className="text-2xl font-bold">{t.arbitrageTitle}</h2>
                <p className="text-brand-text-secondary mt-2 mb-6">{t.arbitrageDescription}</p>
                <button
                    onClick={handleScan}
                    disabled={isLoading}
                    className="w-full sm:w-auto main-button bg-brand-primary hover:bg-brand-secondary text-white font-bold py-2.5 px-6 rounded-lg transition duration-300 disabled:bg-gray-500 disabled:cursor-not-allowed flex items-center justify-center"
                >
                    {isLoading ? <LoadingSpinner /> : <ArrowsRightLeftIcon className="w-5 h-5 me-2 rtl:ms-2" />}
                    {isLoading ? t.scanning : t.scanForArbitrage}
                </button>
            </div>
            
            <div className="glass-card p-6 min-h-[300px]">
                {isLoading && (
                    <div className="flex justify-center items-center h-full py-16">
                        <LoadingSpinner className="w-8 h-8"/>
                    </div>
                )}

                {!isLoading && opportunities.length === 0 && (
                    <div className="text-center py-16">
                         <p className="text-brand-text-secondary">{t.noOpportunities}</p>
                    </div>
                )}
                
                {!isLoading && opportunities.length > 0 && (
                    <div className="space-y-4">
                        {opportunities.map((op) => (
                            <div key={op.id} className="bg-brand-surface/50 p-4 rounded-lg border border-brand-border transform hover:scale-[1.02] transition-transform duration-300">
                                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 mb-3">
                                    <h3 className="text-lg font-bold text-brand-text-primary">{op.symbol}</h3>
                                    <div className="bg-green-900/50 text-green-300 text-sm font-semibold px-3 py-1 rounded-full flex items-center gap-2">
                                        <CheckCircleIcon className="w-4 h-4" />
                                        {t.potentialProfit}: {op.profit.toFixed(3)}%
                                    </div>
                                </div>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div className="bg-brand-bg/40 p-3 rounded-md">
                                        <p className="text-sm text-green-400 font-semibold">{t.buyOn} {op.buyExchange}</p>
                                        <p className="text-2xl font-mono">${op.buyPrice.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 4 })}</p>
                                    </div>
                                     <div className="bg-brand-bg/40 p-3 rounded-md">
                                        <p className="text-sm text-red-400 font-semibold">{t.sellOn} {op.sellExchange}</p>
                                        <p className="text-2xl font-mono">${op.sellPrice.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 4 })}</p>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                )}
            </div>
             <div className="text-center text-xs text-brand-text-secondary">
                <p>{t.arbitrageDisclaimer}</p>
            </div>
        </div>
    );
};