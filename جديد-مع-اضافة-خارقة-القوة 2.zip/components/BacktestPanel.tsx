import React, { useState, useCallback } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';
import { Kline, Translation, BacktestResult } from '../types';
import { runBacktest, fetchHistoricalKlines } from '../services/backtestService';
import { LoadingSpinner, BeakerIcon, ErrorIcon } from './Icons';

interface BacktestPanelProps {
    t: Translation;
}

const ResultCard: React.FC<{ label: string; value: string | number; className?: string }> = ({ label, value, className }) => (
    <div className="bg-brand-surface/50 p-4 rounded-lg border border-brand-border text-center">
        <p className="text-sm text-brand-text-secondary">{label}</p>
        <p className={`text-2xl font-bold mt-1 ${className}`}>{value}</p>
    </div>
);

const PAIRS = ['BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'BNBUSDT', 'XRPUSDT', 'ADAUSDT', 'DOGEUSDT'];

export const BacktestPanel: React.FC<BacktestPanelProps> = ({ t }) => {
    const [strategy, setStrategy] = useState('ema_crossover');
    const [pair, setPair] = useState('BTCUSDT');
    const [timeframe, setTimeframe] = useState('1h');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [backtestResult, setBacktestResult] = useState<BacktestResult | null>(null);
    
    const TIMEFRAMES = [
        { value: '15m', label: t.timeframe15m },
        { value: '1h', label: t.timeframe1h },
        { value: '4h', label: t.timeframe4h },
        { value: '1d', label: t.timeframe1d },
    ];

    const handleRunBacktest = useCallback(async () => {
        setIsLoading(true);
        setError(null);
        setBacktestResult(null);

        try {
            // FIX: Removed extra argument from fetchHistoricalKlines call.
            const fetchedData = await fetchHistoricalKlines(pair, timeframe);
            if (fetchedData.length < 50) {
                 throw new Error("Not enough data returned from API for a reliable backtest.");
            }
            const result = runBacktest(fetchedData, strategy);
            setBacktestResult(result);
        } catch (err) {
            console.error("Backtest failed:", err);
            setError(t.errorFetchData);
        } finally {
            setIsLoading(false);
        }
    }, [pair, timeframe, strategy, t]);


    return (
        <div className="space-y-8">
            <div className="glass-card p-6">
                <h2 className="text-2xl font-bold">{t.backtesterTitle}</h2>
                <p className="text-brand-text-secondary mt-2 mb-6">{t.backtesterDescription}</p>

                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 items-end gap-4">
                    <div>
                        <label htmlFor="pair" className="block text-sm font-medium text-brand-text-secondary mb-2">{t.pair}</label>
                        <select id="pair" value={pair} onChange={(e) => setPair(e.target.value)} className="w-full bg-brand-surface border border-brand-border rounded-lg p-2.5 focus:ring-2 focus:ring-brand-primary focus:outline-none">
                            {PAIRS.map(p => <option key={p} value={p}>{p}</option>)}
                        </select>
                    </div>
                     <div>
                        <label htmlFor="timeframe" className="block text-sm font-medium text-brand-text-secondary mb-2">{t.timeframe}</label>
                        <select id="timeframe" value={timeframe} onChange={(e) => setTimeframe(e.target.value)} className="w-full bg-brand-surface border border-brand-border rounded-lg p-2.5 focus:ring-2 focus:ring-brand-primary focus:outline-none">
                            {TIMEFRAMES.map(tf => <option key={tf.value} value={tf.value}>{tf.label}</option>)}
                        </select>
                    </div>
                    <div>
                        <label htmlFor="strategy" className="block text-sm font-medium text-brand-text-secondary mb-2">{t.selectStrategy}</label>
                        <select
                            id="strategy"
                            value={strategy}
                            onChange={(e) => setStrategy(e.target.value)}
                            className="w-full bg-brand-surface border border-brand-border rounded-lg p-2.5 focus:ring-2 focus:ring-brand-primary focus:outline-none"
                        >
                            <option value="ema_crossover">{t.emaCrossover}</option>
                        </select>
                    </div>
                    <button
                        onClick={handleRunBacktest}
                        disabled={isLoading}
                        className="w-full main-button bg-brand-primary hover:bg-brand-secondary text-white font-bold py-2.5 px-6 rounded-lg transition duration-300 disabled:bg-gray-500 disabled:cursor-not-allowed flex items-center justify-center"
                    >
                        {isLoading ? <LoadingSpinner /> : <BeakerIcon className="w-5 h-5 me-2 rtl:ms-2" />}
                        {isLoading ? t.runningBacktest : t.runBacktest}
                    </button>
                </div>
                 {error && (
                     <div className="mt-4 bg-red-900/50 border border-brand-danger text-red-300 px-4 py-3 rounded-lg flex items-start space-x-2 rtl:space-x-reverse" role="alert">
                        <ErrorIcon className="h-5 w-5 mt-0.5"/>
                        <span>{error}</span>
                    </div>
                )}
            </div>

            {isLoading && !backtestResult && (
                <div className="text-center p-8 glass-card flex justify-center items-center">
                    <LoadingSpinner className="w-8 h-8 -ml-1 mr-3"/>
                    <p>{t.runningBacktest}</p>
                </div>
            )}

            {backtestResult && (
                <div className="glass-card p-6">
                    <h3 className="text-xl font-bold mb-4">{t.backtestResults}</h3>
                    <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
                        <ResultCard 
                            label={t.totalPnl} 
                            value={`$${backtestResult.totalPnl.toFixed(2)}`}
                            className={backtestResult.totalPnl >= 0 ? 'text-green-400' : 'text-red-400'}
                        />
                        <ResultCard label={t.winRate} value={`${backtestResult.winRate.toFixed(2)}%`} />
                        <ResultCard label={t.totalTrades} value={backtestResult.totalTrades} />
                        <ResultCard label={t.avgWin} value={`$${backtestResult.averageWin.toFixed(2)}`} className="text-green-400" />
                        <ResultCard label={t.avgLoss} value={`$${backtestResult.averageLoss.toFixed(2)}`} className="text-red-400" />
                    </div>
                    <div className="mt-8">
                         <h3 className="text-lg font-semibold mb-2 text-brand-text-secondary">{t.pnlChart}</h3>
                         <ResponsiveContainer width="100%" height={300}>
                            <AreaChart data={backtestResult.pnlHistory}>
                                <defs>
                                    <linearGradient id="colorPnl" x1="0" y1="0" x2="0" y2="1">
                                    <stop offset="5%" stopColor="#58A6FF" stopOpacity={0.8}/>
                                    <stop offset="95%" stopColor="#58A6FF" stopOpacity={0}/>
                                    </linearGradient>
                                </defs>
                                <CartesianGrid strokeDasharray="3 3" stroke="#30363D" />
                                <XAxis dataKey="timestamp" tickFormatter={(time) => new Date(time).toLocaleDateString()} stroke="#8B949E" />
                                <YAxis stroke="#8B949E" />
                                <Tooltip contentStyle={{ backgroundColor: '#161B22', border: '1px solid #30363D' }} />
                                <Area type="monotone" dataKey="pnl" stroke="#58A6FF" fillOpacity={1} fill="url(#colorPnl)" name="Cumulative PnL" />
                            </AreaChart>
                        </ResponsiveContainer>
                    </div>
                </div>
            )}
        </div>
    );
};
