import { GoogleGenAI } from "@google/genai";
import { Language, NewsArticle } from '../types';

// We cannot use responseSchema with googleSearch, so we ask for raw JSON text and parse it.
const fetchRealTimeNews = async (prompt: string, language: Language): Promise<NewsArticle[]> => {
    if (!process.env.API_KEY) {
        throw new Error("API key for Gemini is not configured.");
    }
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                tools: [{ googleSearch: {} }],
                // Note: responseMimeType and responseSchema are NOT supported when using googleSearch tool.
            }
        });

        // The response will contain the text with search results.
        // We need to extract the JSON block from the markdown.
        const text = response.text || "";
        
        // Regex to extract JSON array from markdown code blocks
        const jsonMatch = text.match(/```json\n([\s\S]*?)\n```/) || text.match(/```([\s\S]*?)```/);
        
        let jsonString = "";
        if (jsonMatch && jsonMatch[1]) {
            jsonString = jsonMatch[1];
        } else {
            // Fallback: try to find the first [ and last ]
            const start = text.indexOf('[');
            const end = text.lastIndexOf(']');
            if (start !== -1 && end !== -1) {
                jsonString = text.substring(start, end + 1);
            } else {
                console.warn("Could not find JSON in response:", text);
                return [];
            }
        }

        const articles: NewsArticle[] = JSON.parse(jsonString);
        return articles;

    } catch (error) {
        console.error("Error calling Gemini API for news:", error);
        throw new Error("Failed to get news from AI.");
    }
};

export const fetchLatestNews = async (language: Language): Promise<NewsArticle[]> => {
    const today = new Date().toLocaleDateString(language === 'ar' ? 'ar-EG' : 'en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
    
    const prompt = `
    You are a real-time crypto news aggregator.
    
    TASK: Perform a Google Search to find the absolute LATEST cryptocurrency news for today: ${today}.
    
    CRITICAL RULES:
    1. IGNORE any news older than 24 hours. I strictly want news from TODAY.
    2. Select the 7 most impactful stories (Market moves, Regulation, Major Listings, Hacks).
    3. Output the result strictly as a valid JSON array.
    4. Language: ${language === 'ar' ? 'Arabic' : 'English'}.
    
    JSON Structure per item:
    [
      {
        "id": "unique_string",
        "title": "News Headline",
        "source": "Publisher Name (e.g. Coindesk, Reuters)",
        "summary": "One sentence summary.",
        "sentiment": "Bullish" | "Bearish" | "Neutral",
        "timestamp": "ISO 8601 string of the article time",
        "url": "The actual link to the article found in search"
      }
    ]
    `;

    return await fetchRealTimeNews(prompt, language);
};

export const searchNews = async (query: string, language: Language): Promise<NewsArticle[]> => {
    const today = new Date().toLocaleDateString(language === 'ar' ? 'ar-EG' : 'en-US');
    
    const prompt = `
    You are a real-time crypto news aggregator.
    
    TASK: Perform a Google Search to find the latest news specifically about "${query}".
    Current Date: ${today}.
    
    CRITICAL RULES:
    1. Focus on the most recent developments (last 24-48 hours).
    2. Output strictly as a valid JSON array.
    3. Language: ${language === 'ar' ? 'Arabic' : 'English'}.

    JSON Structure per item:
    [
      {
        "id": "unique_string",
        "title": "News Headline",
        "source": "Publisher Name",
        "summary": "One sentence summary.",
        "sentiment": "Bullish" | "Bearish" | "Neutral",
        "timestamp": "ISO 8601 string",
        "url": "The actual link to the article"
      }
    ]
    `;
    
    return await fetchRealTimeNews(prompt, language);
};