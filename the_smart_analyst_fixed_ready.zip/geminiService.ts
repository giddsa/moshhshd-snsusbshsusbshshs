import { GoogleGenAI, Type, Chat } from "@google/genai";
import { NumericalAnalysisResult, GeminiAnalysisResult, Language, UploadedImage, AnalysisResult, ChatMessage } from '../types';

const getSystemInstruction = (language: Language) => {
    if (language === 'ar') {
        return "أنت خبير في التحليل الفني للعملات الرقمية. مهمتك هي كتابة شرح واضح وموجز بناءً على بيانات المؤشرات المقدمة. يجب أن يكون الشرح بلغة عربية احترافية ومفهومة للمتداولين. لا تقدم نصائح مالية مباشرة، بل اشرح الوضع الفني.";
    }
    return "You are an expert crypto technical analyst. Your task is to write a clear and concise explanation based on the provided indicator data. The tone should be professional and understandable for traders. Do not give direct financial advice, but explain the technical situation.";
};

const getSatoSystemInstruction = (language: Language) => {
    if (language === 'ar') {
        return "أنت 'سطو'، خبير ومساعد ذكاء اصطناعي متخصص في تداول العملات الرقمية والتحليل الفني. مهمتك هي الإجابة على أسئلة المستخدم المتعلقة بالتداول فقط. كن ودودًا ومحترفًا. إذا سُئلت عن أي موضوع آخر غير التداول، أجب بلطف بأنك متخصص في التداول فقط ولا يمكنك المساعدة في مواضيع أخرى.";
    }
    return "You are 'Sato', an expert AI assistant specializing in cryptocurrency trading and technical analysis. Your job is to answer user questions related to trading ONLY. Be friendly and professional. If asked about any topic other than trading, politely state that you only specialize in trading and cannot help with other subjects.";
}

const getPromptForData = (analysis: NumericalAnalysisResult, language: Language): string => {
    const langInstructions = language === 'ar' ? 
        'يرجى تقديم ملخص من جملة واحدة وشرح مفصل باللغة العربية.' :
        'Please provide a one-sentence summary and a detailed explanation in English.';

    return `
    Based on the following technical analysis data for ${analysis.symbol}:
    - Recommendation: ${analysis.possible_position}
    - Trend: ${analysis.trend_direction}
    - RSI: ${analysis.indicators.rsi.toFixed(2)}
    - EMA(9): ${analysis.indicators.ema['9'].toFixed(2)}
    - EMA(21): ${analysis.indicators.ema['21'].toFixed(2)}
    - EMA(50): ${analysis.indicators.ema['50'].toFixed(2)}
    - Proposed Entry: ${analysis.possible_entry.toFixed(2)}
    - Proposed Take Profit: ${analysis.take_profit.toFixed(2)}
    - Proposed Stop Loss: ${analysis.stop_loss.toFixed(2)}
    - Confidence: ${(analysis.confidence * 100).toFixed(0)}%

    ${langInstructions}
    
    Generate a JSON object with two keys: "analysis_summary" and "analysis_explanation".
    - The summary should be a single, concise sentence.
    - The explanation should be a paragraph detailing why the recommendation was made, referencing the indicators provided.
    `;
};

const fullAnalysisSchema = {
    type: Type.OBJECT,
    properties: {
        symbol: { type: Type.STRING, description: 'The symbol of the crypto asset, e.g., BTCUSDT. If not visible, state "Unknown".' },
        timeframe: { type: Type.STRING, description: 'The chart timeframe, e.g., 4h, 1D. If not visible, state "Unknown".' },
        analysis_summary: { type: Type.STRING, description: 'A single, concise sentence in the specified language summarizing the trade idea.' },
        possible_position: { type: Type.STRING, enum: ['Long', 'Short', 'Stay Out'] },
        trend_direction: { type: Type.STRING, enum: ['Uptrend', 'Downtrend', 'Sideways'] },
        possible_entry: { type: Type.NUMBER, description: 'A realistic entry price near the current price.' },
        take_profit: { type: Type.NUMBER, description: 'A logical take-profit price.' },
        stop_loss: { type: Type.NUMBER, description: 'A logical stop-loss price.' },
        rr_ratio: { type: Type.NUMBER, description: 'The calculated risk/reward ratio.' },
        confidence: { type: Type.NUMBER, description: 'A confidence score between 0.0 and 1.0 for the trade setup.' },
        analysis_explanation: { type: Type.STRING, description: 'A detailed paragraph in the specified language explaining the reasoning behind the recommendation.' },
        indicators: {
            type: Type.OBJECT,
            description: "Estimated values of visible indicators. Provide a numerical estimate for all fields.",
            properties: {
                rsi: { type: Type.NUMBER },
                macd: { type: Type.OBJECT, properties: { macd: {type: Type.NUMBER}, signal: {type: Type.NUMBER}, hist: {type: Type.NUMBER} } },
                atr: { type: Type.NUMBER },
                ema: { type: Type.OBJECT, properties: { '9': {type: Type.NUMBER}, '21': {type: Type.NUMBER}, '50': {type: Type.NUMBER} } },
                bollinger: { type: Type.OBJECT, properties: { upper: {type: Type.NUMBER}, middle: {type: Type.NUMBER}, lower: {type: Type.NUMBER} } },
            }
        }
    },
    required: [
        'symbol', 'timeframe', 'analysis_summary', 'possible_position', 'trend_direction',
        'possible_entry', 'take_profit', 'stop_loss', 'rr_ratio', 'confidence',
        'analysis_explanation', 'indicators'
    ]
};


export const generateAnalysisExplanation = async (
    analysis: NumericalAnalysisResult,
    language: Language
): Promise<GeminiAnalysisResult> => {
    if (!process.env.API_KEY) {
        throw new Error("API key for Gemini is not configured.");
    }
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

    const prompt = getPromptForData(analysis, language);
    const systemInstruction = getSystemInstruction(language);

    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                systemInstruction: systemInstruction,
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        analysis_summary: {
                            type: Type.STRING,
                            description: 'A single, concise sentence summarizing the analysis.'
                        },
                        analysis_explanation: {
                            type: Type.STRING,
                            description: 'A detailed paragraph explaining the analysis based on the provided indicators.'
                        }
                    },
                    required: ['analysis_summary', 'analysis_explanation']
                }
            }
        });

        const jsonText = response.text?.trim();
        if (!jsonText) {
            throw new Error("Received an empty response from the AI.");
        }
        
        // Robust parsing: handle potential markdown code blocks
        const cleanedJsonText = jsonText.replace(/^```json\s*/, '').replace(/```\s*$/, '');
        
        if (!cleanedJsonText) {
            throw new Error("Received a response that was empty after cleaning markdown.");
        }

        try {
            const parsedResult: GeminiAnalysisResult = JSON.parse(cleanedJsonText);
            return parsedResult;
        } catch (parseError) {
            console.error("Failed to parse JSON response from AI:", cleanedJsonText, parseError);
            throw new Error("Failed to parse the analysis from the AI. The format was invalid.");
        }

    } catch (error) {
        console.error("Error calling Gemini API:", error);
        throw new Error("Failed to get analysis from AI. Please check the API key and network connection.");
    }
};


export const analyzeChartImage = async (
    image: UploadedImage,
    leverage: number,
    language: Language
): Promise<AnalysisResult> => {
     if (!process.env.API_KEY) {
        throw new Error("API key for Gemini is not configured.");
    }
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    const imagePart = {
        inlineData: {
            mimeType: image.mimeType,
            data: image.data,
        },
    };

    const textPrompt = `You are a world-class cryptocurrency technical analyst. Your task is to analyze the attached chart image with extreme precision.

Instructions:
1.  **Identify**: From the image, determine the cryptocurrency symbol (e.g., BTCUSDT) and the chart's timeframe (e.g., 4h, 1D). If they are not visible, infer them from context or state as 'Unknown'.
2.  **Analyze Trend**: Determine the current market trend (Uptrend, Downtrend, Sideways).
3.  **Analyze Indicators**: Visually identify and estimate the values of any visible technical indicators. Common indicators to look for are RSI, MACD, EMAs (Exponential Moving Averages), and Bollinger Bands. If specific values aren't clear, describe their state (e.g., 'RSI is in overbought territory around 75', 'MACD line is crossing above the signal line'). You must provide a numerical estimate for all indicator fields in the schema, even if it's a rough estimation (e.g., 0 if not visible).
4.  **Formulate Recommendation**: Based on your complete analysis, decide on a trading position: 'Long', 'Short', or 'Stay Out'.
5.  **Define Trade Parameters**:
    *   \`possible_entry\`: A realistic entry price near the current price.
    *   \`stop_loss\`: A logical stop-loss price based on recent support/resistance or volatility.
    *   \`take_profit\`: A take-profit price that provides a reasonable risk/reward ratio (aim for at least 1.5).
6.  **Calculate Ratios**:
    *   \`rr_ratio\`: Calculate the risk/reward ratio ((take_profit - possible_entry) / (possible_entry - stop_loss)) for a Long, or ((possible_entry - take_profit) / (stop_loss - possible_entry)) for a Short. If the position is 'Stay Out' this can be 0.
    *   \`confidence\`: Provide a confidence score between 0.0 and 1.0 for this trade setup.
7.  **Generate Explanations (Language: ${language === 'ar' ? 'Arabic' : 'English'})**:
    *   \`analysis_summary\`: A single, concise sentence summarizing the trade idea.
    *   \`analysis_explanation\`: A detailed paragraph explaining the reasoning behind the recommendation. Mention the key indicators and trend analysis that led to your conclusion.
8. **Leverage Context**: The user is considering a leverage of ${leverage}x. If leverage is greater than 1, mention the increased risk in your explanation. If leverage is 1, this is a spot trade, so no need to mention leverage risk.

**Output Format**: You MUST return your complete analysis as a single JSON object that strictly adheres to the provided schema. Do not add any extra text or explanations outside of the JSON object.`;

    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: { parts: [imagePart, { text: textPrompt }] },
            config: {
                responseMimeType: 'application/json',
                responseSchema: fullAnalysisSchema,
            }
        });
        
        const jsonText = response.text?.trim();
        if (!jsonText) {
            throw new Error("Received an empty response from the AI.");
        }

        // Robust parsing: handle potential markdown code blocks
        const cleanedJsonText = jsonText.replace(/^```json\s*/, '').replace(/```\s*$/, '');

        if (!cleanedJsonText) {
            throw new Error("Received a response that was empty after cleaning markdown.");
        }

        try {
            const result: AnalysisResult = JSON.parse(cleanedJsonText);
            return result;
        } catch (parseError) {
            console.error("Failed to parse JSON response from AI:", cleanedJsonText, parseError);
            throw new Error("Failed to parse the analysis from the AI. The format was invalid.");
        }

    } catch (error) {
        console.error("Error calling Gemini Vision API:", error);
        throw new Error("Failed to get analysis from AI. The model may not have been able to interpret the image.");
    }
};

// Fix: Replaced inefficient stateless chat function with a creator for a stateful chat session.
// This aligns with the intended use of the Chat object for managing conversation history.
export const createSatoChat = (language: Language): Chat => {
    if (!process.env.API_KEY) {
        throw new Error("API key for Gemini is not configured.");
    }
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

    return ai.chats.create({
        model: 'gemini-2.5-flash',
        config: {
            systemInstruction: getSatoSystemInstruction(language),
        },
    });
};
