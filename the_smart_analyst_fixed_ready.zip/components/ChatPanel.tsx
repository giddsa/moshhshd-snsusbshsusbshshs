import React, { useState, useRef, useEffect } from 'react';
import { Chat } from '@google/genai';
import { ChatMessage, Language, Translation } from '../types';
import { createSatoChat } from 'geminiService';
import { LoadingSpinner, SendIcon, ErrorIcon } from './Icons';

interface ChatPanelProps {
    t: Translation;
    language: Language;
}

export const ChatPanel: React.FC<ChatPanelProps> = ({ t, language }) => {
    const [messages, setMessages] = useState<ChatMessage[]>([]);
    // Fix: Maintain a stateful chat session object for the conversation.
    const [chat, setChat] = useState<Chat | null>(null);
    const [currentMessage, setCurrentMessage] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const messagesEndRef = useRef<HTMLDivElement>(null);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    };

    useEffect(() => {
        scrollToBottom();
    }, [messages, isLoading]);
    
    // Fix: Initialize a new stateful chat session when the component mounts or the language changes.
    useEffect(() => {
        setMessages([{ role: 'model', parts: [{ text: t.satoWelcome }] }]);
        try {
            setError(null);
            const newChat = createSatoChat(language);
            setChat(newChat);
        } catch (err) {
            const errorMessage = (err instanceof Error) ? err.message : t.errorChatFailed;
            if (errorMessage.includes('API key not valid')) {
                setError(t.errorApiKey);
           } else {
                setError(errorMessage);
           }
        }
    }, [t.satoWelcome, language, t.errorApiKey, t.errorChatFailed]);

    const handleSend = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!currentMessage.trim() || isLoading || !chat) return;

        const userMessage: ChatMessage = { role: 'user', parts: [{ text: currentMessage.trim() }] };
        const messageToSend = currentMessage.trim();

        setMessages(prev => [...prev, userMessage]);
        setCurrentMessage('');
        setIsLoading(true);
        setError(null);

        try {
            // Fix: Use the persistent chat session to send a message.
            const response = await chat.sendMessage({ message: messageToSend });
            const responseText = response.text;
            const modelMessage: ChatMessage = { role: 'model', parts: [{ text: responseText }] };
            setMessages(prev => [...prev, modelMessage]);
        } catch (err) {
             const errorMessage = (err instanceof Error) ? err.message : t.errorChatFailed;
            if (errorMessage.includes('API key not valid')) {
                 setError(t.errorApiKey);
            } else {
                 setError(errorMessage);
            }
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="bg-brand-surface border border-brand-border rounded-lg flex flex-col h-[70vh] max-h-[800px]">
            <div className="p-4 border-b border-brand-border">
                <h2 className="text-xl font-bold text-center">{t.chatWithSato}</h2>
            </div>
            <div className="flex-grow p-4 overflow-y-auto">
                <div className="space-y-4">
                    {messages.map((msg, index) => (
                        <div key={index} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                            <div className={`max-w-prose p-3 rounded-lg ${msg.role === 'user' ? 'bg-brand-primary text-white' : 'bg-brand-bg text-brand-text-primary'}`}>
                                <p className="text-sm whitespace-pre-wrap">{msg.parts[0].text}</p>
                            </div>
                        </div>
                    ))}
                    {isLoading && (
                        <div className="flex justify-start">
                            <div className="max-w-xs p-3 rounded-lg bg-brand-bg text-brand-text-primary">
                                <div className="flex items-center space-x-2">
                                    <div className="w-2 h-2 bg-brand-text-secondary rounded-full animate-pulse"></div>
                                    <div className="w-2 h-2 bg-brand-text-secondary rounded-full animate-pulse delay-75"></div>
                                    <div className="w-2 h-2 bg-brand-text-secondary rounded-full animate-pulse delay-150"></div>
                                </div>
                            </div>
                        </div>
                    )}
                     <div ref={messagesEndRef} />
                </div>
            </div>
            {error && (
                 <div className="p-4 border-t border-brand-border">
                     <div className="bg-red-900/50 border border-brand-danger text-red-300 px-4 py-2 rounded-lg flex items-start space-x-2 rtl:space-x-reverse" role="alert">
                        <ErrorIcon className="h-5 w-5 mt-0.5"/>
                        <span>{error}</span>
                    </div>
                </div>
            )}
            <div className="p-4 border-t border-brand-border">
                <form onSubmit={handleSend} className="flex items-center space-x-2 rtl:space-x-reverse">
                    <input
                        type="text"
                        value={currentMessage}
                        onChange={(e) => setCurrentMessage(e.target.value)}
                        placeholder={t.chatPlaceholder}
                        className="flex-grow bg-brand-bg border border-brand-border rounded-lg p-2 focus:ring-2 focus:ring-brand-primary focus:outline-none text-sm"
                        disabled={isLoading}
                    />
                    <button
                        type="submit"
                        disabled={isLoading || !currentMessage.trim()}
                        className="bg-brand-primary hover:bg-brand-secondary text-white font-bold p-2 rounded-lg transition duration-300 disabled:bg-gray-500 disabled:cursor-not-allowed flex items-center justify-center w-10 h-10"
                    >
                       {isLoading ? <LoadingSpinner className="h-5 w-5 -ml-0 mr-0"/> : <SendIcon className="w-5 h-5" />}
                    </button>
                </form>
            </div>
        </div>
    );
};
