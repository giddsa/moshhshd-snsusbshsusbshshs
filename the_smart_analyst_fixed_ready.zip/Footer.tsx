import React from 'react';
import { Translation } from '../types';
import { InstagramIcon } from './Icons';

interface FooterProps {
    t: Translation;
}

export const Footer: React.FC<FooterProps> = ({ t }) => {
    return (
        <footer className="bg-brand-surface border-t border-brand-border mt-8">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-4 text-center text-sm text-brand-text-secondary flex flex-col sm:flex-row justify-between items-center gap-4">
                <p>&copy; {new Date().getFullYear()} {t.headerTitle}. All Rights Reserved.</p>
                <a 
                    href="https://www.instagram.com/2k__.p?igsh=cnE1ZXFzNmg5dWNu&utm_source=qr" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="flex items-center gap-2 hover:text-brand-primary transition-colors"
                >
                    <InstagramIcon className="w-5 h-5" />
                    {t.instagramLink}
                </a>
            </div>
        </footer>
    );
};