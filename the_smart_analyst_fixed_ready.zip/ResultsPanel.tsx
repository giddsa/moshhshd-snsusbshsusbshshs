
import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, AreaChart, Area } from 'recharts';
import { AnalysisResult, Kline, Translation } from '../types';
import { ChartIcon, CheckCircleIcon, DocumentTextIcon, DownloadIcon, ExclamationIcon, XCircleIcon } from './Icons';

interface ResultsPanelProps {
    result: AnalysisResult | null;
    klineData: Kline[] | null;
    isLoading: boolean;
    t: Translation;
}

const renderRecommendationValue = (position: AnalysisResult['possible_position'], t: Translation) => {
    switch (position) {
        case 'Long':
            return <span className="flex items-center font-bold text-green-400"><CheckCircleIcon className="w-5 h-5 me-2 rtl:ms-2" /> {t.long}</span>;
        case 'Short':
            return <span className="flex items-center font-bold text-red-400"><XCircleIcon className="w-5 h-5 me-2 rtl:ms-2" /> {t.short}</span>;
        default:
            return <span className="flex items-center font-bold text-yellow-400"><ExclamationIcon className="w-5 h-5 me-2 rtl:ms-2" /> {t.stayOut}</span>;
    }
};

const DataCard: React.FC<{ label: string; value: React.ReactNode; className?: string }> = ({ label, value, className }) => (
    <div className={`flex justify-between items-center py-2 ${className}`}>
        <span className="text-sm text-brand-text-secondary">{label}</span>
        <span className="text-sm font-semibold">{value}</span>
    </div>
);

export const ResultsPanel: React.FC<ResultsPanelProps> = ({ result, klineData, isLoading, t }) => {
    
    const handleSave = () => {
        if (!result) return;
        const jsonString = `data:text/json;charset=utf-8,${encodeURIComponent(
            JSON.stringify(result, null, 2)
        )}`;
        const link = document.createElement("a");
        link.href = jsonString;
        link.download = `analysis_${result.symbol}_${result.timeframe}.json`;
        link.click();
    };

    if (!result && !isLoading) {
        return (
            <div className="bg-brand-surface p-6 rounded-lg border border-brand-border min-h-[600px] flex flex-col justify-center items-center text-center">
                 <ChartIcon className="w-16 h-16 text-brand-border mb-4"/>
                <h3 className="text-xl font-bold">{t.analysisResults}</h3>
                <p className="text-brand-text-secondary mt-2">{t.waitingForAnalysis}</p>
            </div>
        );
    }
    
    return (
        <div className="bg-brand-surface p-4 md:p-6 rounded-lg border border-brand-border">
            <h2 className="text-2xl font-bold mb-4">{t.analysisResults}</h2>
            {isLoading && !result && <div className="min-h-[600px] flex items-center justify-center"><p>{t.analyzing}</p></div>}
            
            {klineData && (
                <div className="mb-8">
                    <h3 className="text-lg font-semibold mb-2 text-brand-text-secondary">{t.chart}</h3>
                    <ResponsiveContainer width="100%" height={300}>
                        <LineChart data={klineData}>
                            <CartesianGrid strokeDasharray="3 3" stroke="#30363D" />
                            <XAxis dataKey="timestamp" tickFormatter={(time) => new Date(time).toLocaleDateString()} stroke="#8B949E" />
                            <YAxis yAxisId="left" stroke="#8B949E" />
                            <Tooltip contentStyle={{ backgroundColor: '#161B22', border: '1px solid #30363D' }} />
                            <Legend />
                            <Line yAxisId="left" type="monotone" dataKey="close" stroke="#58A6FF" strokeWidth={2} dot={false} name="Close Price" />
                        </LineChart>
                    </ResponsiveContainer>
                </div>
            )}
            
            {result && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="bg-brand-bg p-4 rounded-lg border border-brand-border">
                        <h3 className="text-lg font-bold mb-3 flex items-center"><CheckCircleIcon className="w-6 h-6 me-2 rtl:ms-2 text-brand-primary"/>{t.recommendation}</h3>
                        <div className="divide-y divide-brand-border">
                            <DataCard label={t.position} value={renderRecommendationValue(result.possible_position, t)} />
                            <DataCard label={t.entryPrice} value={`$${result.possible_entry.toFixed(3)}`} />
                            <DataCard label={t.takeProfit} value={`$${result.take_profit.toFixed(3)}`} className="text-green-400" />
                            <DataCard label={t.stopLoss} value={`$${result.stop_loss.toFixed(3)}`} className="text-red-400" />
                            <DataCard label={t.riskRewardRatio} value={`1 : ${result.rr_ratio.toFixed(2)}`} />
                            <DataCard label={t.confidence} value={`${(result.confidence * 100).toFixed(0)}%`} />
                        </div>
                    </div>
                    
                    <div className="flex flex-col gap-4">
                       <div className="bg-brand-bg p-4 rounded-lg border border-brand-border">
                            <h3 className="text-lg font-bold mb-2 flex items-center"><DocumentTextIcon className="w-6 h-6 me-2 rtl:ms-2 text-brand-primary"/>{t.summary}</h3>
                            <p className="text-sm text-brand-text-secondary leading-relaxed">{result.analysis_summary}</p>
                        </div>
                         <button 
                             onClick={handleSave}
                             className="w-full bg-gray-700 hover:bg-gray-600 text-white font-bold py-2 px-4 rounded-lg transition duration-300 flex items-center justify-center">
                            <DownloadIcon className="w-5 h-5 me-2 rtl:ms-2" />
                            {t.saveAnalysis}
                        </button>
                    </div>

                    <div className="md:col-span-2 bg-brand-bg p-4 rounded-lg border border-brand-border">
                        <h3 className="text-lg font-bold mb-2">{t.fullAnalysis}</h3>
                        <p className="text-sm text-brand-text-secondary whitespace-pre-wrap leading-relaxed">{result.analysis_explanation}</p>
                    </div>

                    <div className="md:col-span-2 mt-4 text-center text-xs text-brand-text-secondary">
                        <p>{t.disclaimer}</p>
                    </div>
                </div>
            )}
        </div>
    );
};
