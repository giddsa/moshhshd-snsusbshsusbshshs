import { GoogleGenAI, Type } from "@google/genai";
import { Language, NewsArticle } from '../types';

const newsArticleSchema = {
    type: Type.OBJECT,
    properties: {
        id: { type: Type.STRING, description: 'A unique ID for the article (e.g., a timestamp).'},
        title: { type: Type.STRING, description: 'A compelling and realistic news headline.' },
        source: { type: Type.STRING, description: 'A plausible news source name (e.g., "CryptoDaily", "MarketWatch").' },
        summary: { type: Type.STRING, description: 'A concise, one-paragraph summary of the news article.' },
        sentiment: { type: Type.STRING, enum: ['Bullish', 'Bearish', 'Neutral'], description: 'The market sentiment of the news.' },
        timestamp: { type: Type.STRING, description: 'The publication date and time in ISO 8601 format.' },
        url: { type: Type.STRING, description: 'A dummy URL for the article (e.g., "https://example.com/news/123").' },
    },
    required: ['id', 'title', 'source', 'summary', 'sentiment', 'timestamp', 'url']
};

const newsArraySchema = {
    type: Type.ARRAY,
    items: newsArticleSchema,
};

const callGeminiWithRetries = async (prompt: string, language: Language) => {
    if (!process.env.API_KEY) {
        throw new Error("API key for Gemini is not configured.");
    }
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                responseMimeType: 'application/json',
                responseSchema: newsArraySchema,
            }
        });

        const jsonText = response.text.trim();
        const articles: NewsArticle[] = JSON.parse(jsonText);
        return articles;
    } catch (error) {
        console.error("Error calling Gemini API for news:", error);
        throw new Error("Failed to get news from AI.");
    }
};

export const fetchLatestNews = async (language: Language): Promise<NewsArticle[]> => {
    const prompt = `Generate a list of 7 recent, impactful, and realistic cryptocurrency news articles. 
    The articles should cover a variety of topics including market movements, major project updates, regulatory news, and technological innovations.
    For each article, provide a title, a plausible source, a concise summary, a market sentiment ('Bullish', 'Bearish', or 'Neutral'), a recent ISO 8601 timestamp, a unique ID, and a dummy URL.
    The content must be in ${language === 'ar' ? 'Arabic' : 'English'}.
    Ensure the timestamps are very recent and sorted from newest to oldest.
    Your output must be a valid JSON array adhering to the specified schema.`;

    return await callGeminiWithRetries(prompt, language);
};

export const searchNews = async (query: string, language: Language): Promise<NewsArticle[]> => {
    const prompt = `Generate a list of 5 recent and realistic news articles specifically about "${query}" in the cryptocurrency space.
    The articles should be informative and relevant to a trader or investor interested in this topic.
    For each article, provide a title, a plausible source, a concise summary, a market sentiment ('Bullish', 'Bearish', or 'Neutral'), a recent ISO 8601 timestamp, a unique ID, and a dummy URL.
    The content must be in ${language === 'ar' ? 'Arabic' : 'English'}.
    Ensure the timestamps are very recent and sorted from newest to oldest.
    Your output must be a valid JSON array adhering to the specified schema.`;
    
    return await callGeminiWithRetries(prompt, language);
};