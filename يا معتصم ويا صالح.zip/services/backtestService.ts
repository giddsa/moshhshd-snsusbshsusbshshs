import { Kline, BacktestResult } from '../types';

// Custom error for API fetch failures
export class ApiError extends Error {
    constructor(message: string) {
        super(message);
        this.name = 'ApiError';
    }
}

/**
 * Fetches historical K-line (candlestick) data from the KuCoin API.
 * @param symbol The trading pair symbol (e.g., 'BTCUSDT').
 * @param interval The timeframe interval (e.g., '1h').
 * @returns A promise that resolves to an array of Kline objects.
 */
export const fetchHistoricalKlines = async (
    symbol: string,
    interval: string
): Promise<Kline[]> => {
    // Format symbol for KuCoin API (e.g., BTCUSDT -> BTC-USDT)
    const pair = symbol.toUpperCase().replace(/USDT$/, '-USDT');
    
    // KuCoin uses specific values for interval
    const kucoinIntervalMap: { [key: string]: string } = {
        '15m': '15min',
        '1h': '1hour',
        '4h': '4hour',
        '1d': '1day',
    };
    const apiInterval = kucoinIntervalMap[interval] || '1hour';
    
    // Calculate duration for the given interval to fetch enough data for analysis
    const intervalSeconds: { [key: string]: number } = {
        '15m': 15 * 60,
        '1h': 60 * 60,
        '4h': 4 * 60 * 60,
        '1d': 24 * 60 * 60,
    };
    const durationInSeconds = intervalSeconds[interval] || 3600; // Default to 1 hour
    const candlesToFetch = 1000; // Increase to request a wider time range for better data availability

    const endAt = Math.floor(Date.now() / 1000);
    const startAt = endAt - (candlesToFetch * durationInSeconds);

    const kucoinApiUrl = `https://api.kucoin.com/api/v1/market/candles?type=${apiInterval}&symbol=${pair}&startAt=${startAt}&endAt=${endAt}`;
    
    // Use a CORS proxy to bypass browser restrictions
    const proxyUrl = `https://corsproxy.io/?${encodeURIComponent(kucoinApiUrl)}`;
    
    try {
        const response = await fetch(proxyUrl);
        if (!response.ok) {
            throw new Error(`KuCoin API error: ${response.status} ${response.statusText}`);
        }
        const res = await response.json();
        if (res.code !== '200000' || !res.data) {
             // Check for a specific KuCoin error message for non-existent symbols.
             if (res.msg && res.msg.toLowerCase().includes('symbol not exist')) {
                 throw new Error(`Unsupported trading pair: ${pair}`);
             }
             throw new Error(res.msg || 'Invalid data from KuCoin API');
        }
        
        // res.data is an array of arrays: [time, open, close, high, low, volume, turnover]
        const raw: string[][] = res.data;
        if (raw.length === 0) {
            return [];
        }
        
        const parsed: Kline[] = raw
          .map((d) => ({
            timestamp: Number(d[0]) * 1000,
            open: parseFloat(d[1]),
            close: parseFloat(d[2]),
            high: parseFloat(d[3]),
            low: parseFloat(d[4]),
            volume: parseFloat(d[5]),
          }))
          .reverse(); // KuCoin returns in descending order, so reverse to get ascending.
          
        return parsed;

    } catch (error) {
        console.error(`Failed to fetch historical k-lines for ${symbol}:`, error);
        if (error instanceof Error && error.message.includes('Unsupported trading pair')) {
            throw new ApiError(error.message);
        }
        throw new ApiError(`Failed to fetch data from KuCoin for ${symbol}. Please check the symbol or try again later.`);
    }
};


const calculateEMAValues = (prices: number[], period: number): (number | null)[] => {
    if (prices.length < period) return Array(prices.length).fill(null);

    const k = 2 / (period + 1);
    const emas: (number | null)[] = Array(period - 1).fill(null);
    
    let initialSma = prices.slice(0, period).reduce((a, b) => a + b, 0) / period;
    emas.push(initialSma);

    for (let i = period; i < prices.length; i++) {
        const ema = (prices[i] * k) + (emas[i - 1]! * (1 - k));
        emas.push(ema);
    }
    return emas;
};

export const runBacktest = (klineData: Kline[], strategy: string): BacktestResult => {
    if (strategy === 'ema_crossover') {
        return runEmaCrossover(klineData);
    }
    // Future strategies can be added here
    throw new Error(`Strategy ${strategy} not implemented.`);
};

const runEmaCrossover = (klineData: Kline[]): BacktestResult => {
    const shortPeriod = 9;
    const longPeriod = 21;
    const initialCapital = 10000; // Assuming a starting capital for percentage PnL
    
    const closePrices = klineData.map(k => k.close);
    const emaShort = calculateEMAValues(closePrices, shortPeriod);
    const emaLong = calculateEMAValues(closePrices, longPeriod);

    let inPosition = false;
    let entryPrice = 0;
    const trades: number[] = [];
    const pnlHistory: { timestamp: number; pnl: number }[] = [];
    let cumulativePnl = 0;

    for (let i = 1; i < klineData.length; i++) {
        const currentEmaShort = emaShort[i];
        const currentEmaLong = emaLong[i];
        const prevEmaShort = emaShort[i - 1];
        const prevEmaLong = emaLong[i - 1];
        
        if (currentEmaShort === null || currentEmaLong === null || prevEmaShort === null || prevEmaLong === null) {
            pnlHistory.push({ timestamp: klineData[i].timestamp, pnl: cumulativePnl });
            continue;
        }

        // Crossover condition
        const goldenCross = prevEmaShort <= prevEmaLong && currentEmaShort > currentEmaLong;
        const deathCross = prevEmaShort >= prevEmaLong && currentEmaShort < currentEmaLong;

        if (goldenCross && !inPosition) {
            inPosition = true;
            entryPrice = klineData[i].close;
        } else if (deathCross && inPosition) {
            inPosition = false;
            const exitPrice = klineData[i].close;
            const pnl = exitPrice - entryPrice;
            trades.push(pnl);
            cumulativePnl += pnl;
        }
        
        pnlHistory.push({ timestamp: klineData[i].timestamp, pnl: cumulativePnl });
    }
    
    const winningTrades = trades.filter(pnl => pnl > 0);
    const losingTrades = trades.filter(pnl => pnl <= 0);

    const totalPnl = trades.reduce((sum, pnl) => sum + pnl, 0);
    const totalTrades = trades.length;
    const winRate = totalTrades > 0 ? (winningTrades.length / totalTrades) * 100 : 0;
    const averageWin = winningTrades.length > 0 ? winningTrades.reduce((sum, pnl) => sum + pnl, 0) / winningTrades.length : 0;
    const averageLoss = losingTrades.length > 0 ? losingTrades.reduce((sum, pnl) => sum + pnl, 0) / losingTrades.length : 0;

    return {
        totalPnl,
        winRate,
        totalTrades,
        averageWin,
        averageLoss,
        pnlHistory
    };
};