import { Kline, NumericalAnalysisResult, Indicators, TradingType, ManualAnalysisInput } from '../types';

const calculateStdDev = (values: number[]): number => {
    if (values.length === 0) return 0;
    const mean = values.reduce((a, b) => a + b, 0) / values.length;
    const squareDiffs = values.map(value => Math.pow(value - mean, 2));
    const avgSquareDiff = squareDiffs.reduce((a, b) => a + b, 0) / values.length;
    return Math.sqrt(avgSquareDiff);
};

export const calculateEMA = (prices: number[], period: number): number => {
    if (prices.length < period) return 0;
    const k = 2 / (period + 1);
    let ema = prices.slice(0, period).reduce((a, b) => a + b, 0) / period; // Initial SMA
    for (let i = period; i < prices.length; i++) {
        ema = (prices[i] * k) + (ema * (1 - k));
    }
    return ema;
};

const calculateEMAArray = (prices: number[], period: number): number[] => {
    if (prices.length < period) return [];
    const k = 2 / (period + 1);
    const emas: number[] = [];
    let ema = prices.slice(0, period).reduce((a, b) => a + b, 0) / period;
    emas.push(...Array(period - 1).fill(0), ema);

    for (let i = period; i < prices.length; i++) {
        ema = (prices[i] * k) + (ema * (1 - k));
        emas.push(ema);
    }
    return emas;
};

export const calculateRSI = (prices: number[], period = 14): number => {
    if (prices.length <= period) return 50;
    const changes = prices.slice(1).map((price, i) => price - prices[i]);
    
    let avgGain = 0;
    let avgLoss = 0;

    for (let i = 0; i < period; i++) {
        if (changes[i] > 0) avgGain += changes[i];
        else avgLoss += Math.abs(changes[i]);
    }
    avgGain /= period;
    avgLoss /= period;

    for (let i = period; i < changes.length; i++) {
        const change = changes[i];
        if (change > 0) {
            avgGain = (avgGain * (period - 1) + change) / period;
            avgLoss = (avgLoss * (period - 1)) / period;
        } else {
            avgLoss = (avgLoss * (period - 1) + Math.abs(change)) / period;
            avgGain = (avgGain * (period - 1)) / period;
        }
    }

    if (avgLoss === 0) return 100;
    const rs = avgGain / avgLoss;
    return 100 - (100 / (1 + rs));
};

const calculateATR = (klines: Kline[], period = 14): number => {
    if (klines.length <= period) return 0;
    const trueRanges: number[] = [];
    for (let i = 1; i < klines.length; i++) {
        const k = klines[i];
        const prevClose = klines[i - 1].close;
        const tr = Math.max(k.high - k.low, Math.abs(k.high - prevClose), Math.abs(k.low - prevClose));
        trueRanges.push(tr);
    }

    if (trueRanges.length < period) return 0;
    const recentTRs = trueRanges.slice(-period);
    return recentTRs.reduce((a, b) => a + b, 0) / period; // Simple ATR
};

export const calculateMACD = (prices: number[], shortPeriod = 12, longPeriod = 26, signalPeriod = 9): Indicators['macd'] => {
    if (prices.length < longPeriod) return { macd: 0, signal: 0, hist: 0 };
    
    const emaShort = calculateEMAArray(prices, shortPeriod);
    const emaLong = calculateEMAArray(prices, longPeriod);
    
    const macdLine = emaShort.map((val, i) => i >= longPeriod - 1 ? val - emaLong[i] : 0).slice(longPeriod - 1);
    
    if (macdLine.length < signalPeriod) return { macd: 0, signal: 0, hist: 0 };

    const signalLine = calculateEMAArray(macdLine, signalPeriod);
    
    const lastMacd = macdLine[macdLine.length - 1];
    const lastSignal = signalLine[signalLine.length - 1];
    const lastHist = lastMacd - lastSignal;

    return {
        macd: lastMacd,
        signal: lastSignal,
        hist: lastHist,
    };
};

const calculateBollingerBands = (prices: number[], period = 20, stdDev = 2): Indicators['bollinger'] => {
    if (prices.length < period) return { upper: 0, middle: 0, lower: 0 };
    const slice = prices.slice(-period);
    const middle = slice.reduce((a, b) => a + b, 0) / period; // SMA
    const sd = calculateStdDev(slice);
    const upper = middle + (sd * stdDev);
    const lower = middle - (sd * stdDev);
    return { upper, middle, lower };
};

export const processAnalysis = (klineData: Kline[], leverage: number, tradingType: TradingType): NumericalAnalysisResult => {
    if (klineData.length < 50) {
        throw new Error("Not enough data for analysis. At least 50 data points are required.");
    }
    const lastKline = klineData[klineData.length - 1];
    const currentPrice = lastKline.close;
    const closePrices = klineData.map(k => k.close);

    const ema9 = calculateEMA(closePrices, 9);
    const ema21 = calculateEMA(closePrices, 21);
    const ema50 = calculateEMA(closePrices, 50);
    const rsi = calculateRSI(closePrices, 14);
    const atr = calculateATR(klineData, 14);
    const macd = calculateMACD(closePrices);
    const bollinger = calculateBollingerBands(closePrices);

    let possible_position: 'Long' | 'Short' | 'Stay Out' = 'Stay Out';
    let trend_direction: 'Uptrend' | 'Downtrend' | 'Sideways' = 'Sideways';
    let confidence = 0.4; // Base confidence

    // Trend analysis using EMAs
    const isUptrend = ema9 > ema21 && ema21 > ema50 && currentPrice > ema50;
    const isDowntrend = ema9 < ema21 && ema21 < ema50 && currentPrice < ema50;

    if (isUptrend) {
        trend_direction = 'Uptrend';
        confidence += 0.15;
    } else if (isDowntrend) {
        trend_direction = 'Downtrend';
        confidence += 0.15;
    }

    // Confirmation with RSI and MACD
    if (trend_direction === 'Uptrend') {
        let confirmations = 0;
        if (rsi > 50 && rsi < 80) confirmations++; // Healthy upward momentum, not overbought
        if (macd.macd > macd.signal) confirmations++; // MACD confirms bullish momentum

        if (confirmations >= 1) { // Loosened: only one confirmation needed
            possible_position = 'Long';
            confidence += 0.15 * confirmations; // Add confidence for each confirmation
        }
    } else if (trend_direction === 'Downtrend') {
        let confirmations = 0;
        if (rsi < 50 && rsi > 20) confirmations++; // Healthy downward momentum, not oversold
        if (macd.macd < macd.signal) confirmations++; // MACD confirms bearish momentum

        if (confirmations >= 1) { // Loosened: only one confirmation needed
            possible_position = 'Short';
            confidence += 0.15 * confirmations;
        }
    }
    
    // If no clear signals, default to Stay Out
    if (possible_position === 'Stay Out') {
        confidence = 0.5;
    }

    const rr_ratio = 2.0;
    let possible_entry = currentPrice;
    let take_profit = currentPrice;
    let stop_loss = currentPrice;
    
    if (possible_position === 'Long') {
        stop_loss = currentPrice - (atr * 1.5);
        take_profit = currentPrice + (currentPrice - stop_loss) * rr_ratio;
    } else if (possible_position === 'Short') {
        stop_loss = currentPrice + (atr * 1.5);
        take_profit = currentPrice - (stop_loss - currentPrice) * rr_ratio;
    } else {
        // Provide hypothetical SL/TP even for Stay Out for context
        stop_loss = currentPrice - atr * 2;
        take_profit = currentPrice + atr * 2;
    }
    
    // Adjust confidence based on leverage
    confidence = Math.max(0.3, confidence - (leverage / 300));

    const result: NumericalAnalysisResult = {
        symbol: "BTCUSDT",
        timeframe: "1h",
        possible_position,
        trend_direction,
        possible_entry,
        take_profit,
        stop_loss,
        rr_ratio: possible_position !== 'Stay Out' ? rr_ratio : 0,
        confidence: Math.min(0.95, confidence),
        indicators: {
            rsi,
            macd,
            atr,
            ema: { '9': ema9, '21': ema21, '50': ema50 },
            bollinger,
        },
    };

    // CRITICAL FIX: Prevent "Short" recommendation on "Spot" trades
    if (tradingType === 'spot' && result.possible_position === 'Short') {
        result.possible_position = 'Stay Out';
        result.rr_ratio = 0;
        result.confidence = Math.min(result.confidence, 0.4);
    }

    return result;
};

// FIX: Added missing processManualAnalysis function
export const processManualAnalysis = (input: ManualAnalysisInput): NumericalAnalysisResult => {
    const {
        symbol,
        currentPrice,
        rsi,
        ema9,
        ema21,
        ema50,
        macdLine,
        macdSignal,
        atr,
        leverage,
        tradingType
    } = input;

    let possible_position: 'Long' | 'Short' | 'Stay Out' = 'Stay Out';
    let trend_direction: 'Uptrend' | 'Downtrend' | 'Sideways' = 'Sideways';
    let confidence = 0.4;

    const isUptrend = ema9 > ema21 && ema21 > ema50 && currentPrice > ema50;
    const isDowntrend = ema9 < ema21 && ema21 < ema50 && currentPrice < ema50;

    if (isUptrend) {
        trend_direction = 'Uptrend';
        confidence += 0.2;
    } else if (isDowntrend) {
        trend_direction = 'Downtrend';
        confidence += 0.2;
    }
    
    const macdHist = macdLine - macdSignal;

    if (trend_direction === 'Uptrend') {
        let confirmations = 0;
        if (rsi > 50 && rsi < 75) confirmations++;
        if (macdLine > macdSignal && macdHist > 0) confirmations++;

        if (confirmations === 2) {
            possible_position = 'Long';
            confidence += 0.25;
        }
    } else if (trend_direction === 'Downtrend') {
        let confirmations = 0;
        if (rsi < 50 && rsi > 25) confirmations++;
        if (macdLine < macdSignal && macdHist < 0) confirmations++;

        if (confirmations === 2) {
            possible_position = 'Short';
            confidence += 0.25;
        }
    }

    if (possible_position === 'Stay Out') {
        confidence = 0.5;
    }
    
    const rr_ratio = 2.0;
    let possible_entry = currentPrice;
    let take_profit = currentPrice;
    let stop_loss = currentPrice;

    if (possible_position === 'Long') {
        stop_loss = currentPrice - (atr * 1.5);
        take_profit = currentPrice + (currentPrice - stop_loss) * rr_ratio;
    } else if (possible_position === 'Short') {
        stop_loss = currentPrice + (atr * 1.5);
        take_profit = currentPrice - (stop_loss - currentPrice) * rr_ratio;
    } else {
        stop_loss = currentPrice - atr * 2;
        take_profit = currentPrice + atr * 2;
    }

    confidence = Math.max(0.3, confidence - (leverage / 300));

    const result: NumericalAnalysisResult = {
        symbol,
        timeframe: "Manual",
        possible_position,
        trend_direction,
        possible_entry,
        take_profit,
        stop_loss,
        rr_ratio: possible_position !== 'Stay Out' ? rr_ratio : 0,
        confidence: Math.min(0.95, confidence),
        indicators: {
            rsi,
            macd: { macd: macdLine, signal: macdSignal, hist: macdHist },
            atr,
            ema: { '9': ema9, '21': ema21, '50': ema50 },
            bollinger: { upper: 0, middle: 0, lower: 0 },
        },
    };

    if (tradingType === 'spot' && result.possible_position === 'Short') {
        result.possible_position = 'Stay Out';
        result.rr_ratio = 0;
        result.confidence = Math.min(result.confidence, 0.4);
    }

    return result;
};


// Helper for chart indicators. Padded with nulls.
export const calculateEMAArrayForChart = (prices: number[], period: number): (number | null)[] => {
    if (prices.length < period) return Array(prices.length).fill(null);
    const k = 2 / (period + 1);
    const emas: (number | null)[] = Array(period - 1).fill(null);
    let ema = prices.slice(0, period).reduce((a, b) => a + b, 0) / period; // Initial SMA
    emas.push(ema);

    for (let i = period; i < prices.length; i++) {
        const prevEma = emas[i - 1];
        if (prevEma !== null) {
            ema = (prices[i] * k) + (prevEma * (1 - k));
            emas.push(ema);
        } else {
            emas.push(null);
        }
    }
    return emas;
};

// New exported function for the chart
export const calculateMACDForChart = (prices: number[], shortPeriod = 12, longPeriod = 26, signalPeriod = 9): { macd: number | null, signal: number | null, hist: number | null }[] => {
    const emaShort = calculateEMAArrayForChart(prices, shortPeriod);
    const emaLong = calculateEMAArrayForChart(prices, longPeriod);

    const macdLine: (number | null)[] = prices.map((_, i) => {
        if (emaShort[i] === null || emaLong[i] === null) return null;
        return emaShort[i]! - emaLong[i]!;
    });
    
    const validMacdLineForSignal = macdLine.filter(v => v !== null) as number[];
    const signalLineForMacd = calculateEMAArrayForChart(validMacdLineForSignal, signalPeriod);

    const signalLine: (number | null)[] = Array(prices.length).fill(null);
    let validMacdIndex = 0;
    for (let i = 0; i < prices.length; i++) {
        if (macdLine[i] !== null) {
            if (validMacdIndex < signalLineForMacd.length) {
                signalLine[i] = signalLineForMacd[validMacdIndex];
            }
            validMacdIndex++;
        }
    }

    return prices.map((_, i) => {
        const macd = macdLine[i];
        const signal = signalLine[i];
        const hist = macd !== null && signal !== null ? macd - signal : null;
        return { macd, signal, hist };
    });
};

export const calculateBollingerBandsForChart = (prices: number[], period = 20, stdDev = 2): { upper: number | null, middle: number | null, lower: number | null }[] => {
    const results: { upper: number | null, middle: number | null, lower: number | null }[] = [];
    for (let i = 0; i < prices.length; i++) {
        if (i < period - 1) {
            results.push({ upper: null, middle: null, lower: null });
            continue;
        }
        const slice = prices.slice(i - period + 1, i + 1);
        const middle = slice.reduce((a, b) => a + b, 0) / period;
        const sd = calculateStdDev(slice);
        results.push({
            middle,
            upper: middle + (sd * stdDev),
            lower: middle - (sd * stdDev),
        });
    }
    return results;
};

export const calculateRSIForChart = (prices: number[], period = 14): (number | null)[] => {
    if (prices.length <= period) return Array(prices.length).fill(null);

    const results: (number | null)[] = Array(period).fill(null);
    const changes = prices.slice(1).map((price, i) => price - prices[i]);

    let gain = 0;
    let loss = 0;

    for (let i = 0; i < period; i++) {
        if (changes[i] > 0) {
            gain += changes[i];
        } else {
            loss += Math.abs(changes[i]);
        }
    }

    let avgGain = gain / period;
    let avgLoss = loss / period;
    
    let rs = avgLoss === 0 ? Infinity : avgGain / avgLoss;
    results.push(100 - (100 / (1 + rs)));

    for (let i = period; i < changes.length; i++) {
        const change = changes[i];
        const currentGain = change > 0 ? change : 0;
        const currentLoss = change < 0 ? Math.abs(change) : 0;
        
        avgGain = (avgGain * (period - 1) + currentGain) / period;
        avgLoss = (avgLoss * (period - 1) + currentLoss) / period;

        rs = avgLoss === 0 ? Infinity : avgGain / avgLoss;
        results.push(100 - (100 / (1 + rs)));
    }

    return results;
};
