
import React from 'react';
import { Language, Translation } from '../types';
import { LogoIcon } from './Icons';

interface HeaderProps {
    language: Language;
    setLanguage: (lang: Language) => void;
    t: Translation;
}

export const Header: React.FC<HeaderProps> = ({ language, setLanguage, t }) => {
    return (
        <header className="glass-card sticky top-0 z-10 mx-2 my-2 md:mx-4 md:my-4">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex items-center justify-between h-16">
                    <div className="flex items-center space-x-3 rtl:space-x-reverse">
                        <LogoIcon className="h-8 w-8 text-brand-primary" />
                        <h1 className="text-xl font-bold text-brand-text-primary">{t.headerTitle}</h1>
                    </div>
                    <div className="flex items-center">
                        <button
                            onClick={() => setLanguage('en')}
                            className={`px-3 py-1 text-sm font-medium rounded-md ${language === 'en' ? 'bg-brand-primary text-white' : 'text-brand-text-secondary hover:bg-brand-border'}`}
                        >
                            EN
                        </button>
                        <button
                            onClick={() => setLanguage('ar')}
                            className={`px-3 py-1 text-sm font-medium rounded-md ${language === 'ar' ? 'bg-brand-primary text-white' : 'text-brand-text-secondary hover:bg-brand-border'}`}
                        >
                            AR
                        </button>
                    </div>
                </div>
            </div>
        </header>
    );
};