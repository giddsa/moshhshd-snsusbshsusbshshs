import React, { useCallback, useState } from 'react';
import { Kline, Translation, UploadedImage } from '../types';
import { UploadIcon, XCircleIcon, SearchIcon } from './Icons';

interface UploadPanelProps {
    onDataLoaded: (data: Kline[] | UploadedImage) => void;
    onClear: () => void;
    t: Translation;
    symbol: string | null;
    onSymbolChange: (symbol: string) => void;
}

export const UploadPanel: React.FC<UploadPanelProps> = ({ onDataLoaded, onClear, t, symbol, onSymbolChange }) => {
    const [mode, setMode] = useState<'file' | 'symbol'>('file');
    const [dragging, setDragging] = useState(false);
    const [imagePreview, setImagePreview] = useState<string | null>(null);

    const handleFile = useCallback((file: File) => {
        const isImage = file.type.startsWith('image/');
        
        if (isImage) {
            const reader = new FileReader();
            reader.onload = (e) => {
                const base64 = e.target?.result as string;
                setImagePreview(base64);
                onDataLoaded({
                    data: base64.split(',')[1],
                    mimeType: file.type
                });
            };
            reader.readAsDataURL(file);
        } else {
            const reader = new FileReader();
            reader.onload = (e) => {
                try {
                    const content = e.target?.result as string;
                    const lines = content.split('\n').filter(line => line.trim() !== '');
                    const start = lines[0].toLowerCase().includes('timestamp') ? 1 : 0;
                    const data: Kline[] = lines.slice(start).map(line => {
                        const parts = line.split(',');
                        return {
                            timestamp: parseInt(parts[0], 10),
                            open: parseFloat(parts[1]),
                            high: parseFloat(parts[2]),
                            low: parseFloat(parts[3]),
                            close: parseFloat(parts[4]),
                            volume: parseFloat(parts[5]),
                        };
                    });
                    setImagePreview(null);
                    onDataLoaded(data);
                } catch (error) {
                    alert('Failed to parse file. Please ensure it is a valid CSV with columns: timestamp,open,high,low,close,volume');
                }
            };
            reader.readAsText(file);
        }
    }, [onDataLoaded]);

    const handleDragEvents = (e: React.DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        e.stopPropagation();
        if (e.type === 'dragenter' || e.type === 'dragover') {
            setDragging(true);
        } else if (e.type === 'dragleave') {
            setDragging(false);
        }
    };
    
    const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        e.stopPropagation();
        setDragging(false);
        if (e.dataTransfer.files && e.dataTransfer.files[0]) {
            handleFile(e.dataTransfer.files[0]);
        }
    };

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            handleFile(e.target.files[0]);
        }
        e.target.value = ''; // Reset input to allow re-uploading the same file
    };

    const handleClearFile = () => {
        setImagePreview(null);
        onClear();
    };

    const handleSymbolInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const newSymbol = e.target.value.toUpperCase();
        if (newSymbol.trim()) {
            onSymbolChange(newSymbol.trim());
        } else {
            onClear();
        }
    };

    const handleModeChange = (newMode: 'file' | 'symbol') => {
        if (mode !== newMode) {
            setMode(newMode);
            onClear();
            setImagePreview(null);
        }
    };

    return (
        <div className="glass-card p-6">
            <div className="border-b border-brand-border mb-4">
                 <nav className="-mb-px flex space-x-4 rtl:space-x-reverse" aria-label="Tabs">
                    <button
                        onClick={() => handleModeChange('file')}
                        className={`${
                            mode === 'file'
                                ? 'border-brand-primary text-brand-primary'
                                : 'border-transparent text-brand-text-secondary hover:text-brand-text-primary hover:border-gray-500'
                        } whitespace-nowrap py-3 px-1 border-b-2 font-medium text-sm flex items-center gap-2`}
                    >
                         <UploadIcon className="w-5 h-5" />
                        {t.uploadFile}
                    </button>
                    <button
                        onClick={() => handleModeChange('symbol')}
                        className={`${
                            mode === 'symbol'
                                ? 'border-brand-primary text-brand-primary'
                                : 'border-transparent text-brand-text-secondary hover:text-brand-text-primary hover:border-gray-500'
                        } whitespace-nowrap py-3 px-1 border-b-2 font-medium text-sm flex items-center gap-2`}
                    >
                         <SearchIcon className="w-5 h-5" />
                        {t.analyzeBySymbol}
                    </button>
                 </nav>
            </div>

            {mode === 'file' && (
                <div>
                     <h2 className="text-xl font-bold mb-4">{t.uploadTitle}</h2>
                     {imagePreview ? (
                        <div className="relative">
                            <img src={imagePreview} alt="Chart preview" className="rounded-lg max-h-60 w-full object-contain" />
                            <button 
                                onClick={handleClearFile}
                                className="absolute top-2 right-2 rtl:right-auto rtl:left-2 bg-black/60 text-white rounded-full p-1 hover:bg-black/80 transition-colors"
                                aria-label={t.removeImage}
                            >
                                <XCircleIcon className="w-6 h-6" />
                            </button>
                        </div>
                    ) : (
                        <div
                            onDragEnter={handleDragEvents}
                            onDragLeave={handleDragEvents}
                            onDragOver={handleDragEvents}
                            onDrop={handleDrop}
                            className={`border-2 border-dashed ${dragging ? 'border-brand-primary' : 'border-brand-border'} rounded-lg p-8 text-center cursor-pointer transition-colors duration-300`}
                        >
                            <input type="file" id="file-upload" className="hidden" accept=".csv,.json,image/png,image/jpeg" onChange={handleInputChange} />
                            <label htmlFor="file-upload" className="cursor-pointer flex flex-col items-center">
                                <UploadIcon className="w-12 h-12 text-brand-text-secondary mb-4" />
                                <p className="text-brand-text-primary font-semibold">{t.uploadImage} {t.or} {t.uploadData}</p>
                                <p className="text-sm text-brand-text-secondary mt-1 text-center">{t.uploadInstructions}</p>
                            </label>
                        </div>
                    )}
                </div>
            )}
            
            {mode === 'symbol' && (
                <div>
                    <h2 className="text-xl font-bold mb-4">{t.analyzeBySymbol}</h2>
                    <div className="space-y-2">
                        <label htmlFor="symbol-input" className="block text-sm font-medium text-brand-text-secondary">{t.enterSymbol}</label>
                        <input
                            type="text"
                            id="symbol-input"
                            value={symbol || ''}
                            onChange={handleSymbolInputChange}
                            placeholder={t.symbolPlaceholder}
                            className="w-full bg-brand-surface border border-brand-border rounded-lg p-2.5 focus:ring-2 focus:ring-brand-primary focus:outline-none text-sm"
                        />
                    </div>
                </div>
            )}
        </div>
    );
};