import React, { useState, useCallback, useMemo, useEffect } from 'react';
import { Header } from './components/Header';
import { UploadPanel } from './components/UploadPanel';
import { SettingsPanel } from './components/SettingsPanel';
import { ResultsPanel } from './components/ResultsPanel';
import { Footer } from './components/Footer';
import { ChatPanel } from './components/ChatPanel';
import { AiTraderPanel } from './components/AiTraderPanel';
import { CryptoNewsPanel } from './components/CryptoNewsPanel';
import { HistoryPanel } from './components/HistoryPanel';
import { LoadingSpinner, ErrorIcon, AnalyzerIcon, ChatBubbleIcon, BoltIcon, NewspaperIcon, HistoryIcon } from './components/Icons';
import { AnalysisResult, Kline, Language, UploadedImage, TradingType, User, SavedSignal } from './types';
import { translations } from './constants';
import { processAnalysis } from './services/analysisService';
import { generateAnalysisExplanation, analyzeChartImage, getQuantumAnalysis } from './services/geminiService';
import { fetchHistoricalKlines, ApiError } from './services/backtestService';
import { loginUser, logoutUser, getSignalHistory, saveSignal, getCurrentUser } from './services/authService';

type ActiveTab = 'analyzer' | 'ai-trader' | 'chat' | 'news' | 'history';

const App: React.FC = () => {
    // Default language set to Arabic
    const [language, setLanguage] = useState<Language>('ar');
    const [activeTab, setActiveTab] = useState<ActiveTab>('analyzer');
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);
    const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
    const [leverage, setLeverage] = useState<number>(10);
    const [tradingType, setTradingType] = useState<TradingType>('futures');
    const [klineData, setKlineData] = useState<Kline[] | null>(null);
    const [uploadedImage, setUploadedImage] = useState<UploadedImage | null>(null);
    const [symbol, setSymbol] = useState<string | null>(null);
    const [analysisSource, setAnalysisSource] = useState<'file' | 'symbol' | null>(null);

    // Auth & History State
    const [user, setUser] = useState<User | null>(null);
    const [history, setHistory] = useState<SavedSignal[]>([]);

    const t = useMemo(() => translations[language], [language]);

    // Check for logged in user on mount
    useEffect(() => {
        const storedUser = getCurrentUser();
        if (storedUser) {
            setUser(storedUser);
            setHistory(getSignalHistory());
        }
    }, []);

    const handleLogin = async () => {
        try {
            const loggedInUser = await loginUser();
            setUser(loggedInUser);
            setHistory(getSignalHistory());
        } catch (e) {
            console.error("Login failed", e);
        }
    };

    const handleLogout = async () => {
        await logoutUser();
        setUser(null);
        setHistory([]);
    };

    const handleSaveSignal = useCallback(() => {
        if (!user || !analysisResult) return;
        
        const signalToSave: SavedSignal = {
            ...analysisResult,
            id: `sig_${Date.now()}`,
            timestamp: Date.now(),
            status: 'Pending',
        };
        
        const updatedHistory = saveSignal(signalToSave);
        setHistory(updatedHistory);
    }, [user, analysisResult]);

    const handleAnalyze = useCallback(async () => {
        if (!klineData && !uploadedImage && !symbol) {
            setError(t.errorNoData);
            return;
        }

        setIsLoading(true);
        setError(null);
        setAnalysisResult(null);

        const finalLeverage = tradingType === 'spot' ? 1 : leverage;

        try {
            let finalResult: AnalysisResult = {};

            if (symbol) {
                setAnalysisSource('symbol');
                const fetchedKlines = await fetchHistoricalKlines(symbol, '1h');
                 if (fetchedKlines.length < 100) { 
                    throw new Error("Could not fetch enough historical data for a quantum analysis.");
                }
                setKlineData(fetchedKlines);
                
                const quantumResult = await getQuantumAnalysis(fetchedKlines, symbol, language);

                finalResult = {
                    ...quantumResult,
                    symbol: symbol.toUpperCase(),
                };

            } else if (uploadedImage) {
                setAnalysisSource('file');
                finalResult = await analyzeChartImage(uploadedImage, finalLeverage, language, tradingType);
            } else if (klineData) {
                setAnalysisSource('file');
                const numericalAnalysis = processAnalysis(klineData, finalLeverage, tradingType);
                const geminiExplanation = await generateAnalysisExplanation(numericalAnalysis, language);
                finalResult = {
                    ...numericalAnalysis,
                    ...geminiExplanation
                };
            } else {
                throw new Error("No data available to analyze.");
            }
            
            setAnalysisResult(finalResult);

        } catch (err) {
            console.error(err);
             if (err instanceof ApiError) {
                const errorMessage = t.errorUnsupportedSymbol
                    .replace('{symbol}', symbol || '');
                setError(errorMessage);
            } else {
                const errorMessage = (err instanceof Error) ? err.message : t.errorAnalysisFailed;
                if (errorMessage.includes('API key not valid')) {
                     setError(t.errorApiKey);
                } else if (symbol) {
                     setError(errorMessage);
                } else if (uploadedImage) {
                    setError(t.errorVisionAnalysisFailed);
                }
                else {
                     setError(errorMessage);
                }
            }
        } finally {
            setIsLoading(false);
        }
    }, [klineData, uploadedImage, symbol, leverage, tradingType, language, t]);

    const handleDataLoaded = useCallback((data: Kline[] | UploadedImage) => {
        setError(null);
        setAnalysisResult(null);
        setSymbol(null);
        setKlineData(null);
        setUploadedImage(null);
        if (Array.isArray(data)) {
            setKlineData(data);
        } else {
            setUploadedImage(data);
        }
    }, []);

    const handleSymbolChange = useCallback((newSymbol: string) => {
        setError(null);
        setAnalysisResult(null);
        setKlineData(null);
        setUploadedImage(null);
        setSymbol(newSymbol);
    }, []);

    const handleClear = useCallback(() => {
        setKlineData(null);
        setUploadedImage(null);
        setAnalysisResult(null);
        setError(null);
        setSymbol(null);
        setAnalysisSource(null);
    }, []);

    const renderContent = () => {
        switch (activeTab) {
            case 'analyzer':
                return (
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                        <div className="lg:col-span-1 flex flex-col gap-6">
                            <UploadPanel onDataLoaded={handleDataLoaded} onClear={handleClear} t={t} symbol={symbol} onSymbolChange={handleSymbolChange}/>
                            <SettingsPanel 
                                leverage={leverage} 
                                setLeverage={setLeverage}
                                tradingType={tradingType}
                                setTradingType={setTradingType} 
                                t={t} 
                            />
                            <button
                                onClick={handleAnalyze}
                                disabled={isLoading || (!klineData && !uploadedImage && !symbol)}
                                className="w-full main-button bg-brand-primary hover:bg-brand-secondary text-white font-bold py-4 px-6 rounded-lg transition duration-300 disabled:bg-gray-700 disabled:cursor-not-allowed flex items-center justify-center text-lg shadow-lg"
                            >
                                {isLoading ? <LoadingSpinner className="h-6 w-6 -ml-1 mr-3"/> : <BoltIcon className="h-6 w-6 me-2 rtl:ms-2" />}
                                {isLoading ? t.analyzing : t.analyzeNow}
                            </button>
                        </div>
                        <div className="lg:col-span-2">
                             <ResultsPanel 
                                result={analysisResult} 
                                isLoading={isLoading} 
                                t={t} 
                                analysisSource={analysisSource}
                                language={language}
                                klineData={klineData}
                                user={user}
                                onSaveSignal={handleSaveSignal}
                             />
                        </div>
                    </div>
                );
            case 'ai-trader':
                return <AiTraderPanel t={t} language={language} />;
            case 'chat':
                return <ChatPanel t={t} language={language} />;
            case 'news':
                return <CryptoNewsPanel t={t} language={language} />;
            case 'history':
                return user ? (
                    <HistoryPanel 
                        history={history} 
                        setHistory={setHistory} 
                        t={t} 
                        language={language} 
                    />
                ) : (
                    <div className="glass-card p-8 flex flex-col items-center justify-center text-center">
                        <HistoryIcon className="w-16 h-16 text-brand-border mb-4" />
                        <h2 className="text-2xl font-bold mb-2">{t.loginRequired}</h2>
                        <p className="text-brand-text-secondary mb-6">{t.loginRequiredDesc}</p>
                        <button
                            onClick={handleLogin}
                            className="main-button bg-brand-primary hover:bg-brand-secondary text-white font-bold py-3 px-8 rounded-full"
                        >
                            {t.loginWithGoogle}
                        </button>
                    </div>
                );
            default:
                return null;
        }
    };

    return (
        <div className={`min-h-screen bg-brand-bg text-brand-text-primary font-sans ${language === 'ar' ? 'font-arabic' : ''}`} dir={language === 'ar' ? 'rtl' : 'ltr'}>
            <Header 
                language={language} 
                setLanguage={setLanguage} 
                t={t} 
                user={user} 
                onLogin={handleLogin} 
                onLogout={handleLogout} 
            />
            
            <main className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
                {/* Mobile Tab Navigation */}
                <div className="md:hidden mb-6 overflow-x-auto pb-2 scrollbar-hide">
                    <div className="flex space-x-2 rtl:space-x-reverse min-w-max">
                        <button
                            onClick={() => setActiveTab('analyzer')}
                            className={`px-4 py-2 rounded-full text-sm font-medium transition-colors whitespace-nowrap ${activeTab === 'analyzer' ? 'bg-brand-primary text-white' : 'bg-brand-surface text-brand-text-secondary'}`}
                        >
                            <AnalyzerIcon className="w-4 h-4 inline-block me-1 rtl:ms-1 mb-0.5" />
                            {t.analyzerTab}
                        </button>
                        <button
                            onClick={() => setActiveTab('ai-trader')}
                            className={`px-4 py-2 rounded-full text-sm font-medium transition-colors whitespace-nowrap ${activeTab === 'ai-trader' ? 'bg-brand-primary text-white' : 'bg-brand-surface text-brand-text-secondary'}`}
                        >
                             <BoltIcon className="w-4 h-4 inline-block me-1 rtl:ms-1 mb-0.5" />
                            {t.aiAssistant}
                        </button>
                         <button
                            onClick={() => setActiveTab('news')}
                            className={`px-4 py-2 rounded-full text-sm font-medium transition-colors whitespace-nowrap ${activeTab === 'news' ? 'bg-brand-primary text-white' : 'bg-brand-surface text-brand-text-secondary'}`}
                        >
                             <NewspaperIcon className="w-4 h-4 inline-block me-1 rtl:ms-1 mb-0.5" />
                            {t.newsTab}
                        </button>
                        <button
                            onClick={() => setActiveTab('chat')}
                            className={`px-4 py-2 rounded-full text-sm font-medium transition-colors whitespace-nowrap ${activeTab === 'chat' ? 'bg-brand-primary text-white' : 'bg-brand-surface text-brand-text-secondary'}`}
                        >
                             <ChatBubbleIcon className="w-4 h-4 inline-block me-1 rtl:ms-1 mb-0.5" />
                            {t.chatTab}
                        </button>
                        <button
                            onClick={() => setActiveTab('history')}
                            className={`px-4 py-2 rounded-full text-sm font-medium transition-colors whitespace-nowrap ${activeTab === 'history' ? 'bg-brand-primary text-white' : 'bg-brand-surface text-brand-text-secondary'}`}
                        >
                             <HistoryIcon className="w-4 h-4 inline-block me-1 rtl:ms-1 mb-0.5" />
                            {t.historyTab}
                        </button>
                    </div>
                </div>

                 {/* Desktop Tab Navigation */}
                <div className="hidden md:flex justify-center mb-8">
                    <div className="bg-brand-surface p-1 rounded-xl inline-flex shadow-lg border border-brand-border">
                        <button
                            onClick={() => setActiveTab('analyzer')}
                            className={`px-6 py-2.5 rounded-lg text-sm font-bold transition-all duration-300 flex items-center gap-2 ${activeTab === 'analyzer' ? 'bg-brand-primary text-white shadow-md' : 'text-brand-text-secondary hover:text-white'}`}
                        >
                            <AnalyzerIcon className="w-5 h-5" />
                            {t.analyzerTab}
                        </button>
                         <button
                            onClick={() => setActiveTab('ai-trader')}
                            className={`px-6 py-2.5 rounded-lg text-sm font-bold transition-all duration-300 flex items-center gap-2 ${activeTab === 'ai-trader' ? 'bg-brand-primary text-white shadow-md' : 'text-brand-text-secondary hover:text-white'}`}
                        >
                             <BoltIcon className="w-5 h-5" />
                            {t.aiAssistant}
                        </button>
                        <button
                            onClick={() => setActiveTab('news')}
                            className={`px-6 py-2.5 rounded-lg text-sm font-bold transition-all duration-300 flex items-center gap-2 ${activeTab === 'news' ? 'bg-brand-primary text-white shadow-md' : 'text-brand-text-secondary hover:text-white'}`}
                        >
                            <NewspaperIcon className="w-5 h-5" />
                            {t.newsTab}
                        </button>
                         <button
                            onClick={() => setActiveTab('chat')}
                            className={`px-6 py-2.5 rounded-lg text-sm font-bold transition-all duration-300 flex items-center gap-2 ${activeTab === 'chat' ? 'bg-brand-primary text-white shadow-md' : 'text-brand-text-secondary hover:text-white'}`}
                        >
                            <ChatBubbleIcon className="w-5 h-5" />
                            {t.chatTab}
                        </button>
                        <button
                            onClick={() => setActiveTab('history')}
                            className={`px-6 py-2.5 rounded-lg text-sm font-bold transition-all duration-300 flex items-center gap-2 ${activeTab === 'history' ? 'bg-brand-primary text-white shadow-md' : 'text-brand-text-secondary hover:text-white'}`}
                        >
                            <HistoryIcon className="w-5 h-5" />
                            {t.historyTab}
                        </button>
                    </div>
                </div>

                {error && activeTab === 'analyzer' && !symbol && !uploadedImage && !klineData && (
                     <div className="mb-6 bg-red-900/50 border border-brand-danger text-red-300 px-4 py-3 rounded-lg flex items-center shadow-lg animate-fade-in" role="alert">
                        <ErrorIcon className="h-6 w-6 me-3 rtl:ms-3"/>
                        <span className="font-medium">{error}</span>
                    </div>
                )}

                {renderContent()}
            </main>
            <Footer t={t} />
        </div>
    );
};

export default App;