import { GoogleGenAI, Type, Chat, FunctionDeclaration, FunctionCall, GenerateContentResponse } from "@google/genai";
import { NumericalAnalysisResult, GeminiAnalysisResult, Language, UploadedImage, AnalysisResult, ChatMessage, TradingType, Kline } from '../types';
import { fetchHistoricalKlines } from './backtestService';
import { calculateEMA, calculateRSI, calculateMACD } from './analysisService';

const analysts = {
    crypto: "Anthony Pompliano, Ben Cowen, Ari Paul, Willy Woo, Michael van de Poppe, PlanB, Alessio Rastani, Raoul Pal, Mark Moss, Crypto Rover",
    forex: "Peter Brandt, Kathy Lien, Rayner Teo, John Bollinger, Steve Burns, Linda Raschke, Paul Tudor Jones, Akil Stokes, Adam Khoo, Mitchell Choi",
    futures: "Jim Rogers, Linda Bradford Raschke, Tom Sosnoff, Dan Zanger, Joe Ross, Mark Douglas, Jack Schwager, Rob Hoffman, Tim Grittani, SMB Capital",
    general: "Warren Buffett, Ray Dalio, Peter Lynch, George Soros, Mark Minervini, Michael Burry, Cathie Wood, Robert Kiyosaki, Naval Ravikant, Jesse Livermore"
};

const getSystemInstruction = (language: Language) => {
    if (language === 'ar') {
        return `أنت "المحلل الذكي"، وهو ذكاء اصطناعي فائق لتحليل الأسواق. تم تدريبك على استيعاب وتجميع استراتيجيات وفلسفات أعظم المتداولين والمحللين في العالم. مهمتك الأساسية هي تحديد أفضل فرصة تداول مربحة محتملة ضمن البيانات المقدمة باتباع مجموعة قواعد صارمة وغير قابلة للتفاوض. هدفك هو الجودة، لا الكمية. لا تقدم نصيحة مالية مباشرة، بل قدم تحليلاً فنياً احترافياً لا مثيل له.`;
    }
    return `You are 'The Smart Analyst', a paramount AI market analysis entity. Your analytical core is a synthesis of the strategies and philosophies of the world's greatest traders and analysts. Your primary mission is to identify the most probable profitable trade setup within the provided data by following a strict, non-negotiable set of rules. Your goal is quality, not quantity. You do not give direct financial advice, but provide unparalleled, professional technical analysis.`;
};


const getSatoSystemInstruction = (language: Language) => {
    if (language === 'ar') {
        return "أنت 'سطو'، مساعد ذكاء اصطناعي خبير في تداول العملات الرقمية. أنا من صنع المطور 'سطو'. إذا سُئلت عن من صنعك، فاذكر 'سطو' وقدم رابط حسابه على انستقرام: https://www.instagram.com/2k__.p . مهمتك هي الإجابة على أسئلة المستخدم المتعلقة بالتداول وأسعار العملات فقط. إذا طُلب منك سعر عملة، استخدم الأداة المتاحة لك. كن ودودًا ومحترفًا. إذا سُئلت عن أي موضوع آخر، أجب بلطف بأنك متخصص في التداول فقط.";
    }
    return "You are 'Sato', an expert AI assistant specializing in cryptocurrency trading. I was created by the developer 'Sato'. If asked who made you, mention 'Sato' and provide his Instagram link: https://www.instagram.com/2k__.p . Your job is to answer user questions about trading and crypto prices. If asked for a price, use the function provided to you. Be friendly and professional. If asked about any other topic, politely state that you only specialize in trading.";
}

// Mock function to simulate fetching crypto price
const getCurrentCryptoPrice = (symbol: string): number => {
    // In a real application, you would call a crypto API (e.g., Binance, CoinGecko)
    // For this example, we'll generate a realistic-looking random price.
    console.log(`Fetching price for ${symbol}...`);
    const basePrice = symbol.toLowerCase().includes('btc') ? 65000 : (symbol.toLowerCase().includes('eth') ? 3500 : 150);
    const randomFactor = (Math.random() - 0.5) * 0.1; // +/- 5%
    return basePrice * (1 + randomFactor);
};

const tools: FunctionDeclaration[] = [
    {
      name: 'getCurrentCryptoPrice',
      parameters: {
        type: Type.OBJECT,
        description: 'Get the current price for a specific cryptocurrency symbol.',
        properties: {
          symbol: {
            type: Type.STRING,
            description: 'The symbol of the cryptocurrency, e.g., "BTCUSDT", "ETHUSDT".',
          },
        },
        required: ['symbol'],
      },
    }
];

// FIX: Add missing generateAnalysisExplanation function to resolve import error.
const explanationSchema = {
    type: Type.OBJECT,
    properties: {
        analysis_summary: { type: Type.STRING, description: 'A single, concise sentence in the specified language summarizing the trade idea.' },
        analysis_explanation: { type: Type.STRING, description: 'A detailed paragraph in the specified language explaining the reasoning behind the recommendation.' },
    },
    required: ['analysis_summary', 'analysis_explanation']
};

export const generateAnalysisExplanation = async (
    numericalAnalysis: NumericalAnalysisResult,
    language: Language
): Promise<GeminiAnalysisResult> => {
    if (!process.env.API_KEY) {
        throw new Error("API key for Gemini is not configured.");
    }
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

    const prompt = `As 'The Super Analyst', your mind a collective of trading legends, you have been presented with a pre-computed numerical analysis of a financial chart. Your task is to interpret this data and articulate a masterful, professional-grade analysis and trade thesis.

**Provided Numerical Analysis:**
\`\`\`json
${JSON.stringify(numericalAnalysis, null, 2)}
\`\`\`

**Your Mission:**
1.  **Synthesize the Data**: Do not just repeat the numbers. Interpret what the combination of these indicators (\`RSI\`, \`MACD\`, \`EMAs\`) and the proposed trade setup (\`possible_position\`, \`entry\`, \`SL\`, \`TP\`) implies about the market's state and future direction.
2.  **Formulate the Thesis (Language: ${language === 'ar' ? 'Arabic' : 'English'})**:
    *   \`analysis_summary\`: A single, powerful sentence that encapsulates your core thesis for the trade. This should be a direct and confident statement.
    *   \`analysis_explanation\`: A masterful, detailed paragraph. Start with your main conclusion (e.g., "A compelling long opportunity is materializing..."). Then, walk through your interpretation of the data, explaining how the indicators and trend analysis build an undeniable case for your recommendation. Your tone must be that of an ultimate authority on the markets.
3.  **Adhere to Context**:
    *   The analysis suggests a \`${numericalAnalysis.possible_position}\` position with a confidence of \`${(numericalAnalysis.confidence * 100).toFixed(0)}%\`. Your explanation must align with and justify this conclusion.
    *   If the position is 'Stay Out', explain why the data suggests conflicting signals or a lack of a high-probability setup, justifying a neutral stance.

**Output Mandate**: You MUST return your complete analysis as a single JSON object that strictly adheres to the provided schema. There must be no other text or explanation outside of this JSON object.`;

    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                systemInstruction: getSystemInstruction(language),
                responseMimeType: 'application/json',
                responseSchema: explanationSchema,
            }
        });

        const jsonText = response.text.trim();
        const result: GeminiAnalysisResult = JSON.parse(jsonText);
        return result;

    } catch (error) {
        console.error("Error calling Gemini API for analysis explanation:", error);
        throw new Error("Failed to generate analysis explanation from AI.");
    }
};

export const getQuantumAnalysis = async (
    klines: Kline[],
    symbol: string,
    language: Language,
): Promise<AnalysisResult> => {
    if (!process.env.API_KEY) {
        throw new Error("API key for Gemini is not configured.");
    }
    if (klines.length < 100) { // Need enough data for context
        throw new Error("Not enough historical data for a quantum analysis. At least 100 candles are needed.");
    }

    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const recentKlinesForPrompt = klines.slice(-100).map(k => ({ t: k.timestamp, o: k.open, h: k.high, l: k.low, c: k.close, v: k.volume }));

    const quantumAnalysisSchema = {
        type: Type.OBJECT,
        properties: {
            analysis_summary: { type: Type.STRING, description: 'The final verdict. A confident, detailed paragraph summarizing the trade thesis based on all combined factors. This MUST be in the target language.' },
            market_sentiment_score: { type: Type.NUMBER, description: 'A score from 0 (Extreme Fear) to 100 (Extreme Greed) representing the current market sentiment.' },
            
            // NEW: Whale & Smart Money Radar
            whale_activity: {
                type: Type.OBJECT,
                properties: {
                    score: { type: Type.NUMBER, description: 'A score from 0 to 100 indicating intensity of institutional activity (volume anomalies).' },
                    action: { type: Type.STRING, enum: ['Accumulation', 'Distribution', 'Dormant'], description: 'What are the whales doing?' },
                    warning: { type: Type.STRING, description: 'Optional warning for manipulation patterns like Stop Hunt, Pump & Dump, or "None".' }
                },
                required: ['score', 'action']
            },

            key_support: { type: Type.NUMBER, description: 'The most critical immediate support level.' },
            key_resistance: { type: Type.NUMBER, description: 'The most critical immediate resistance level.' },
            point_of_control: { type: Type.NUMBER, description: 'The price level with the highest trading volume (Point of Control).' },
            liquidity_analysis: { type: Type.STRING, description: 'Analysis of where major liquidity pools are located (e.g., above recent highs, below recent lows). This MUST be in the target language.' },
            bullish_case: { type: Type.STRING, description: 'A paragraph detailing the arguments for a bullish move. This MUST be in the target language.' },
            bearish_case: { type: Type.STRING, description: 'A paragraph detailing the arguments for a bearish move. This MUST be in the target language.' },
            market_structure: { type: Type.STRING, enum: ['Bullish', 'Bearish'] },
            market_structure_reason: { type: Type.STRING, enum: ['BOS', 'CHoCH'] },
            order_block: {
                type: Type.OBJECT,
                properties: {
                    type: { type: Type.STRING, enum: ['Bullish', 'Bearish'] },
                    start_price: { type: Type.NUMBER },
                    end_price: { type: Type.NUMBER },
                },
            },
            fair_value_gap: {
                type: Type.OBJECT,
                properties: {
                    start_price: { type: Type.NUMBER },
                    end_price: { type: Type.NUMBER },
                },
            },
            // Trade Plan
            possible_position: { type: Type.STRING, enum: ['Long', 'Short', 'Stay Out'] },
            recommended_timeframe: { type: Type.STRING, description: 'The most suitable timeframe for this analysis (e.g., 1h, 4h).' },
            possible_entry: { type: Type.NUMBER, description: 'A precise, recommended entry price based on a re-test or key level, not market price.' },
            take_profit: { type: Type.NUMBER, description: 'The primary take-profit target.' },
            tp1: { type: Type.NUMBER, description: 'The first take-profit target.' },
            tp2: { type: Type.NUMBER, description: 'The second take-profit target.' },
            tp3: { type: Type.NUMBER, description: 'The third take-profit target.' },
            stop_loss: { type: Type.NUMBER, description: 'A precise stop-loss level placed logically *below* a key support (for longs) or *above* a key resistance (for shorts).' },
            rr_ratio: { type: Type.NUMBER, description: 'Calculated risk-reward ratio to the first take profit (tp1).' },
            confidence: { type: Type.NUMBER, description: 'A confidence score between 0.0 and 1.0 for the trade setup.' },
        },
        required: [
            'analysis_summary', 'market_sentiment_score', 'whale_activity', 'key_support', 'key_resistance',
            'liquidity_analysis', 'bullish_case', 'bearish_case', 'market_structure',
            'possible_position', 'recommended_timeframe', 'possible_entry', 'take_profit', 'stop_loss',
            'rr_ratio', 'confidence'
        ]
    };

    const prompt = `
You are 'The Smart Analyst', a paramount AI market analysis entity. Your analytical core is a synthesis of the strategies of legends like Jesse Livermore, Paul Tudor Jones, and modern Smart Money Concepts (SMC) experts. Your task is to perform a deep, multi-faceted "Quantum Analysis" of the provided market data and generate a high-probability trade setup.

**Language for response text (summaries, cases, etc.): ${language === 'ar' ? 'Arabic' : 'English'}**

**Core Directives (Non-Negotiable):**
1.  **NO MARKET ORDERS:** You are forbidden from suggesting "immediate market entry". All entry points must be based on a re-test of a key level (Order Block, FVG, Support/Resistance).
2.  **STRATEGIC STOP LOSS:** The Stop Loss must NOT be placed directly on a support/resistance line. It must be placed logically beyond it (e.g., below the low of a bullish order block) to avoid stop hunts.
3.  **QUALITY OVER QUANTITY:** Only generate a 'Long' or 'Short' trade if a high-probability setup with a Risk/Reward ratio of at least 1.5 exists. Otherwise, recommend 'Stay Out'.
4.  **WHALE RADAR:** You must analyze Volume Spread Analysis (VSA) to detect anomalies. High volume with small price movement = hidden accumulation/distribution. Stop runs (wicks) = manipulation.

**Quantum Analysis Protocol:**
Analyze the provided recent price action data and generate a complete picture of the market.
1.  **Sentiment Analysis:** Determine the overall market sentiment and provide a score from 0-100.
2.  **Whale & Manipulation Analysis:**
    *   Identify signs of "Smart Money" activity (Whales).
    *   Determine if they are likely Accumulating, Distributing, or Dormant.
    *   Look for manipulation patterns (Stop Hunts, Bull/Bear Traps).
3.  **Structural Analysis (SMC):**
    *   Identify the current \`market_structure\` (Bullish/Bearish).
    *   Pinpoint the key event causing it (\`BOS\` or \`CHoCH\`).
    *   Locate critical structural levels: \`key_support\`, \`key_resistance\`, \`point_of_control\`.
    *   Identify key SMC zones if present: \`order_block\`, \`fair_value_gap\`.
4.  **Liquidity Mapping:** Describe where significant \`liquidity_analysis\` pools likely reside.
5.  **The Verdict & Trade Plan:**
    *   Synthesize all data into a \`analysis_summary\` (final verdict).
    *   Based on your verdict and core directives, construct a complete trade plan (\`possible_position\`, \`recommended_timeframe\`, \`possible_entry\`, \`stop_loss\`, multiple take profit targets \`tp1\`, \`tp2\`, \`tp3\`, and a primary \`take_profit\` which should be same as \`tp1\`). Calculate the \`rr_ratio\` based on the entry, SL, and \`tp1\`.
    *   Provide a final \`confidence\` score.

**Recent Price Action (last 100 candles):**
\`\`\`json
${JSON.stringify(recentKlinesForPrompt, null, 2)}
\`\`\`

**Output Mandate: Respond ONLY with a single JSON object adhering to the schema. No other text.**
`;

    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash", 
            contents: prompt,
            config: {
                systemInstruction: getSystemInstruction(language),
                responseMimeType: 'application/json',
                responseSchema: quantumAnalysisSchema,
            }
        });
        const jsonText = response.text.trim();
        const geminiResult: AnalysisResult = JSON.parse(jsonText);

        // Ensure symbol is included
        geminiResult.symbol = symbol;

        return geminiResult;

    } catch (error) {
        console.error("Error calling Gemini API for quantum analysis:", error);
        throw new Error("Failed to get quantum analysis from AI.");
    }
};


const fullAnalysisSchema = {
    type: Type.OBJECT,
    properties: {
        symbol: { type: Type.STRING, description: 'The symbol of the crypto asset, e.g., BTCUSDT. If not visible, state "Unknown".' },
        timeframe: { type: Type.STRING, description: 'The chart timeframe, e.g., 4h, 1D. If not visible, state "Unknown".' },
        analysis_summary: { type: Type.STRING, description: 'A single, concise sentence in the specified language summarizing the trade idea.' },
        possible_position: { type: Type.STRING, enum: ['Long', 'Short', 'Stay Out'] },
        trend_direction: { type: Type.STRING, enum: ['Uptrend', 'Downtrend', 'Sideways'] },
        possible_entry: { type: Type.NUMBER, description: 'A realistic entry price near the current price.' },
        take_profit: { type: Type.NUMBER, description: 'A logical take-profit price.' },
        stop_loss: { type: Type.NUMBER, description: 'A logical stop-loss price.' },
        rr_ratio: { type: Type.NUMBER, description: 'The calculated risk/reward ratio.' },
        confidence: { type: Type.NUMBER, description: 'A confidence score between 0.0 and 1.0 for the trade setup.' },
        analysis_explanation: { type: Type.STRING, description: 'A detailed paragraph in the specified language explaining the reasoning behind the recommendation.' },
        indicators: {
            type: Type.OBJECT,
            description: "Estimated values of visible indicators. Provide a numerical estimate for all fields.",
            properties: {
                rsi: { type: Type.NUMBER },
                macd: { type: Type.OBJECT, properties: { macd: {type: Type.NUMBER}, signal: {type: Type.NUMBER}, hist: {type: Type.NUMBER} } },
                atr: { type: Type.NUMBER },
                ema: { type: Type.OBJECT, properties: { '9': {type: Type.NUMBER}, '21': {type: Type.NUMBER}, '50': {type: Type.NUMBER} } },
                bollinger: { type: Type.OBJECT, properties: { upper: {type: Type.NUMBER}, middle: {type: Type.NUMBER}, lower: {type: Type.NUMBER} } },
            }
        }
    },
    required: [
        'symbol', 'timeframe', 'analysis_summary', 'possible_position', 'trend_direction',
        'possible_entry', 'take_profit', 'stop_loss', 'rr_ratio', 'confidence',
        'analysis_explanation', 'indicators'
    ]
};


export const analyzeChartImage = async (
    image: UploadedImage,
    leverage: number,
    language: Language,
    tradingType: TradingType,
): Promise<AnalysisResult> => {
     if (!process.env.API_KEY) {
        throw new Error("API key for Gemini is not configured.");
    }
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    const imagePart = {
        inlineData: {
            mimeType: image.mimeType,
            data: image.data,
        },
    };

    const textPrompt = `As 'The Super Analyst', your task is to conduct a masterful analysis of the attached chart image. Your mind is a collective of trading legends. Your goal is to find an actionable trade.

**Context & Rules:**
1.  **User Settings**: The user is trading '${tradingType}' with ${leverage}x leverage.
2.  **CRITICAL SPOT TRADING RULE**: If \`tradingType\` is 'spot', you are FORBIDDEN from recommending a 'Short' position. If the chart is bearish, you MUST recommend 'Stay Out' and explain that shorting is impossible in spot markets. This is a non-negotiable directive.

**Opportunity Hunter's Protocol:**
1.  **Identify Canvas (Willy Woo)**: First, identify the asset symbol and timeframe from the chart. State 'Unknown' if not visible.
2.  **Market Structure (Peter Brandt, Jesse Livermore)**: Analyze the macro and micro trends. Is the market in a clear uptrend, downtrend, or range-bound? Identify key support and resistance levels, breaks of structure (BOS), or changes of character (CHoCH).
3.  **Indicator Confluence (John Bollinger, Rayner Teo)**: Visually identify and interpret the state of key indicators (RSI, MACD, EMAs, Bollinger Bands, etc.). Do not just state their values; explain what their convergence or divergence implies. You MUST provide numerical estimates for all indicator fields in the schema, even if it's a rough estimation (e.g., 0 if not visible).
4.  **Risk Management (Paul Tudor Jones)**: Based on the structure and volatility (e.g., ATR if visible), define a precise and logical trade plan.
    *   \`possible_entry\`: A strategic entry point, not just the current price.
    *   \`stop_loss\`: A tight stop-loss placed at a point that would invalidate your entire thesis.
    *   \`take_profit\`: A realistic target based on key resistance/support levels, ensuring a strong risk/reward ratio (aim for 2.0 or higher if possible).
5.  **Formulate the Trade**: Synthesize all evidence to find the most advantageous trade setup. Actively hunt for a Long or Short opportunity. Only recommend 'Stay Out' as a last resort if the market is exceptionally chaotic or presents no discernible edge.
6.  **Articulate the Thesis (Language: ${language === 'ar' ? 'Arabic' : 'English'})**:
    *   \`analysis_summary\`: A single, powerful sentence that encapsulates your core thesis for the trade.
    *   \`analysis_explanation\`: A masterful, detailed paragraph. Start with your main conclusion. Then, walk through your multi-layered analysis (market structure, indicators, etc.) to build an undeniable case for your recommendation. Your tone must be that of an ultimate authority on the markets.

**Output Mandate**: You MUST return your complete analysis as a single JSON object that strictly adheres to the provided schema. There must be no other text or explanation outside of this JSON object.`;

    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: { parts: [imagePart, { text: textPrompt }] },
            config: {
                systemInstruction: getSystemInstruction(language),
                responseMimeType: 'application/json',
                responseSchema: fullAnalysisSchema,
            }
        });
        
        const jsonText = response.text.trim();
        const result: AnalysisResult = JSON.parse(jsonText);
        
        // Final check to enforce the spot trading rule, in case the model makes a mistake.
        if (tradingType === 'spot' && result.possible_position === 'Short') {
            result.possible_position = 'Stay Out';
            result.analysis_summary = language === 'ar' 
                ? 'لا توجد فرصة شراء واضحة؛ البيع غير متاح في السبوت.' 
                : 'No clear long opportunity; shorting is not available in spot.';
        }

        return result;

    } catch (error) {
        console.error("Error calling Gemini Vision API:", error);
        throw new Error("Failed to get analysis from AI. The model may not have been able to interpret the image.");
    }
};

export const handleSatoChat = async (
    history: ChatMessage[],
    newMessage: string,
    language: Language,
    onFunctionCall: (message: string) => void,
): Promise<string> => {
     if (!process.env.API_KEY) {
        throw new Error("API key for Gemini is not configured.");
    }
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    const chat: Chat = ai.chats.create({
        model: 'gemini-2.5-flash',
        config: {
            systemInstruction: getSatoSystemInstruction(language),
            tools: [{functionDeclarations: tools}],
        },
        history: history,
    });

    try {
        let response: GenerateContentResponse = await chat.sendMessage({ message: newMessage });
        
        const functionCalls = response.functionCalls;
        
        if (functionCalls && functionCalls.length > 0) {
            onFunctionCall('satoFetchingPrice');
            const call = functionCalls[0];
            let result;
            if (call.name === 'getCurrentCryptoPrice') {
                const price = getCurrentCryptoPrice(call.args.symbol);
                result = { price: price };
            }

            // Send the result back to the model
            response = await chat.sendMessage({
                message: '',
                tool_responses: [{
                    id: call.id,
                    name: call.name,
                    response: { result: JSON.stringify(result) }
                }]
            });
        }
        
        return response.text;

    } catch (error) {
        console.error("Error calling Gemini Chat API:", error);
        throw new Error("Failed to get chat response from AI.");
    }
}