import React from 'react';
import { Language, Translation, User } from '../types';
import { LogoIcon, GoogleIcon } from './Icons';

interface HeaderProps {
    language: Language;
    setLanguage: (lang: Language) => void;
    t: Translation;
    user: User | null;
    onLogin: () => void;
    onLogout: () => void;
}

export const Header: React.FC<HeaderProps> = ({ language, setLanguage, t, user, onLogin, onLogout }) => {
    return (
        <header className="glass-card sticky top-0 z-10 mx-2 my-2 md:mx-4 md:my-4">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex items-center justify-between h-16">
                    <div className="flex items-center space-x-3 rtl:space-x-reverse">
                        <LogoIcon className="h-8 w-8 text-brand-primary" />
                        <h1 className="text-xl font-bold text-brand-text-primary hidden sm:block">{t.headerTitle}</h1>
                    </div>
                    
                    <div className="flex items-center gap-4">
                        {/* Auth Section */}
                        {user ? (
                            <div className="flex items-center gap-3 bg-brand-bg/50 px-3 py-1.5 rounded-full border border-brand-border">
                                <img src={user.avatarUrl} alt={user.name} className="w-6 h-6 rounded-full" />
                                <span className="text-sm font-medium hidden sm:block">{user.name}</span>
                                <button 
                                    onClick={onLogout}
                                    className="text-xs text-brand-danger hover:underline font-semibold"
                                >
                                    {t.logout}
                                </button>
                            </div>
                        ) : (
                            <button
                                onClick={onLogin}
                                className="flex items-center gap-2 bg-white text-gray-900 px-3 py-1.5 rounded-full text-sm font-bold hover:bg-gray-100 transition-colors"
                            >
                                <GoogleIcon className="w-4 h-4" />
                                <span className="hidden sm:inline">{t.loginWithGoogle}</span>
                                <span className="sm:hidden">{t.login}</span>
                            </button>
                        )}

                        <div className="h-6 w-px bg-brand-border mx-1"></div>

                        {/* Language Selector */}
                        <div className="flex items-center bg-brand-surface rounded-lg p-1 border border-brand-border">
                            <button
                                onClick={() => setLanguage('en')}
                                className={`px-2 py-1 text-xs font-bold rounded-md transition-colors ${language === 'en' ? 'bg-brand-primary text-white shadow' : 'text-brand-text-secondary hover:text-brand-text-primary'}`}
                            >
                                EN
                            </button>
                            <button
                                onClick={() => setLanguage('ar')}
                                className={`px-2 py-1 text-xs font-bold rounded-md transition-colors ${language === 'ar' ? 'bg-brand-primary text-white shadow' : 'text-brand-text-secondary hover:text-brand-text-primary'}`}
                            >
                                AR
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </header>
    );
};