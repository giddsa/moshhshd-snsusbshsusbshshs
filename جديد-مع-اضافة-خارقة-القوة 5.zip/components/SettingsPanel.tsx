import React from 'react';
import { Translation, TradingType } from '../types';

interface SettingsPanelProps {
    leverage: number;
    setLeverage: (leverage: number) => void;
    tradingType: TradingType;
    setTradingType: (type: TradingType) => void;
    t: Translation;
}

export const SettingsPanel: React.FC<SettingsPanelProps> = ({ leverage, setLeverage, tradingType, setTradingType, t }) => {
    const isSpot = tradingType === 'spot';

    return (
        <div className="glass-card p-6">
            <h2 className="text-xl font-bold mb-4">{t.settingsTitle}</h2>
            <div className="space-y-6">
                <div>
                    <label className="block text-sm font-medium text-brand-text-secondary mb-2">{t.tradingType}</label>
                    <div className="flex rounded-md shadow-sm">
                        <button
                            type="button"
                            onClick={() => setTradingType('futures')}
                            className={`relative inline-flex items-center px-4 py-2 rounded-l-md border ${tradingType === 'futures' ? 'bg-brand-primary border-brand-primary text-white' : 'bg-brand-surface border-brand-border text-brand-text-secondary hover:bg-brand-border'} text-sm font-medium focus:z-10 focus:outline-none`}
                        >
                            {t.futures}
                        </button>
                        <button
                            type="button"
                            onClick={() => setTradingType('spot')}
                            className={`-ml-px relative inline-flex items-center px-4 py-2 rounded-r-md border ${tradingType === 'spot' ? 'bg-brand-primary border-brand-primary text-white' : 'bg-brand-surface border-brand-border text-brand-text-secondary hover:bg-brand-border'} text-sm font-medium focus:z-10 focus:outline-none`}
                        >
                            {t.spot}
                        </button>
                    </div>
                </div>
                <div>
                    <label htmlFor="leverage" className={`block text-sm font-medium mb-2 ${isSpot ? 'text-gray-500' : 'text-brand-text-secondary'}`}>{t.leverage}</label>
                    <div className="flex items-center">
                        <input
                            type="range"
                            id="leverage"
                            min="1"
                            max="125"
                            value={leverage}
                            onChange={(e) => setLeverage(parseInt(e.target.value))}
                            disabled={isSpot}
                            className={`w-full h-2 rounded-lg appearance-none cursor-pointer ${isSpot ? 'bg-gray-700' : 'bg-brand-border'}`}
                        />
                        <span className={`ms-4 rtl:me-4 text-lg font-semibold w-12 text-center ${isSpot ? 'text-gray-500' : 'text-brand-primary'}`}>{isSpot ? '1x' : `${leverage}x`}</span>
                    </div>
                </div>
            </div>
        </div>
    );
};