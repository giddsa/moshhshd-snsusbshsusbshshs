import React from 'react';
import { Translation, OpenPosition, TradeHistory } from '../types';
import { WalletIcon, CheckCircleIcon, XCircleIcon } from './Icons';

interface PortfolioPanelProps {
    t: Translation;
    balance: number;
    openPositions: OpenPosition[];
    tradeHistory: TradeHistory[];
    onClosePosition: (positionId: string) => void;
}

const StatCard: React.FC<{ label: string; value: string; color?: string }> = ({ label, value, color = 'text-brand-text-primary' }) => (
    <div className="bg-brand-surface/50 p-4 rounded-lg border border-brand-border">
        <p className="text-sm text-brand-text-secondary">{label}</p>
        <p className={`text-2xl font-bold mt-1 ${color}`}>{value}</p>
    </div>
);

export const PortfolioPanel: React.FC<PortfolioPanelProps> = ({ t, balance, openPositions, tradeHistory, onClosePosition }) => {
    // Note: Unrealized PnL calculation is a simulation. In a real app, you'd need a live price feed.
    const unrealizedPnl = openPositions.reduce((acc, pos) => {
        const mockCurrentPrice = pos.entryPrice * (1 + (Math.random() - 0.5) * 0.02); // Simulate +/- 2% price fluctuation
        const size = pos.amountUSD / pos.entryPrice;
        const pnl = (mockCurrentPrice - pos.entryPrice) * size * (pos.position === 'Long' ? 1 : -1);
        return acc + pnl;
    }, 0);

    return (
        <div className="space-y-8">
            <div className="glass-card p-6">
                <h2 className="text-2xl font-bold mb-4 flex items-center gap-3"><WalletIcon className="w-7 h-7" />{t.portfolioTitle}</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <StatCard label={t.accountBalance} value={`$${balance.toFixed(2)}`} />
                    <StatCard 
                        label={t.unrealizedPnL} 
                        value={`${unrealizedPnl >= 0 ? '+' : ''}$${unrealizedPnl.toFixed(2)}`}
                        color={unrealizedPnl >= 0 ? 'text-green-400' : 'text-red-400'}
                    />
                </div>
            </div>

            <div className="glass-card p-6">
                <h3 className="text-xl font-bold mb-4">{t.openPositions}</h3>
                <div className="overflow-x-auto">
                    {openPositions.length > 0 ? (
                        <table className="w-full text-sm text-left rtl:text-right">
                            <thead className="text-xs text-brand-text-secondary uppercase bg-brand-surface/50">
                                <tr>
                                    <th scope="col" className="px-6 py-3">{t.symbol}</th>
                                    <th scope="col" className="px-6 py-3">{t.position}</th>
                                    <th scope="col" className="px-6 py-3">{t.entryPrice}</th>
                                    <th scope="col" className="px-6 py-3">{t.size}</th>
                                    <th scope="col" className="px-6 py-3"></th>
                                </tr>
                            </thead>
                            <tbody>
                                {openPositions.map(pos => (
                                    <tr key={pos.id} className="border-b border-brand-border hover:bg-brand-surface/30">
                                        <td className="px-6 py-4 font-medium">{pos.symbol}</td>
                                        <td className={`px-6 py-4 font-semibold ${pos.position === 'Long' ? 'text-green-400' : 'text-red-400'}`}>{t[pos.position.toLowerCase() as 'long'|'short']}</td>
                                        <td className="px-6 py-4">${pos.entryPrice.toFixed(3)}</td>
                                        <td className="px-6 py-4">${pos.amountUSD.toFixed(2)}</td>
                                        <td className="px-6 py-4 text-right">
                                            <button onClick={() => onClosePosition(pos.id)} className="font-medium text-brand-primary hover:underline">{t.closePosition}</button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    ) : (
                        <p className="text-center text-brand-text-secondary py-8">{t.noOpenPositions}</p>
                    )}
                </div>
            </div>

            <div className="glass-card p-6">
                <h3 className="text-xl font-bold mb-4">{t.tradeHistory}</h3>
                 <div className="overflow-x-auto">
                    {tradeHistory.length > 0 ? (
                        <table className="w-full text-sm text-left rtl:text-right">
                            <thead className="text-xs text-brand-text-secondary uppercase bg-brand-surface/50">
                                <tr>
                                    <th scope="col" className="px-6 py-3">{t.symbol}</th>
                                    <th scope="col" className="px-6 py-3">{t.position}</th>
                                    <th scope="col" className="px-6 py-3">{t.pnl}</th>
                                    <th scope="col" className="px-6 py-3">{t.entryPrice}</th>
                                    <th scope="col" className="px-6 py-3">Exit Price</th>
                                </tr>
                            </thead>
                            <tbody>
                                {tradeHistory.map(trade => (
                                    <tr key={trade.id} className="border-b border-brand-border hover:bg-brand-surface/30">
                                        <td className="px-6 py-4 font-medium">{trade.symbol}</td>
                                        <td className="px-6 py-4">{t[trade.position.toLowerCase() as 'long'|'short']}</td>
                                        <td className={`px-6 py-4 font-semibold ${trade.pnl >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                                            {trade.pnl >= 0 ? '+' : ''}${trade.pnl.toFixed(2)}
                                        </td>
                                        <td className="px-6 py-4">${trade.entryPrice.toFixed(3)}</td>
                                        <td className="px-6 py-4">${trade.exitPrice.toFixed(3)}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    ) : (
                        <p className="text-center text-brand-text-secondary py-8">{t.noTradeHistory}</p>
                    )}
                </div>
            </div>
        </div>
    );
};